import json
D = '/workspace/phlippo-cad/report-0.5.11/'
F = json.load(open(D + 'findings.json')); P = json.load(open(D + 'parity.json')); R = json.load(open(D + 'tools/results-0511.json'))
c = P['counts']; A, De, O, K = c.get('aanwezig', 0), c.get('deels', 0), c.get('ontbreekt', 0), c.get('kapot', 0)
br, rl = R['brep'], R['release']
fx = lambda x, n: (f'**{x[0]}/{x[1]}**, {x[2]} skips' if x else f'nog niet afgerond bij het schrijven (zie `{n}`)')
BR, RL = fx(br, 'logs/regression-brep.log'), fx(rl, 'logs/regression-release.log')
OPENST = ('Deels opgelost', 'Open', 'Niet geverifieerd', 'Nieuw')
op = [f for f in F if f['status'] in OPENST]
from collections import Counter
sv = Counter(f['sev'] for f in op)
krit = [f['id'] for f in op if f['sev'] == 'Kritiek']
B10 = {f['id']: f for f in json.load(open(D + 'findings-0.5.10.json'))}
was = [i for i, f in B10.items() if f['status'] != 'Opgelost']
closed = [i for i in was if next(x for x in F if x['id'] == i)['status'] == 'Opgelost']
withdrawn = [i for i in was if next(x for x in F if x['id'] == i)['status'].startswith('Ingetrokken')]
still = [i for i in was if i not in closed and i not in withdrawn]
new = [f['id'] for f in F if f['status'] == 'Nieuw']
SCORE = '6/10'
naar = open(D + 'tools/naar100.md').read().replace('{PCT}', str(P['pct']).replace('.', ',')).replace('{A}', str(A)).replace('{D}', str(De)).replace('{O}', str(O)).replace('{K}', str(K))
open(D + 'NAAR-100.md', 'w').write(naar)
out = []
w = out.append
w(f'''# QA-rapport Phlippo CAD 0.5.11 — strikte controle tegen SOLIDWORKS

*Opgesteld op 3 november 2026 (Europe/Brussels, UTC+1). Alle cijfers komen uit runs op de QA-box (Linux, xvfb en SwiftShader) of uit bestanden in deze map. Er is niets overgenomen zonder eigen controle. Doel van de opdrachtgever: "echt 100 % halen". Daarom staat er in §11 een volledig plan met acceptatietests (ook als los bestand `NAAR-100.md`).*

## 0. Versie en scope

| | |
|---|---|
| Versie | **0.5.11**, HEAD `db0d4b2` (`db0d4b27d857c42b898bcec68c65240b3fe855e9`, 3-11-2026 02:46 CET), branch `claude/fase1-schetser` |
| Vorige QA | 0.5.10 (`a4b1e92`): score 5/10, strikte pariteit 66,1 %, 70 open bevindingen, 9 Kritiek |
| Delta | 14 commits sinds `a4b1e92` |
| Testomgeving | `git archive HEAD` van de laptop naar `/workspace/phlippo-cad/app-0.5.11`. Node 22 met Playwright-Chromium (SwiftShader) en Electron onder xvfb. De laptop is alleen gelezen. |
| Bewijs | `logs/` (alle runs), `shots/` (screenshots), `win/` (Windows- en Actions-logs van de laptop, zelfrapportage), `tools/` (generatoren en eigen QA-tests in `tools/qa-src/`) |
| Beperking | Box-logs tonen "commit unknown", omdat een git-archive geen .git heeft. Dat de code van HEAD is, blijkt uit `provenance.txt`. |

## 1. Oordeel (executive summary)

**Is het klaar? Nog niet, maar 0.5.11 is de eerste versie zonder bekende stille geometriefout.** De fillet op een gatrand klopt nu op de mesh-kernel. Het verlies is 97,61 mm³ tegen 96,80 theoretisch, dus F139 is opgelost. De gesplitste-randfillet (T3) klopt op beide kernels: B-rep geeft precies 30439,911 mm³. Mates markeren nu de nieuwste, conflicterende mate (F141). AutoRecover is veilig: desktop-recover geeft 21/21. Two/Four View werkt ook zonder WebGL (35/35). Op de Linux-box is de volledige mesh-regressie **98/98 groen met 0 skips**. In 0.5.10 was dat 93/98. De B-rep-pass (14 scripts) is **14/14** en de volledige release-pass (`?kernel=brep&rebuild=worker`) is **98/98** groen, met 1 optioneel stapje overgeslagen. Daarmee is F105 op de box gesloten en staat er geen Kritiek meer open.

**Correctie op ons eigen rapport:** F140 ("B-rep rondt een extra rand af") en het afgeleide F167 trekken we in. Onze 0.5.10-test koos met `reduce()` de eerste van de gelijke 80 mm-randen. Onder de B-rep-kernel is dat een andere rand, één die de sleuf niet snijdt. Op die rand is 30431,327 mm³ precies het juiste antwoord (30500 − 80·R²(1−π/4)). De ontwikkelaar had gelijk met "niet reproduceerbaar". Zie §4.2.

**Waarom nog geen "klaar":**
1. **Geen bewijs op HEAD buiten deze box.** De Windows-logs zijn van `0495219`/`1fd00e3` en de Actions-runs van `c1fc039`/`75ceeea`, met rode shards. Op HEAD is er geen groene CI-run, omdat het minutenquotum op was (F176, F54, F31, F147).
2. **Nog niet overal exact.** Indent, Lip/Groove, Snap Hook, Mounting Boss, surfaces en wrap-patches blijven mesh. Ellipsen en splines worden ook in B-rep als segmenten gebouwd (F51, F121, F175). Het programma meldt dat nu wel eerlijk ("Faceted").
3. **De vangnetten zijn te grof.** De kruiscontrole exact tegen mesh slaat pas aan bij 0,5 % van het bodyvolume. Op T3 is dat 152 mm³, terwijl een hele fillet maar 60 mm³ is (F172). De strikte tests in de repo hebben ook te ruime marges (F173).
4. **De installer is ongesigneerd** (F49/F117), nu wel eerlijk gemeld.

**Lijkt het op SOLIDWORKS?** Visueel en qua werkwijze sterk (shots/viewpanes-four.png, shots/home-brep.png). Functioneel ontbreken nog design tables, Instant2D/Magnified Selection, IGES/DWG/Parasolid en code-signing. 17 van de 62 pariteitsrijen zijn alleen te beoordelen met een SOLIDWORKS-referentie, die er niet is.

**Eindscore: {SCORE}** (0.5.10: 5/10). **Strikte pariteit: {str(P['pct']).replace('.', ',')} %** (0.5.10: 66,1 %). {len(op)} bevindingen staan open: {sv.get('Kritiek',0)} Kritiek, {sv.get('Major',0)} Major, {sv.get('Minor',0)} Minor. **GO/NO-GO:** NO-GO voor publiceren; GO voor eigen concept- en hobbywerk.

## 2. Delta sinds 0.5.10 (14 commits)

| Onderwerp | Wat de commits en README zeggen | QA-bevinding |
|---|---|---|
| Fillet op gatrand (F139) | Kettingtolerantie en "Keep features"-hersnede | **Klopt**: mesh-verlies binnen 0,9 % van de gesloten vorm, B-rep exact |
| Wrap exact | Polyhedrale B-rep-tool | Deels: lichaam blijft "exact", maar de patch is polyhedraal (rij 15) |
| Dome exact | Bol-segment | **Klopt** (qaBrep) |
| Kruiscontrole F159 | Exact tegen facet, terugval bij > 0,5 % | Bestaat, maar de drempel is te ruim (F172) |
| QA-tests in repo | "8 mesh + 13 B-rep" in `src/qa/` | **Klopt** (geteld). TASKS.md noemt nog "(11)" |
| Mates | Nieuwste mate gemarkeerd, Not Converged | **Klopt** (M2, StatusBar.tsx:111) |
| AutoRecover | Eén sleutel per document | **Klopt** (desktop-recover 21/21) |
| Two/Four View | Hoofdrenderer, zonder WebGL opgevangen | **Klopt** (viewpanes 35/35) |
| Namen | Frames, Additional Materials, SW-Density → Density | **Klopt** (Ribbon.tsx:47, persistence.ts:139) |
| CI | Matrix mesh/B-rep/release, één log per pass, skip-budget | Config klopt; op HEAD niet gedraaid |
| Windows | "mesh 98/98, release 98/98, brep 12/12 op 0495219" | Getallen kloppen met `win/*.txt`, maar niet op HEAD (brep op 1fd00e3) |

## 3. Testresultaten (box, echte cijfers)

| Test | Resultaat | Log |
|---|---|---|
| Unit (vitest) | **487/487**, 121 bestanden | logs/vitest.log |
| Typecheck | exit 0 | logs/typecheck.log |
| ci-checks (merken, neutral, budgetten) | ok | logs/ci-checks.log |
| Bundel | 854,86 kB van 860 kB (5,14 kB marge) | logs/build-release.log |
| npm audit | dev-keten 15 moderate, 0 high; productie 0 | logs/audit.json, logs/audit-prod.json |
| Regressie mesh (98 scripts) | **98/98**, 0 skips. drawing 28/28, inventory47 18/18, videos46 25/25, sheetexport 12/12, rebuildworker 10/10 (152 s), features 65/65 (163 s), multibody 14/14 | logs/regression-mesh.log |
| Regressie B-rep (14 scripts, `?kernel=brep`) | {BR} | logs/regression-brep.log |
| Regressie release (98 scripts, `?kernel=brep&rebuild=worker`) | {RL} | logs/regression-release.log |
| Electron self-test zonder GPU | **8/8**: B-rep exact 44858,407; Fillet1 exact 44742,522; STEP exact (23567 B); worker 1143/1143 vertices in 85 ms; atomaire save met .bak | logs/self-test-nogpu.json |
| Electron self-test SwiftShader | **8/8**, zelfde waarden, worker 183 ms | logs/self-test-softgl.json |
| desktop-nohooks (soft GL) | 10/10 | logs/desktop-nohooks-softgl.log |
| desktop-restore-autosave | ok, 4 features hersteld | logs/desktop-autosave.log |
| desktop-recover | **21/21** (F153, F154, F156, F162) | logs/desktop-recover.log |
| viewpanes | 35/35 | logs/viewpanes.log |

**Werkwijze B-rep/release op de box:** de QA-box werd halverwege de B-rep-pass vervangen (node_modules, dist en de Playwright-cache waren weg). Opnieuw `npm ci`, `playwright install chromium` en `build:e2e` (bundel opnieuw 854,77 kB). De B-rep-pass is daarna afgemaakt: 7 scripts vóór de reset (`logs/regression-brep-part1.log`) plus de 7 resterende (`logs/regression-brep-part2.log`). De release-pass liep volledig opnieuw, in 3 parallelle shards (`E2E_SHARD=k/3`, `logs/regression-release-shard{1,2,3}.log`). De gecombineerde DONE-regels staan in `logs/regression-brep.log` en `logs/regression-release.log`. Het enige overgeslagen optionele stapje in de release-pass is sheetexport "PDF in de browserviewer" (Download is starting, binnen het budget van 1).

**Windows-logs vergeleken (win/):** `regression-0.5.11-mesh-win32.txt` geeft DONE 98/98 op `0495219`, `…-release-win32.txt` geeft 98/98 op `0495219`, `…-brep-win32.txt` geeft 12/12 op `1fd00e3`. De getallen kloppen met de claims, maar geen van de drie is van HEAD `db0d4b2`. `desktop-installed-0.5.11.txt` bevat alleen de regel "19/19 checks passed", zonder commit of lijst van checks (F97). `signature-0.5.11.txt` geeft NotSigned voor alle drie de exe's.

### 3.1 Eigen strikte QA-tests (bronnen in tools/qa-src/, log logs/qa-ext-tests.log: 14/14)

CORNER(R) = R²(1−π/4) en RIM_LOSS = CORNER·2π(r + k·R) met k = (10−3π)/(12−3π).

| Test | Kernel | Gemeten | Verwacht | Oordeel |
|---|---|---|---|---|
| T1 gatrand R2, Ø35 | mesh | verlies 97,61 mm³ | 96,80 | ok (+0,8 %, facetten) |
| T1 na Ø50 | mesh | verlies 138,46 | 137,25 | ok (+0,9 %) |
| T1 Ø35 / Ø50 | B-rep | 54282,076 / 44227,798 | formule | **exact** |
| T2 revolve-fillet | mesh | verlies 432,68 | 428,74 | ok (+0,9 %) |
| T2 | B-rep | 100175,033 / 149865,048 | formule | **exact** |
| T3 gesplitste rand z=−40 | mesh | 30439,067 | 30439,911 | ok (−0,8 mm³) |
| T3 gesplitste rand z=−40 | B-rep | 30439,911 | 30439,911 | **exact** |
| T3 rand z=0 (niet gesplitst) | B-rep | 30431,327 | 30500 − 80·CORNER(2) = 30431,327 | **exact** (zie §4.2) |
| M2 conflict | — | nieuwste mate m2 gemarkeerd | m2 | ok (F141) |
| M5 gesloten lus met conflict | — | mAB gemarkeerd, B "over", C "under" | idem | ok |
| E1 circulaire vergelijking | — | gemeld | gemeld | ok |

## 4. Claimcontrole

### 4.1 Onjuiste of onbewezen claims

| Claim | Waar | Oordeel |
|---|---|---|
| "Linux: checks en desktop groen" | README.md, win/linux/README.md | **Onbewezen**: er staan geen ruwe logs van de checks- en desktop-jobs in `win/linux/`, alleen regressieshards (F149) |
| "qaBrep.test.ts (11)" | TASKS.md (P0/P1-regel) | **Onjuist**: het zijn er 13. README zegt terecht 13 (F129) |
| F142 "alleen .gitignore" | docs/28 | **Verouderd**: graphify-out is echt uit de index (TASKS klopt) |
| "release 0.5.11 gebouwd en geïnstalleerd (19/19)" | TASKS.md:834 | **Zwak bewijs**: het log is één regel zonder commit of checks (F97) |
| "Regressie Windows op 0495219 (mesh 98/98, release 98/98, brep 12/12)" | TASKS.md:834 | Getallen kloppen, maar brep draaide op `1fd00e3` en niets op HEAD (F176) |
| "Wrap op een exact lichaam houdt het lichaam exact" | README | **Deels**: het lichaam blijft exact, de patch is polyhedraal |
| "elk lichaam krijgt een kruiscontrole" | README | Klopt, maar met 0,5 % is die te grof om fillet-fouten te vangen (F172) |
| Overige claims (F139, F141, F143, F144–F146, F153–F158, F160, F162–F166, Frames) | commits, TASKS, docs/28 | **Klopt**, zelf nagemeten (§3) |

### 4.2 Ingetrokken: F140 en F167 (fout in onze test)

De 0.5.10-test `B-T3` koos de te fillen rand met `edges.reduce((a, b) => len(b) > len(a) ? b : a)`. Bij gelijke lengte (80 mm) blijft dan de eerste rand staan. Onder de mesh-kernel was dat de rand op z=−40, die de sleuf in twee stukken snijdt. Onder de B-rep-kernel was het de rand op z=0, die de sleuf niet raakt. De diagnose (`tools/qa-src/qaT3diag.test.ts`, `logs/qa-t3diag.log`):

- rand z=0 in B-rep: 30431,327 mm³ = 30500 − 80·CORNER(2), verschil 0;
- rand z=−40 in B-rep, sleuf in twee richtingen en gewone sleuf: 30439,911 mm³ = 30500 − 70·CORNER(2), verschil 0;
- rand z=−40 in mesh: 30439,067 mm³ (−0,8 mm³, facetten).

Het programma deed in 0.5.10 dus al het juiste. De ontwikkelaar meldde terecht "niet reproduceerbaar". Op 0.5.10 zelf konden we de diagnose niet opnieuw draaien, omdat `app-0.5.10/node_modules` geen vite bevat (`logs/qa-t3diag-on-0.5.10.log`). De 0.5.10-waarde 30431,327 is wel exact de waarde voor de z=0-rand. **Les voor QA:** kies randen op positie, niet met een `reduce` op lengte.

## 5. Pariteitsmatrix (62 rijen)

Weging: aanwezig = 1, deels = 0,5, ontbreekt/kapot = 0. **{A} aanwezig, {De} deels, {O} ontbreekt, {K} kapot: {str(P['pct']).replace('.', ',')} %** (0.5.10: 66,1 %). Rijen waarvoor een SOLIDWORKS-referentie nodig is om "aanwezig" te worden: {', '.join(map(str, P['sw_ref_nodig']))}.

| # | Gebied | Onderdeel | 0.5.10 | 0.5.11 | Bewijs |
|---|---|---|---|---|---|''')
for i, r in enumerate(P['rows'], 1):
    ch = ' **↑**' if r['old'] != r['status'] else ''
    w(f"| {i} | {r['area']} | {r['item']} | {r['old']} | {r['status']}{ch} | {r['ev'].replace('|', '/')} |")
w(f'''
## 6. Alle bevindingen

Totaal {len(F)} (F1–F176). Van de 70 bevindingen die in 0.5.10 open stonden zijn er **{len(closed)} opgelost**, **{len(withdrawn)} ingetrokken** (F140, F167) en **{len(still)} nog open**. Nieuw: **{len(new)}** ({', '.join(new)}). Open per ernst: **Kritiek {sv.get('Kritiek',0)}**{(' (' + ', '.join(krit) + ')') if krit else ''}, Major {sv.get('Major',0)}, Minor {sv.get('Minor',0)}.

Opgelost in 0.5.11: {', '.join(closed)}.

### 6.1 Overzicht open bevindingen

| ID | Ernst | Status | Prio | Gebied | Titel |
|---|---|---|---|---|---|''')
po = {'P0': 0, 'P1': 1, 'P2': 2, 'P3': 3}
so = {'Kritiek': 0, 'Major': 1, 'Minor': 2}
op.sort(key=lambda f: (po.get(f['prio'], 9), so.get(f['sev'], 9), int(f['id'][1:])))
for f in op: w(f"| {f['id']} | {f['sev']} | {f['status']} | {f['prio']} | {f['area']} | {f['title']} |")
w('\n### 6.2 Details open bevindingen\n')
for f in op:
    w(f"#### {f['id']} · {f['sev']} · {f['status']} · {f['prio']} · {f['area']} — {f['title']}\n")
    w(f"- **Bewijs:** {f['ev']}\n- **Reproductie:** {f.get('repro','')}\n- **Fix:** {f.get('fix','')}\n")
w('### 6.3 Opgelost of ingetrokken in deze ronde\n\n| ID | Was | Nu | Bewijs 0.5.11 |\n|---|---|---|---|')
for i in closed + withdrawn:
    f = next(x for x in F if x['id'] == i)
    w(f"| {i} | {f['old']} | {f['status']} | {f['ev'].split(' || ')[0].replace('0.5.11: ', '').replace('|', '/')} |")
w(f'''
## 7. Risico's

1. **Bewijs alleen op de QA-box.** Zolang er geen groene CI-run en geen Windows-run op dezelfde release-commit is, kan elke "groen"-claim afwijken van wat gebruikers krijgen (F176).
2. **Stille afwijkingen onder 0,5 %.** Een fout van de grootte van een fillet valt binnen de kruiscontrole (F172).
3. **Facetten waar SOLIDWORKS exact is.** Massa, STEP en verdere bewerkingen op ellipsen, splines en plastics wijken af (F175, F51). Het programma meldt dat wel eerlijk.
4. **Ongesigneerde installer.** SmartScreen waarschuwt; niet geschikt voor verspreiding (F49).

## 8. Score

| Criterium | 0.5.10 | 0.5.11 | Waarom |
|---|---|---|---|
| Correcte geometrie | 4 | 7 | T1–T3 correct op beide kernels, B-rep exact; facetten bij plastics, ellips en spline |
| Functionele pariteit | 6 | 7 | {str(P['pct']).replace('.', ',')} % strikt |
| Bewijs/claims | 4 | 6 | Kop met commit/platform, één log per pass; maar niets groen op HEAD buiten de box |
| Tests | 5 | 7 | 487 unit, QA-tests in de repo; op Linux mesh 98/98, B-rep 14/14, release 98/98; toleranties te ruim |
| Release-klaar | 3 | 4 | Ongesigneerd, geen CI op HEAD |
| **Totaal** | **5/10** | **{SCORE}** | Streng afgerond naar beneden: zonder CI-bewijs op HEAD geen 7 |

## 9. Wat de ontwikkelaar nu als eerste moet doen

Zie §11. De top 5: (1) groene Actions-run op de release-commit, (2) kruiscontrole per feature, (3) QA-tests aanscherpen en M3/M5 in de repo, (4) Windows-, desktop- en checks-logs op dezelfde commit, (5) het SOLIDWORKS-referentiepakket R0.

## 10. Bijlagen

`findings.json` (176 bevindingen), `parity.json` (62 rijen), `NAAR-100.md`, `logs/`, `shots/`, `tools/` (generatoren `build_findings_0511.py`, `parity_0511.py`, `mkreport_0511.py`; QA-bronnen `tools/qa-src/`), `win/`, `provenance.txt`.

## 11. Weg naar 100%
''')
import re as _re
w(_re.sub(r'(?m)^(#{2,3}) ', lambda m: '#' + m.group(1) + ' ', naar.split('\n', 2)[2]))
open(D + 'QA-rapport-0.5.11.md', 'w').write('\n'.join(out))
print('ok', len(op), dict(sv), krit, len(closed), len(withdrawn), len(still), new)
