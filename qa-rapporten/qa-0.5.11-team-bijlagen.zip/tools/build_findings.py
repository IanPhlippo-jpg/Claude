import json, copy
B = json.load(open('/workspace/phlippo-cad/report-0.5.1/findings.json'))
F = {f['id']: copy.deepcopy(f) for f in B}
for f in F.values(): f['old'] = f['status']   # 'old' = status in 0.5.1 (na teamronde)
R = json.load(open('/workspace/phlippo-cad/report-0.5.10/tools/results.json'))
def up(i, status, ev, sev=None, prio=None, title=None, fix=None, repro=None):
    f = F[i]; f['status'] = status; f['ev'] = '0.5.10: ' + ev + ' || 0.5.1: ' + f['ev']
    if sev: f['sev'] = sev
    if prio: f['prio'] = prio
    if title: f['title'] = title
    if fix: f['fix'] = fix
    if repro: f['repro'] = repro
L = 'logs/'
up('F10', R['F10_status'], R['F10_ev'], prio='P1')
up('F31', 'Deels opgelost', 'Exitcodes en runner in orde; CI-config draait nu met SwiftShader (ci.yml). Een groene Actions-run is niet te bewijzen (privé-repo, geen gh op laptop of box). Lokale Linux-regressie: ' + R['reg_summary'] + ' (logs/regression.log).', sev='Major', prio='P1')
up('F38', 'Deels opgelost', 'README "Status" stopt bij 0.5.4 terwijl de versie 0.5.10 is (README.md:46); TASKS en commit a3bfaf7 melden 98/98, op Linux niet gehaald.', prio='P3')
up('F46', 'Deels opgelost', 'Release-builds rebuilden standaard in de worker (rebuildWorker.ts:25-36, perf.rebuildWorker=true); e2e-builds draaien op de UI-thread tenzij ?rebuild=worker. Worker-pass: ' + R['worker_summary'] + ' (logs/regression-worker.log). Budget nog 45 s (F137).', prio='P3')
up('F47', 'Deels opgelost', 'Mesh: T1-T3 randen worden teruggevonden; B-rep: T3 rondt een extra parallelle rand af (F140) → naamgeving nog niet robuust.')
up('F49', 'Open', 'Geïnstalleerde Phlippo CAD.exe: Get-AuthenticodeSignature = NotSigned (laptop, read-only). Bewust (docs/25), maar blokkeert publiceren (SmartScreen).', prio='P2')
up('F50', 'Deels opgelost', 'SW-Density en 3D ContentCentral weg (F116/F131); "Weldments" bewust behouden: 28 vermeldingen in src en zichtbaar als tabblad (shots/walk-18-done.png). Kritiek → Major: één term resteert, juridische check vóór publicatie.', sev='Major', prio='P1')
up('F51', 'Deels opgelost', 'Browser-build toont "Faceted 1/1" (shots/walk-18-done.png); mesh-kernel blijft primair voor preview/terugval/worker; plastics-features alleen mesh (plastics.ts gebruikt csg/extrudeGeometry); mesh-fillet op gatrand fout (F139).', prio='P1')
up('F54', R['F54_status'], R['F54_ev'], prio=R['F54_prio'])
up('F93', 'Deels opgelost', 'Claims kloppen niet: commit a3bfaf7 en TASKS.md:810 melden "98/98", lokaal Linux haalt dat niet; bundle "827 kB" is 849 kB (F118); het Windows-log met 98/98 heet regression-0.5.9.txt (start 30-10 22:03 CET, vóór de versie-commit a3bfaf7 van 22:48 CET); lokaal Linux ' + R['reg_summary'] + '.', prio='P1')
up('F94', 'Deels opgelost', 'Pack and Go en MBD weg uit src; Weldments bewust behouden (zie F50).', prio='P2')
up('F98', 'Deels opgelost', 'Branch is gepusht (laptop: claude/fase1-schetser = origin/…, HEAD a4b1e92). Een Actions-run-link of -uitslag ontbreekt nog steeds.', prio='P1')
up('F97', 'Opgelost', 'Niet opnieuw op Windows getest; box-self-test (app://, 0.5.10) 8/8 zonder GPU en met SwiftShader (logs/self-test-nogpu.json, logs/self-test-softgl.json).', prio='P4')
up('F99', 'Opgelost', 'Featuretree toont per body "Exact surfaces (B-rep)"/Faceted (FeatureTreeBody.tsx:354); open faceted resultaat geeft waarschuwing (rebuild.ts:3364).', prio='P4')
up('F100', R['F100_status'], R['F100_ev'], prio=R['F100_prio'])
up('F105', R['F105_status'], R['F105_ev'], prio=R['F105_prio'])
up('F108', 'Opgelost', 'QA M2: conflict wordt gedetecteerd (B "over", violated ["m1"]); M5 lus-conflict ook gedetecteerd (logs/qa-strict-tests.log). Kanttekening: de oudere mate wordt als fout gemarkeerd i.p.v. de nieuwe (F141).', prio='P4')
up('F109', 'Opgelost', 'QA M1 in beide refs-volgordes B=25, C=10; M3 keten van 4 in slechtste volgorde correct; M5 gesloten lus correct (logs/qa-strict-tests.log).', prio='P4')
up('F110', 'Opgelost', 'QA T2 mesh: geen fout, verlies 432,68 vs theorie 428,74 (R30: 359,14 vs 355,93); B-rep exact 428,74/355,93 (logs/qa-strict-tests.log, logs/qa-brep-tests.log).', prio='P4')
up('F111', 'Deels opgelost', 'Mesh: T3 30439,07 vs verwacht 30439,91 → OK. B-rep (standaard in release): 30431,33, 8,584 mm³ te weinig = een extra rand van 10 mm afgerond (F140). Kritiek → Major (mesh-deel dicht; B-rep-deel apart als F140).', sev='Major', prio='P1')
up('F112', 'Deels opgelost', '379 sleutels (prefsSchema+prefs), 45 in WIRED_PREFS, 334 inert maar grijs met "Not available in this version of Phlippo CAD." (options.tsx:80-81; logs/prefs-unused.txt); prefsWired.test.ts bewaakt de lijst; AutoRecover schrijft echt (autoRecover.ts). Eerlijkheid opgelost; slechts ≈12 % van de opties werkt → Kritiek → Major.', sev='Major', prio='P2')
up('F113', 'Opgelost', 'Slepen in de boom met canDrop/onDrop (FeatureTreeBody.tsx:213) + core/features/reorder.ts met reorder.test.ts; e2e/reorder.mjs:52-69 sleept met dragTo, 10/10 (logs/regression.log).', prio='P4')
up('F114', 'Deels opgelost', 'PDF/DXF-export van tekeningen (sheetExport.ts, export2d.ts + export2d.test.ts, e2e/sheetexport.mjs). IGES, DWG en Parasolid ontbreken nog.', prio='P2')
up('F115', R['F115_status'], R['F115_ev'], prio=R['F115_prio'], sev=R.get('F115_sev'))
up('F116', 'Opgelost', 'Geen "SW-Density" meer zichtbaar; equations.ts:262 accepteert de oude naam alleen bij inlezen.', prio='P4')
up('F117', 'Open', 'NotSigned bevestigd (zie F49).', prio='P2')
up('F118', 'Open', 'build-release: index 849,37 kB (gzip 233,87) — docs/25 claimt 827 kB; groei t.o.v. 0.5.1 (906) wel kleiner, maar de claim klopt niet (logs/build-release.log).', prio='P3')
up('F119', 'Opgelost', 'Runner telt en noemt skips (run-regression.mjs:19-29); lokaal: ' + R['skips'] + '.', prio='P4')
up('F120', 'Opgelost', 'CI B-rep-pass = 12 scripts, gelijk aan de lokale lijst (ci.yml:44).', prio='P4')
up('F121', 'Deels opgelost', 'Dome/Indent/Mounting Boss/Snap Hook/Lip-Groove bestaan (plasticsTypes.ts, plastics.ts, 12 unit-tests, e2e plastics) maar alleen op de mesh-kernel; Auto Fasteners aanwezig (store.ts:461).', prio='P2')
up('F122', 'Opgelost', 'Auto centermarks + verborgen lijnen (core/drawing/autoMarks.ts, hlr.ts met tests).', prio='P4')
up('F123', 'Opgelost', 'Intersection/Merge/Equal Curvature in solver (equations.ts:307-323) met relations2.test.ts; AlongX/Y/Z hoort bij 3D-schets (F124).', prio='P4')
up('F125', R['F125_status'], R['F125_ev'], prio=R['F125_prio'], sev=R.get('F125_sev'))
up('F126', 'Deels opgelost', 'Ruwe runner-logs bestaan nu op de laptop (win/regression-0.5.9.txt, win/regression-round2b.log). Maar het volledige 98/98-log is als 0.5.9 benoemd en het 0.5.10-log (round2b) bevat maar 6 scripts.', prio='P2')
up('F127', 'Opgelost', 'Self-test zonder GPU 8/8, Fillet1 exact 44742,52 (logs/self-test-nogpu.json); software-GL 8/8 (logs/self-test-softgl.json).', prio='P4')
up('F128', 'Opgelost', 'ci.yml: desktop-nohooks met PHLIPPO_SOFTWARE_GL=1 en self-test --software-gl, continue-on-error met eindstap die faalt; regressielog-artefact if-no-files-found: error. (Screenshots nog "ignore".)', prio='P4')
up('F129', 'Deels opgelost', 'docs/23 bijgewerkt; maar README-status 0.5.4, docs/25 noemt het 0.5.1-rapport "6/10" (was 5/10 na teamronde).', prio='P3')
up('F130', 'Deels opgelost', 'Nieuwe unit-tests mateStatus/revolve2/edgesets; maar de mesh-gatrand-fout (F139) en B-rep-T3 (F140) vallen door die tests heen; intussen 9 releases in 3 dagen met veel look-dev.', prio='P2')
up('F131', 'Opgelost', '"3D ContentCentral" weg uit src/electron; repo-tools/rename-trademarks.cjs:20 vervangt het.', prio='P4')
up('F132', 'Opgelost', 'Merkencheck + uiText.test dekken SW-, Pack and Go, MBD, SOLIDWORKS, 3D ContentCentral (logs/ci-checks.log EXIT=0).', prio='P4')
up('F133', 'Opgelost', '19 .catch(() => …) over: 4 in regressiescripts, allemaal gerichte terugval (Escape/alternatieve klik); 15 in e2e/tools (niet in de regressie).', prio='P4')
up('F134', 'Opgelost', 'Caps bevroren op huidige grootte en verlaagd bij splitsing (repo: tools/line-budget.cjs).', prio='P4')
up('F135', 'Opgelost', 'Alle statusbalk-prompts herschreven in eigen woorden (git diff 46fc2f3..HEAD -- src/app/StatusBar.tsx); frame-tags uit StatusBar weg.', prio='P4')
up('F136', 'Deels opgelost', 'repo-script neutral-comments.cjs scant e2e/ niet: 15+ e2e-bestanden verwijzen naar "reference video/frame" en één naar "the SOLIDWORKS reference frame" (e2e/tools/tune-shade.mjs:1); in src nog bodyScene.ts:688 "(reference frames: …)" dat de regex mist.', prio='P3')
up('F137', 'Deels opgelost', 'rebuildBudgetMs nog 45 000 (rebuild.ts:875); browser-release gebruikt wel de worker.', prio='P3')
for i in ['F16','F21','F22']: up(i, 'Niet geverifieerd', 'Niet opnieuw naast SOLIDWORKS gelegd; look is in 0.5.6-0.5.7 veranderd (studio look).')
for i in ['F24','F28','F124','F48']: F[i]['ev'] = '0.5.10: niet opnieuw getest, status overgenomen. || ' + F[i]['ev']
NEW = [
 dict(id='F138', area='Build/Security', sev='Minor', old='—', title='npm audit: 17 kwetsbaarheden (15 moderate, 2 high) in de electron-builder-keten', status='Nieuw', prio='P3', ev='logs/audit.log: follow-redirects 1.16.1, joi 18.3.0, minimatch 10.2.6; --omit=dev: 0 (logs/audit-prod.log). Zelfde versies als 0.5.1 → nieuwe advisories, alleen build-tijd.', repro='npm audit', fix='electron-builder/overrides bijwerken.'),
 dict(id='F139', area='Kernel', sev='Major', old='—', title='Mesh-fillet op een gatrand voegt volume toe i.p.v. af te nemen (fout zonder foutmelding)', status='Nieuw', prio='P1', ev='QA T1 mesh: Ø50: gefilleteerd 44390,34 > eigen scherpe mesh 44385,74 (verlies −4,6, verwacht 137,2), alleen waarschuwing "faceted result is not closed (≈18,48 mm²)". Ø35 direct: 54428,24 > 54393,40 (−34,8 i.p.v. 96,8) zonder waarschuwing (logs/qa-strict-tests.log, logs/qa-diag.log). Identiek in 0.5.1 → het 0.5.1-rapport noemde T1 ten onrechte OK (vergeleek met analytisch volume). B-rep exact correct (logs/qa-brep-tests.log); de gebruiker ziet eerst het foute mesh-resultaat, worker/terugval blijven fout.', repro='QA-bronnen uit tools/qa-src/ naar src/qa/ kopiëren, dan npx vitest run src/qa/qaStrict.test.ts src/qa/qaDiag.test.ts --silent=false', fix='Concave-rand fillet in mesh-CSG corrigeren of mesh-fillet op gesloten ronde randen weigeren met fout; test op volumeverlies t.o.v. eigen scherp volume.'),
 dict(id='F140', area='Topologie', sev='Kritiek', old='—', title='B-rep (standaard in release): fillet op gesplitste rand rondt een extra rand van 10 mm af', status='Nieuw', prio='P0', ev='QA T3 B-rep: 30431,33 vs verwacht 30439,91; tekort exact 8,584 mm³ = 10 mm × (4−π) bij R2 → één extra rechte rand van 10 mm afgerond, waarschijnlijk de achterrand van de sleuf parallel aan de oorspronkelijke rand (logs/qa-brep-tests.log). Stil fout resultaat, geen waarschuwing; mesh-pad correct.', repro='QA-bronnen uit tools/qa-src/ naar src/qa/ kopiëren, dan npx vitest run src/qa/qaBrep.test.ts --silent=false', fix='matchEdges op B-rep beperken tot randen die colineair met én binnen de oorspronkelijke rand liggen; T3 als B-rep-unit-test opnemen.'),
 dict(id='F141', area='Assembly', sev='Minor', old='—', title='Bij conflict wordt de oudere mate als fout gemarkeerd, niet de nieuwe', status='Nieuw', prio='P3', ev='QA M2: m1 (10) en m2 (20) → B y=30 (voldoet aan m2), violated ["m1"] (logs/qa-strict-tests.log). SOLIDWORKS houdt de bestaande mate en markeert de nieuw toegevoegde.', repro='vitest qaStrict › M2', fix='Mates in volgorde van aanmaak oplossen; de laatst toegevoegde conflicterende mate markeren.'),
 dict(id='F142', area='Repo', sev='Minor', old='—', title='graphify-out (64 MB, 193 bestanden) gecommit', status='Nieuw', prio='P3', ev='git ls-files graphify-out = 193; du -sh 64M; diff 46fc2f3..HEAD wordt erdoor gedomineerd (222 bestanden).', repro='git ls-files graphify-out | wc -l', fix='In .gitignore zetten en uit de index halen.'),
]
T={'F93':'Docs/commits claimen 98/98 terwijl de Linux-regressie rood blijft','F112':'Options-dialoog: 334 van 379 instellingen doen niets (nu eerlijk grijs)','F114':'Geen IGES-, DWG- of Parasolid-export (PDF/DXF van tekeningen nu wel)','F115':'Zonder WebGL: hoofdviewport en self-test nu netjes, multi-view nog onbeveiligd (F143)','F118':'Bundle-claim klopt niet: index 849 kB (gzip 234) i.p.v. de geclaimde 827 kB','F125':'rebuildworker-e2e timing-flaky (frame-gap-check zelf groen)'}
for k,v in T.items(): F[k]['title']=v
F['F115']['repro']='xvfb-run -a npx electron . --self-test --no-sandbox (zonder GPU; logs/self-test-nogpu.json); ViewPane: zie F143'
F['F126']['repro']='Header van win/regression-0.5.9.txt vergelijken met git log -1 a3bfaf7'
F['F136']['repro']='node tools/neutral-comments.cjs --check (in de repo) en rg -n "reference frame" e2e/'
out = [F[k] for k in sorted(F, key=lambda x: int(x[1:]))] + R.get('extra_new', []) + NEW
out = sorted({f['id']: f for f in out}.values(), key=lambda f: int(f['id'][1:]))
json.dump(out, open('/workspace/phlippo-cad/report-0.5.10/findings.json', 'w'), ensure_ascii=False, indent=1)
from collections import Counter
op = [f for f in out if not f['status'].startswith('Opgelost')]
print(len(out), Counter(f['sev'] for f in op), Counter(f['status'] for f in out))
print('open kritiek:', [f['id'] for f in op if f['sev']=='Kritiek'])
