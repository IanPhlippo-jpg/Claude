import json
D = '/workspace/phlippo-cad/report-0.5.11/'
F = json.load(open(D + 'findings.json')); P = json.load(open(D + 'parity.json')); R = json.load(open(D + 'tools/results-0511.json'))
c = P['counts']; A, De, O, K = c.get('aanwezig', 0), c.get('deels', 0), c.get('ontbreekt', 0), c.get('kapot', 0)
br, rl = R['brep'], R['release']
fx = lambda x, n: (f'**{x[0]}/{x[1]}**, {x[2]} skips' if x else f'nog niet afgerond bij het schrijven (zie `{n}`)')
BR, RL = fx(br, 'logs/regression-brep.log'), fx(rl, 'logs/regression-release.log')
OPENST = ('Deels opgelost', 'Open', 'Niet geverifieerd', 'Nieuw')
op = [f for f in F if f['status'] in OPENST]
from collections import Counter
sv = Counter(f['sev'] for f in op)
krit = [f['id'] for f in op if f['sev'] == 'Kritiek']
B10 = {f['id']: f for f in json.load(open(D + 'findings-0.5.10.json'))}
was = [i for i, f in B10.items() if f['status'] != 'Opgelost']
closed = [i for i in was if next(x for x in F if x['id'] == i)['status'] == 'Opgelost']
withdrawn = [i for i in was if next(x for x in F if x['id'] == i)['status'].startswith('Ingetrokken')]
still = [i for i in was if i not in closed and i not in withdrawn]
new = [f['id'] for f in F if f['status'] == 'Nieuw']
SCORE = '5/10'
T = json.load(open(D + 'logs/qa-team.json'))
TM = {(o['test'], o.get('kernel'), o.get('kind')): o for o in T}
nl = lambda x: f'{x:,.3f}'.replace(',', ' ').replace('.', ',').replace(' ', '.')
naar = open(D + 'tools/naar100.md').read().replace('{PCT}', str(P['pct']).replace('.', ',')).replace('{A}', str(A)).replace('{D}', str(De)).replace('{O}', str(O)).replace('{K}', str(K))
open(D + 'NAAR-100.md', 'w').write(naar)
out = []
w = out.append
w(f'''# QA-rapport Phlippo CAD 0.5.11 — strikte controle tegen SOLIDWORKS

*Opgesteld op 3 november 2026 (Europe/Brussels, UTC+1). Alle cijfers komen uit runs op de QA-box (Linux, xvfb en SwiftShader) of uit bestanden in deze map. Er is niets overgenomen zonder eigen controle. Doel van de opdrachtgever: "echt 100 % halen". Daarom staat er in §11 een volledig plan met acceptatietests (ook als los bestand `NAAR-100.md`).*

## 0. Versie en scope

| | |
|---|---|
| Versie | **0.5.11**, HEAD `db0d4b2` (`db0d4b27d857c42b898bcec68c65240b3fe855e9`, 3-11-2026 02:46 CET), branch `claude/fase1-schetser` |
| Vorige QA | 0.5.10 (`a4b1e92`): score 5/10, strikte pariteit 66,1 %, 70 open bevindingen, 9 Kritiek |
| Delta | 14 commits sinds `a4b1e92` |
| Testomgeving | `git archive HEAD` van de laptop naar `/workspace/phlippo-cad/app-0.5.11`. Node 22 met Playwright-Chromium (SwiftShader) en Electron onder xvfb. De laptop is alleen gelezen. |
| Bewijs | `logs/` (alle runs), `shots/` (screenshots), `win/` (Windows- en Actions-logs van de laptop, zelfrapportage), `tools/` (generatoren en eigen QA-tests in `tools/qa-src/`) |
| Beperking | De boom is een `git archive` (geen echte kloon). Om de e2e-kop te laten werken kreeg de box-kopie een lokale stand-in-commit `dcd49df` (`logs/git-standin.txt`); de box-logs dragen dus "commit dcd49df" en **niet** db0d4b2. Dat de inhoud HEAD db0d4b2 is, blijkt uit `provenance.txt` en de zip-comment (688/688 bestanden). De eerste versie van dit rapport zei ten onrechte "commit unknown" (F180). |
| Revisie | **Herzien na de vijf teamreviews** (`team/strati.md`, `riki.md`, `webi.md`, `risk.md`, `mt5dev.md`). De strengste lezing wint waar het bewijs die steunt; elk teamclaim dat de score raakt is op de box nagemeten (§3.2). |

## 1. Oordeel (executive summary)

**Is het klaar? Nee. En de eerste versie van dit rapport was te gunstig.** Wij schreven dat 0.5.11 "de eerste versie zonder bekende stille geometriefout" was, met 0 Kritiek en 6/10. De teamreview (Strati) vond een stille fout die wij gemist hadden, en wij hebben die op de box gereproduceerd (§3.2):

1. **F177 — Kritiek: stille foute fillet na een maatwijziging.** T3 met de sleuf, daarna basis 80 → 100 mm: B-rep geeft **{nl(TM[('1a','brep',None)]['A_slot_then_stretch']['v'])} mm³** waar 38.422,743 juist is (**+{nl(TM[('1a','brep',None)]['A_slot_then_stretch']['diff'])} mm³ = 55 mm fillet vergeten**). Het lichaam heet "exact", er is geen fout, geen waarschuwing en geen "Faceted". De mesh-kernel maakt precies dezelfde fout, dus de kruiscontrole zwijgt (F179). Met de hand gekozen randen geeft hetzelfde model wél 38.422,743.
2. **F175 — Kritiek: facetten onder het label "exact".** Een ellips 40×20×10 geeft {nl(TM[('1b-ellipse','brep',None)]['v'])} mm³ in plaats van 6.283,185, onder "Exact surfaces (B-rep)", zonder Faceted-cel; de STEP bevat 0 ELLIPSE en {TM[('1b-ellipse','brep',None)]['step']['LINE']} LINE-entiteiten. Splines en de wrap-patch idem. In SOLIDWORKS zijn die vlakken analytisch of NURBS.
3. **F176 — Kritiek (blokkade voor klaar): geen enkele groene CI-run op de release-commit.**

**Wat wél klopt en blijft staan:** T1 (gatrand), T2 en de basis-T3 zijn correct op beide kernels; B-rep is daar exact. Mates markeren de nieuwste conflicterende mate (F141). AutoRecover 21/21, Two/Four View zonder WebGL 35/35. Op de Linux-box: mesh-regressie **98/98**, B-rep **14/14**, release **98/98**, vitest 487/487.

**Correctie op ons eigen werk (F140/F167):** terecht ingetrokken voor 0.5.11; voor 0.5.10 afgeleid, niet gedraaid (§4.2). Daarnaast heeft de teamreview gevonden dat 28 pariteitsrijen naar logs verwezen die hier niet bestaan, dat de herkomstzin fout was en dat onze eigen diagnosetests 0 asserts hebben (F180, F185). Hersteld in deze revisie of als open bevinding opgenomen.

**Lijkt het op SOLIDWORKS?** In werkwijze en uiterlijk sterk. Maar SOLIDWORKS geeft na een maatwijziging nooit stil een ander volume, en een ellips is daar een ellips. Zolang dat hier niet zo is, mag je Mass Properties en STEP van gefillete of gebogen geometrie niet blind vertrouwen.

**Eindscore: {SCORE}** (eerste versie: 6/10; 0.5.10: 5/10). **Strikte pariteit: {str(P['pct']).replace('.', ',')} %** (eerste versie: 75,0 %; 0.5.10: 66,1 %). {len(op)} bevindingen staan open: **{sv.get('Kritiek',0)} Kritiek** ({', '.join(krit)}), {sv.get('Major',0)} Major, {sv.get('Minor',0)} Minor. **GO/NO-GO:** NO-GO voor publiceren of verspreiden. Eigen concept- en hobbywerk: alleen onder de voorwaarden in §9.2.

## 2. Delta sinds 0.5.10 (14 commits)

| Onderwerp | Wat de commits en README zeggen | QA-bevinding |
|---|---|---|
| Fillet op gatrand (F139) | Kettingtolerantie en "Keep features"-hersnede | **Klopt**: mesh-verlies binnen 0,9 % van de gesloten vorm, B-rep exact |
| Wrap exact | Polyhedrale B-rep-tool | **Onjuist label**: lichaam heet "exact", maar de patch is polyhedraal (22 PLANE-vlakken in STEP, F175) |
| Dome exact | Bol-segment | **Klopt** (qaBrep) |
| Kruiscontrole F159 | Exact tegen facet, terugval bij > 0,5 % | Bestaat, maar te ruim (F172) én structureel blind voor gedeelde randfouten (F179) |
| QA-tests in repo | "8 mesh + 13 B-rep" in `src/qa/` | **Klopt** (geteld). TASKS.md noemt nog "(11)" |
| Mates | Nieuwste mate gemarkeerd, Not Converged | **Klopt** (M2, StatusBar.tsx:111) |
| AutoRecover | Eén sleutel per document | **Klopt** (desktop-recover 21/21) |
| Two/Four View | Hoofdrenderer, zonder WebGL opgevangen | **Klopt** (viewpanes 35/35) |
| Namen | Frames, Additional Materials, SW-Density → Density | **Klopt** (Ribbon.tsx:47, persistence.ts:139) |
| CI | Matrix mesh/B-rep/release, één log per pass, skip-budget | Config klopt; op HEAD niet gedraaid |
| Windows | "mesh 98/98, release 98/98, brep 12/12 op 0495219" | Getallen kloppen met `win/*.txt`, maar niet op HEAD (brep op 1fd00e3) |

## 3. Testresultaten (box, echte cijfers)

| Test | Resultaat | Log |
|---|---|---|
| Unit (vitest) | **487/487**, 121 bestanden | logs/vitest.log |
| Typecheck | exit 0 | logs/typecheck.log |
| ci-checks (merken, neutral, budgetten) | ok | logs/ci-checks.log |
| Bundel | 854,86 kB van 860 kB (5,14 kB marge) | logs/build-release.log |
| npm audit | dev-keten 15 moderate, 0 high; productie 0 | logs/audit.json, logs/audit-prod.json |
| Regressie mesh (98 scripts) | **98/98**, 0 skips. drawing 28/28, inventory47 18/18, videos46 25/25, sheetexport 12/12, rebuildworker 10/10 (152 s), features 65/65 (163 s), multibody 14/14 | logs/regression-mesh.log |
| Regressie B-rep (14 scripts, `?kernel=brep`) | {BR} | logs/regression-brep.log |
| Regressie release (98 scripts, `?kernel=brep&rebuild=worker`) | {RL} | logs/regression-release.log |
| Electron self-test zonder GPU | **8/8**: B-rep exact 44858,407; Fillet1 exact 44742,522; STEP exact (23567 B); worker 1143/1143 vertices in 85 ms; atomaire save met .bak | logs/self-test-nogpu.json |
| Electron self-test SwiftShader | **8/8**, zelfde waarden, worker 183 ms | logs/self-test-softgl.json |
| desktop-nohooks (soft GL) | 10/10 | logs/desktop-nohooks-softgl.log |
| desktop-restore-autosave | ok, 4 features hersteld | logs/desktop-autosave.log |
| desktop-recover | **21/21** (F153, F154, F156, F162) | logs/desktop-recover.log |
| viewpanes | 35/35 | logs/viewpanes.log |

**Werkwijze B-rep/release op de box:** de QA-box werd halverwege de B-rep-pass vervangen (node_modules, dist en de Playwright-cache waren weg). Opnieuw `npm ci`, `playwright install chromium` en `build:e2e` (bundel opnieuw 854,77 kB). De B-rep-pass is daarna afgemaakt: 7 scripts vóór de reset (`logs/regression-brep-part1.log`) plus de 7 resterende (`logs/regression-brep-part2.log`). De release-pass liep volledig opnieuw, in 3 parallelle shards (`E2E_SHARD=k/3`, `logs/regression-release-shard{1,2,3}.log`). De gecombineerde DONE-regels staan in `logs/regression-brep.log` en `logs/regression-release.log`. Het enige overgeslagen optionele stapje in de release-pass is sheetexport "PDF in de browserviewer" (Download is starting, binnen het budget van 1).

**Windows-logs vergeleken (win/):** `regression-0.5.11-mesh-win32.txt` geeft DONE 98/98 op `0495219`, `…-release-win32.txt` geeft 98/98 op `0495219`, `…-brep-win32.txt` geeft 12/12 op `1fd00e3`. De getallen kloppen met de claims, maar geen van de drie is van HEAD `db0d4b2`. `desktop-installed-0.5.11.txt` bevat alleen de regel "19/19 checks passed", zonder commit of lijst van checks (F97). `signature-0.5.11.txt` geeft NotSigned voor alle drie de exe's.

### 3.1 Eigen strikte QA-tests (bronnen in tools/qa-src/, log logs/qa-ext-tests.log: 14/14)

CORNER(R) = R²(1−π/4) en RIM_LOSS = CORNER·2π(r + k·R) met k = (10−3π)/(12−3π).

| Test | Kernel | Gemeten | Verwacht | Oordeel |
|---|---|---|---|---|
| T1 gatrand R2, Ø35 | mesh | verlies 97,61 mm³ | 96,80 | ok (+0,8 %, facetten) |
| T1 na Ø50 | mesh | verlies 138,46 | 137,25 | ok (+0,9 %) |
| T1 Ø35 / Ø50 | B-rep | 54282,076 / 44227,798 | formule | **exact** |
| T2 revolve-fillet | mesh | verlies 432,68 | 428,74 | ok (+0,9 %) |
| T2 | B-rep | 100175,033 / 149865,048 | formule | **exact** |
| T3 gesplitste rand z=−40 | mesh | 30439,067 | 30439,911 | ok (−0,8 mm³) |
| T3 gesplitste rand z=−40 | B-rep | 30439,911 | 30439,911 | **exact** |
| T3 rand z=0 (niet gesplitst) | B-rep | 30431,327 | 30500 − 80·CORNER(2) = 30431,327 | **exact** (zie §4.2) |
| M2 conflict | — | nieuwste mate m2 gemarkeerd | m2 | ok (F141) |
| M5 gesloten lus met conflict | — | mAB gemarkeerd, B "over", C "under" | idem | ok |
| E1 circulaire vergelijking | — | gemeld | gemeld | ok |

### 3.2 Teamclaims nagemeten (teamronde, `tools/qa-src/qaTeam.test.ts`, `qaCurved.test.ts`; logs `logs/qa-team.json`, `logs/qa-team-tests.log` 11/11, `logs/qa-curved.log`)

CORNER(2) = 4·(1−π/4) = 0,8584 mm² per mm randlengte.

| # | Test | Kernel | Gemeten | Verwacht | Label / waarschuwing | Oordeel |
|---|---|---|---|---|---|---|
| 1a | T3 + sleuf, daarna basis 80 → 100 (variant A; variant E idem) | B-rep | {nl(TM[('1a','brep',None)]['A_slot_then_stretch']['v'])} | 38500 − 90·C = 38.422,743 | exact, geen fout, geen waarschuwing, geen Faceted | **FOUT, stil (+{nl(TM[('1a','brep',None)]['A_slot_then_stretch']['diff'])}) → F177 Kritiek** |
| 1a | idem | mesh | {nl(TM[('1a','mesh',None)]['A_slot_then_stretch']['v'])} | 38.422,743 (± facet) | Faceted | **zelfde fout** (+{nl(TM[('1a','mesh',None)]['A_slot_then_stretch']['diff'])}) |
| 1a | orakel: zelfde model, stukken 55 + 35 mm met de hand | B-rep | {nl(TM[('1a','brep',None)]['D_oracle_manual']['v'])} | 38.422,743 | exact | ok — de kernel kán het, de randkeuze niet |
| 1a | controles: alleen basis 100 / alleen sleuf | B-rep | 39.914,159 / 30.439,911 | formule | exact | ok |
| 1a | kruiscontrole volumeMismatch(exact, mesh) | — | null | waarschuwing | — | **blind → F179** |
| 1a-b | plaat met R10-boog, scherp | B-rep | 31.785,398 | formule | exact | ok, maar de boogrand = 32 rechte randen van 0,491 mm |
| 1a-b | fillet R2 op de 32 boogsegmenten | B-rep→mesh | verlies 135,498 | 12,881 (Pappus) | waarschuwing "approximate" | **10,5× fout → F178** |
| 1a-b | sleuf vóór fillet op 32 segmenten | B-rep | geen resultaat na > 10 min | — | — | hang, afgebroken, niet geïsoleerd |
| 1b | ellips 40×20, extrude 10 | B-rep | {nl(TM[('1b-ellipse','brep',None)]['v'])} | 6.283,185 | exact, "Exact surfaces (B-rep)", geen waarschuwing; STEP 0 ELLIPSE, {TM[('1b-ellipse','brep',None)]['step']['LINE']} LINE, {TM[('1b-ellipse','brep',None)]['step']['PLANE']} PLANE | **facet onder exact → F175 Kritiek** |
| 1b | ellips | mesh | {nl(TM[('1b-ellipse','mesh',None)]['v'])} | 6.283,185 | Faceted | eerlijk gelabeld |
| 1b | cirkel Ø20 (controle) | B-rep | 3.141,593 | 3.141,593 | exact, STEP 1 CYLINDRICAL_SURFACE | ok |
| 1b | spline-profiel | B-rep | 2.943,781 | — | exact; STEP 0 B_SPLINE, {TM[('1b-spline',None,None)]['step']['LINE']} LINE | **facet onder exact → F175** |
| 1c | wrap emboss 2 mm op R20-rol | B-rep | {nl(TM[('1c-wrap',None,'emboss')]['v'])} | {nl(TM[('1c-wrap',None,'emboss')]['expected'])} | exact, geen waarschuwing; STEP {TM[('1c-wrap',None,'emboss')]['step']['PLANE']} PLANE | **polyhedraal onder exact → F175** |
| 1c | wrap deboss | B-rep | {nl(TM[('1c-wrap',None,'deboss')]['v'])} | {nl(TM[('1c-wrap',None,'deboss')]['expected'])} | idem | idem |
| 1d | asserts in onze QA-tests (`rg -c "expect\\("`) | — | qaBrep 0, qaDiag 0, qaT3diag 0, qaTeam 0, qaCurved 0, qaStrict 20 | — | — | **F185** |
| 1d | B-T3 (`qaBrep.test.ts:56-68`) randkeuze | — | eerste 80 mm-rand = z=0 | z=−40 | — | **RISK-08 bevestigd** |

Code-claims van het team ook zelf gecontroleerd: `volumeCheck.test.ts:9` (F198), `rebuild.ts:1600-1604` (F197), `ci.yml:137` 12 scripts (F183), 0× `IGESControl_Writer` in de meegeleverde OCCT (F199), `recover.cjs:27-29` (F188), `mateStatus.ts:124-128` (F186), `rebuild.ts:858-864` (F51).

## 4. Claimcontrole

### 4.1 Onjuiste of onbewezen claims

| Claim | Waar | Oordeel |
|---|---|---|
| "Linux: checks en desktop groen" | README.md, win/linux/README.md | **Onbewezen**: er staan geen ruwe logs van de checks- en desktop-jobs in `win/linux/`, alleen regressieshards (F149) |
| "qaBrep.test.ts (11)" | TASKS.md (P0/P1-regel) | **Onjuist**: het zijn er 13. README zegt terecht 13 (F129) |
| F142 "alleen .gitignore" | docs/28 | **Verouderd**: graphify-out is echt uit de index (TASKS klopt) |
| "release 0.5.11 gebouwd en geïnstalleerd (19/19)" | TASKS.md:834 | **Zwak bewijs**: het log is één regel zonder commit of checks (F97) |
| "Regressie Windows op 0495219 (mesh 98/98, release 98/98, brep 12/12)" | TASKS.md:834 | Getallen kloppen, maar brep draaide op `1fd00e3` en niets op HEAD (F176) |
| "Wrap op een exact lichaam houdt het lichaam exact" | README | **Deels**: het lichaam blijft exact, de patch is polyhedraal |
| "elk lichaam krijgt een kruiscontrole" | README | Klopt, maar met 0,5 % is die te grof om fillet-fouten te vangen (F172) |
| "Exact surfaces (B-rep)" / Faceted-cel | UI, README | **Onjuist** voor ellips, spline en wrap-patch (F175, §3.2) |
| Overige claims (F139, F141, F143, F144–F146, F153–F158, F160, F162–F166, Frames) | commits, TASKS, docs/28 | **Klopt**, zelf nagemeten (§3) |

### 4.2 Ingetrokken: F140 en F167 (fout in onze test)

De 0.5.10-test `B-T3` koos de te fillen rand met `edges.reduce((a, b) => len(b) > len(a) ? b : a)`. Bij gelijke lengte (80 mm) blijft dan de eerste rand staan. Onder de mesh-kernel was dat de rand op z=−40, die de sleuf in twee stukken snijdt. Onder de B-rep-kernel was het de rand op z=0, die de sleuf niet raakt. De diagnose (`tools/qa-src/qaT3diag.test.ts`, `logs/qa-t3diag.log`):

- rand z=0 in B-rep: 30431,327 mm³ = 30500 − 80·CORNER(2), verschil 0;
- rand z=−40 in B-rep, sleuf in twee richtingen en gewone sleuf: 30439,911 mm³ = 30500 − 70·CORNER(2), verschil 0;
- rand z=−40 in mesh: 30439,067 mm³ (−0,8 mm³, facetten).

**Formulering na teamreview: terecht ingetrokken voor 0.5.11; voor 0.5.10 afgeleid, niet gedraaid.** Voor 0.5.11 is gemeten dat het programma op beide randen het juiste doet. Dat het in 0.5.10 al zo was, leiden we af: op 0.5.10 zelf konden we de diagnose niet opnieuw draaien, omdat `app-0.5.10/node_modules` geen vite bevat (`logs/qa-t3diag-on-0.5.10.log`). De 0.5.10-waarde 30431,327 is wel exact de waarde voor de z=0-rand. **Les voor QA:** kies randen op positie, niet met een `reduce` op lengte.

## 5. Pariteitsmatrix (62 rijen)

Weging: aanwezig = 1, deels = 0,5, ontbreekt/kapot = 0. **{A} aanwezig, {De} deels, {O} ontbreekt, {K} kapot: {str(P['pct']).replace('.', ',')} %** (eerste versie 0.5.11: 75,0 %; 0.5.10: 66,1 %).\n\n**Strikte hertelling na teamreview.** Elke verlaging die een reviewer met bewijs voorstelde, is overgenomen (unie), en alleen als ons eigen boxbewijs of de code die steunt. Strati en Riki kwamen op 71,8 %, Webi op 73,4 %, MT5D en Risk op 74,2 %; de unie is {str(P['pct']).replace('.', ',')} %.\n\n| Rij | Was | Nu | Waarom (bewijs) |\n|---|---|---|---|\n| 11 Fillet/Chamfer | aanwezig | deels | F177 stil fout na maatwijziging; F178 gebogen rand 10× fout; face fillet/full round alleen mesh (Strati, Riki, §3.2) |\n| 30 Exacte B-rep op desktop | aanwezig | deels | ellips/spline/wrap facet onder exact (F175); self-test niet packaged (Strati, Riki, Risk, Webi) |\n| 49 STEP | aanwezig | deels | \"exacte\" STEP van een ellips = {TM[('1b-ellipse','brep',None)]['step']['LINE']} LINE, 0 ELLIPSE (Riki, MT5D, §3.2) |\n| 55 Handelsmerk-vrij | aanwezig | deels | geen juridische toets; docs/26 en docs/06 (Strati, Risk; F189) |\n| 61 Unit + e2e + B-rep + worker | aanwezig | deels | alleen box, één run, CI-brep 12/14, QA-tests zonder asserts (Strati, Webi; F183–F185) |\n| 62 CI | deels | ontbreekt | 0 groene runs op HEAD; laatste runs rood op andere commits (Riki; F176, F195) |\n| 56 Performance | deels | deels | bewijs ververst met 0.5.11-cijfers (was 0.5.10, MT5D-17) |\n| 59 Installer | deels | deels | blijft deels: packaged self-test ontbreekt (F151), los van signing |\n\nDaarnaast wezen **28 rijen** naar logs die in deze map niet bestaan (`logs/regression.log`, `regression-rerun.log`, `qa-strict-tests.log`, `qa-brep-tests.log`, \"vitest 454/454\"). Die verwijzingen zijn nu vervangen door de echte 0.5.11-logs (`regression-mesh.log`, `qa-ext-tests.log`, vitest 487/487); een script controleert dat elk genoemd log bestaat (0 missend). Rijen waarvoor een SOLIDWORKS-referentie nodig is om "aanwezig" te worden: {', '.join(map(str, P['sw_ref_nodig']))}.

| # | Gebied | Onderdeel | 0.5.10 | 0.5.11 | Bewijs |
|---|---|---|---|---|---|''')
for i, r in enumerate(P['rows'], 1):
    ch = ' **↑**' if r['old'] != r['status'] else ''
    w(f"| {i} | {r['area']} | {r['item']} | {r['old']} | {r['status']}{ch} | {r['ev'].replace('|', '/')} |")
w(f'''
## 6. Alle bevindingen

Totaal {len(F)} (F1–F199; F177–F199 komen uit de teamreview, met de originele team-ID's als alias tussen haken). Van de 70 bevindingen die in 0.5.10 open stonden zijn er **{len(closed)} opgelost**, **{len(withdrawn)} ingetrokken** (F140, F167) en **{len(still)} nog open**. Nieuw: **{len(new)}** ({', '.join(new)}). Open per ernst: **Kritiek {sv.get('Kritiek',0)}**{(' (' + ', '.join(krit) + ')') if krit else ''}, Major {sv.get('Major',0)}, Minor {sv.get('Minor',0)}.

Opgelost in 0.5.11: {', '.join(closed)}.

### 6.1 Overzicht open bevindingen

| ID | Ernst | Status | Prio | Gebied | Titel |
|---|---|---|---|---|---|''')
po = {'P0': 0, 'P1': 1, 'P2': 2, 'P3': 3}
so = {'Kritiek': 0, 'Major': 1, 'Minor': 2}
op.sort(key=lambda f: (po.get(f['prio'], 9), so.get(f['sev'], 9), int(f['id'][1:])))
for f in op: w(f"| {f['id']} | {f['sev']} | {f['status']} | {f['prio']} | {f['area']} | {f['title']} |")
w('\n### 6.2 Details open bevindingen\n')
for f in op:
    w(f"#### {f['id']} · {f['sev']} · {f['status']} · {f['prio']} · {f['area']} — {f['title']}\n")
    w(f"- **Bewijs:** {f['ev']}\n- **Reproductie:** {f.get('repro','')}\n- **Fix:** {f.get('fix','')}\n")
w('### 6.3 Opgelost of ingetrokken in deze ronde\n\n| ID | Was | Nu | Bewijs 0.5.11 |\n|---|---|---|---|')
for i in closed + withdrawn:
    f = next(x for x in F if x['id'] == i)
    w(f"| {i} | {f['old']} | {f['status']} | {f['ev'].split(' || ')[0].replace('0.5.11: ', '').replace('|', '/')} |")
w(f'''
## 7. Risico's

1. **Stille foute geometrie onder het label "exact"** (F177, F175). De gebruiker krijgt geen enkel signaal; Mass Properties, STEP en verdere bewerkingen zijn fout. Dit is precies wat SOLIDWORKS nooit doet.
2. **De vangnetten zien gedeelde fouten niet** (F179, F198): beide kernels delen de randkeuze en een unit-test legt de blindheid vast.
3. **Gebogen randen** (F178): 32 segmenten, mesh-terugval, ±10× fout verlies; één combinatie hing > 10 min.
4. **Bewijs alleen op de QA-box, op een stand-in-commit** (F176, F180, F190): geen groene CI, geen Windows-job, geen echte kloon.
5. **Stabiliteit onbewezen** (F184, F145, F195): elke pass één run; multibody rood in Actions.
6. **Gegevens** (F188): AutoRecover-kopieën van 0.5.10 worden mogelijk niet aangeboden.
7. **Juridisch** (F189): SW-documentatie in de repo; pixel-overlay-plan; geen EULA. Niet publiceren vóór opschoning en toets.
8. **Ongesigneerde installer** (F49): SmartScreen; niet geschikt voor verspreiding.

## 8. Score

### 8.1 QA-score

| Criterium | 0.5.10 | 0.5.11 eerste versie | 0.5.11 herzien | Waarom |
|---|---|---|---|---|
| Correcte geometrie | 4 | 7 | **4** | T1–T3 basis correct, maar stil fout na maatwijziging (F177) en facetten onder "exact" (F175); gebogen rand 10× fout (F178) |
| Functionele pariteit | 6 | 7 | **6** | {str(P['pct']).replace('.', ',')} % strikt |
| Bewijs/claims | 4 | 6 | **4** | Stand-in-commit, foute herkomstzin, 28 dode logverwijzingen, niets groen op HEAD buiten de box |
| Tests | 5 | 7 | **5** | 487 unit en 98/98 op de box, maar kruiscontrole blind, CI-brep 12/14, QA-diagnose zonder asserts, geen herhalingen |
| Release-klaar | 3 | 4 | **3** | Ongesigneerd, geen CI, geen Windows-job |
| **Totaal** | **5/10** | 6/10 | **{SCORE}** | Gemiddelde 4,4; naar boven afgerond omdat de basis-T1–T3 en de regressie echt verbeterd zijn. Geen 6 met 3 Kritiek open |

### 8.2 Teamscores

| Reviewer | Focus | Score | Pariteit | Belangrijkste punt |
|---|---|---|---|---|
| Strati | geometrie, strategie | 5/10 | 71,8 % | STRATI-01: stille foute fillet na maatwijziging (bevestigd, F177) |
| Riki | regressie, bewijs | 6/10 | 71,8 % | logs en herkomst niet sluitend; CI-brep 12/14 (F180, F183) |
| Risk | risico, gegevens, juridisch | 6/10 | 74,2 % | P0-2-drempel geeft valse alarmen; AutoRecover 0.5.10; juridische grens (F172, F188, F189) |
| Webi | UI/UX, CI | 5,5/10 | 73,4 % | extra views niet interactief; multibody rood in Actions (F192, F195) |
| MT5D | code, kernel | 5/10 | 74,2 % | volumeCheck.test.ts:9; flange gemaskeerd; geen IGES-writer (F197–F199) |
| **QA herzien** | alles | **{SCORE}** | **{str(P['pct']).replace('.', ',')} %** | strengste lezing met boxbewijs |

## 9. Wat nu

### 9.1 P0 — eerst (zie §11, fase F0)

1. **Eerlijk label, interim:** ellips/spline/wrap-patch en fillets op gesplitste/gebogen referenties `exact:false` + waarschuwing (F175, F177, F178).
2. **STRATI-01 repareren:** gesplitste referentie = alle stukken; waarschuwen bij een keuze uit meerdere kandidaten (F177).
3. **Kruiscontrole per feature, onafhankelijk van `matchEdges`,** met volume, oppervlak, zwaartepunt, bbox en face/edge-aantallen en een tessellatie-bewuste drempel (F172, F179); `volumeCheck.test.ts:9` omkeren (F198).
4. **Groene Actions-run op de release-commit vanuit een echte git-kloon,** CI-brep 14/14, plus een Windows-job (F176, F183, F190).
5. **QA-tests met asserts en randkeuze op positie;** herhaalde runs (N ≥ 10) en mutatietests (F185, F184).

### 9.2 Voorwaarden voor eigen gebruik (geconsolideerd uit Risk 1–6 en Strati)

Eigen concept- en hobbywerk kan, **mits**:
1. **Mass Properties opnieuw controleren** na een fillet of chamfer op een gesplitste of gebogen rand, en na elk invoegen van een feature vóór een fillet of elke maatwijziging daarvóór. Vergelijk met een handberekening of herselecteer de randen (F177, F178).
2. **Ellipsen, splines en wrap-patches zijn niet exact**, ook als er "Exact" staat. Niet gebruiken voor maatkritische delen of STEP naar derden (F175).
3. **Face fillet, full round, setback en plastics gaan via mesh** (F51); let op de **Faceted**-cel in de statusbalk en de waarschuwingen in de boom.
4. **Vaak Ctrl+S**; AutoRecover is goed, maar niet je enige kopie.
5. **Crashkopieën van 0.5.10 eerst in 0.5.10 openen** en opslaan, vóór je overstapt (F188).
6. Niet verspreiden: ongesigneerde installer, geen CI-bewijs (F49, F176).
7. STEP-export van gefillete of gebogen geometrie in een tweede CAD-pakket nameten vóór gebruik.

### 9.3 Besluiten voor Ian

Zie §11 (NAAR-100 §6): B1 rij 37 en 54 herdefiniëren; B2 DWG/Parasolid betalen of buiten scope; B3 code-signing; B4 SOLIDWORKS-licentie voor R0; B5 repo publiek maken (pas na de juridische opschoning, NAAR-100 §7).

## 10. Bijlagen

`findings.json` ({len(F)} bevindingen), `parity.json` (62 rijen, met `team_pct` en `log_refs_hersteld`), `NAAR-100.md`, `team/` (vijf reviews), `logs/` (o.a. `qa-team.json`, `qa-team-tests.log`, `qa-curved.log`), `shots/`, `tools/` (generatoren `build_findings_0511.py`, `parity_0511.py`, `team_0511.py`, `mkreport_0511.py`; QA-bronnen `tools/qa-src/`; eerste versies `naar100-v1.md`, `mkreport_0511-v1.py`), `win/`, `provenance.txt`.

## 11. Weg naar 100%
''')
import re as _re
w(_re.sub(r'(?m)^(#{2,3}) ', lambda m: '#' + m.group(1) + ' ', naar.split('\n', 2)[2]))
open(D + 'QA-rapport-0.5.11.md', 'w').write('\n'.join(out))
print('ok', SCORE, len(op), dict(sv), krit, len(closed), len(withdrawn), len(still), new)
