# Teamronde 0.5.10: verwerkt de 5 reviews (team/strati.md, riki.md, webi.md, risk.md, mt5dev.md) in findings.json.
# Regel: de strengste ernst wint. Elke wijziging krijgt een 'team'-veld (wie wilde wat); nieuwe bevindingen een 'alias'-veld.
import json
D = '/workspace/phlippo-cad/report-0.5.10/'
L = json.load(open(D + 'findings.json')); F = {f['id']: f for f in L}
def ch(i, team, sev=None, status=None, prio=None, title=None, add=None, fix=None, repro=None):
    f = F[i]
    if sev and sev != f['sev']: f['sev_qa'] = f['sev']; f['sev'] = sev
    if status and status != f['status']: f['status_qa'] = f['status']; f['status'] = status
    if prio: f['prio'] = prio
    if title: f['title'] = title
    if add:
        cur, sep, hist = f['ev'].partition(' || ')
        f['ev'] = cur + ' Teamronde: ' + add + (sep + hist if sep else '')
    if fix: f['fix'] = fix
    if repro: f['repro'] = repro
    f['team'] = team
# --- ernstcorrecties (strengste wint) ---
ch('F139', 'Kritiek volgens Strati, Riki, Webi, Risk en MT5 Dev (unaniem); QA had Major', sev='Kritiek', prio='P0',
   add='Ø35 (r=17,5): verlies −34,85 mm³ met errors {} en géén waarschuwing (logs/qa-diag.log:1). Stil fout volume = Kritiek volgens §11.')
ch('F31', 'Kritiek volgens Strati, Webi en MT5 Dev; Major volgens QA, Riki en Risk (Risk: "wie F147 niet apart boekt, moet F31 Kritiek houden"). Strengste wint: Kritiek', sev='Kritiek', prio='P0',
   add='CI bewijst niets zolang mesh rood is: één run-stap met bash -e (ci.yml:38-46, F147); logs/regression-rerun.log EXIT=1; geen Actions-run.')
ch('F54', 'Kritiek volgens MT5 Dev (P0 die "klaar" blokkeert = Kritiek volgens §11); QA had Major', sev='Kritiek', prio='P0')
ch('F50', 'Kritiek volgens Strati; Major volgens QA, Riki, Webi, Risk en MT5 Dev. Strengste wint: Kritiek. Alle reviewers: blokkeert publiceren, niet eigen gebruik', sev='Kritiek', prio='P1',
   add='"Weldments" 29× in src (rg -o Weldments src), 0× in tools/rename-trademarks.cjs; "Sustainability Extras" (materials.ts:124/140); docs/26 legt een 1-op-1-pass tegen SOLIDWORKS-frames vast (docs/26-zelfcontrole-1op1.md:1-5).')
ch('F111', 'Kritiek volgens Strati en MT5 Dev ("of sluiten en onderbrengen in F140"); Major volgens QA, Riki en Risk (alleen zolang F140 Kritiek blijft). Strengste wint: Kritiek', sev='Kritiek', prio='P0',
   add='Het symptoom (stil fout bij een gesplitste rand) zit in de releasekernel; de gebruiker ziet F140.')
ch('F105', 'Kritiek volgens Strati; QA had Major. MT5 Dev: deels, in CI onbereikbaar bij rode mesh-pass', sev='Kritiek', prio='P0',
   add='Release = B-rep (prefs.ts:21, brepRefine.ts:25-38: true buiten TEST_HOOKS), maar de e2e-build draait mesh; in CI draaien de 12 B-rep-scripts (ci.yml:44) alleen als de mesh-pass groen is (F147). F140 wordt door de B-rep-pass niet gevangen.')
ch('F145', 'Major volgens Riki en MT5 Dev (en Risk bij herhaling); QA had Minor', sev='Major', prio='P1',
   title='features-script niet-deterministisch: Sweep1 "path sketch has no lines" met volgfouten (oorzaak niet geverifieerd)',
   add='Sweep1-fout "The path sketch has no lines, arcs or splines to sweep along." met volgfouten in Imported1, equations, Extrude-Thin1 (logs/regression.log:3). App- of testrace: niet geverifieerd.')
ch('F125', 'Major volgens MT5 Dev (rebuildworker rood in de standaardrun); QA had Minor', sev='Major', prio='P2',
   add='logs/regression.log: rebuildworker exit=1 219 s TimeoutError in de standaardrun.')
ch('F143', 'Major volgens QA en alle reviewers; Riki: ernstiger dan gedacht', prio='P1',
   add='De enige ErrorBoundary staat rond de hele app (src/main.tsx:25-28), dus een throw in ViewPane legt de hele UI plat (statisch, niet runtime gereproduceerd).')
ch('F140', 'Kritiek volgens QA en alle vijf reviewers (unaniem)',
   add='Formule: 8,584 mm³ = 10 mm · R²·(1−π/4) bij R = 2 (logs/qa-brep-tests.log). Welke rand extra wordt afgerond, is niet geverifieerd; zie F167 voor de oorzaak en F159 voor de ontbrekende kruiscontrole.',
   fix='Eerst diagnose (F167): mesh- en OCCT-randen loggen; QA-T3 als B-rep-unit-test die 30439,91 ± 0,01 mm³ eist; daarna de matcher repareren. Intussen volume-kruiscontrole (F159).')
# --- heropend (strengste wint) ---
ch('F120', 'Deels opgelost volgens Strati en MT5 Dev: de lijst klopt, maar de stap wordt in CI niet bereikt; QA had Opgelost', status='Deels opgelost', prio='P1',
   add='ci.yml:44 heeft 12 scripts, maar die regel draait niet zolang ci.yml:42 rood is (F147).')
ch('F97', 'Deels opgelost volgens MT5 Dev (self-test niet gepackaged); QA had Opgelost. Ernst Kritiek → Major (QA): app:// + WASM zijn bewezen, alleen de packaging-laag niet', status='Deels opgelost', sev='Major', prio='P2',
   add='logs/self-test-nogpu.json:3 en self-test-softgl.json:3: "packaged": false. Een packaged (geïnstalleerde) self-test van 0.5.10 is er niet (F151).')
ch('F134', 'Deels opgelost volgens MT5 Dev (caps, geen doelen; geen splitsplan); QA had Opgelost', status='Deels opgelost', prio='P3',
   add='logs/ci-checks.log: "rebuild.ts … above the goal of 1000"; caps op grootte+1 (tools/line-budget.cjs:13-22).')
ch('F119', 'Deels heropend volgens Webi en Risk: skips worden geteld maar laten een run nooit falen (F155); QA had Opgelost', status='Deels opgelost', prio='P1')
ch('F122', 'Deels volgens Webi en Risk: alleen unit-tests, geen e2e; verborgen lijnen in geen enkele shot; centermarks ontbreken in Detail B van shots/deurkruk-tekening.png; QA had Opgelost', status='Deels opgelost', prio='P2')
ch('F99', 'Deels volgens Strati: geen test op data-exact / status "Faceted"; MT5 Dev: opgelost. Strengste wint', status='Deels opgelost', prio='P3',
   add='Indicator bestaat (StatusBar.tsx:224 "Faceted n/m"), maar geen test die de indicator of data-exact controleert.')
# --- bewijscorrecties ---
ch('F118', 'Strati, Riki, Risk, MT5 Dev: "827 kB" is een verouderde 0.5.2-claim, niet onwaar; Webi: stale. Ernst blijft Minor',
   title='Bundel weer gegroeid zonder budget: index 849 kB tegen 827 kB in de 0.5.2-claim (claim verouderd)',
   add='Correctie: de claim "919 → 827 kB" staat in TASKS.md:763 (0.5.2) en docs/25:30; het is geen 0.5.10-claim en dus verouderd, niet "onwaar". Strati bouwde 46a1bd9 zelf: 826,66 kB (niet door QA herhaald). Nu 849,37 kB (logs/build-release.log:50): +22,7 kB zonder budget.',
   fix='Bundelbudget in CI (bijv. index ≤ 830 kB) en de claim bij elke release opnieuw meten.')
ch('F126', 'Strati, Webi, Riki: QA-tekst was fout ("round2b bevat maar 6 scripts")',
   add='Correctie: win/regression-round2b.log bevat niet 6 scripts. Regels 1-99 zijn byte-identiek aan regels 2-100 van win/regression-0.5.9.txt (diff, geen verschil), plus B-rep 12/12 (r.112) en worker 6/6 (r.119). Zie F148.')
ch('F93', 'Kritiek volgens QA en alle reviewers',
   add='Het Windows-98/98-log (win/regression-0.5.9.txt, gestart 22:03:47 CET) bevat round2.mjs (r.99), dat pas in a3bfaf7 (22:48:35 CET) is toegevoegd: het draaide dus op een niet-gecommitte 0.5.10-werkboom met package-versie 0.5.9. Gelijkheid met de release: niet geverifieerd. TASKS.md:814 claimt "release 0.5.10 geïnstalleerd (19/19)" zonder log (F149).')
for i in ('F49', 'F117'):
    ch(i, 'Major volgens QA en alle reviewers; NotSigned op 2-11 opnieuw gemeten (F150)',
       add='Opnieuw gemeten op 2-11 (alleen lezen): geïnstalleerde exe, Setup-0.5.10.exe, portable en win-unpacked alle vier NotSigned (win/signature-0.5.10.txt).')
ch('F51', 'Kritiek volgens QA en alle reviewers',
   add='Correctie: de shot "Faceted 1/1" (shots/walk-18-done.png) komt uit de e2e-build (TEST_HOOKS → mesh, brepRefine.ts:29-35). Een gewone browserbuild zet B-rep aan (brepRefine.ts:37); of de OCCT-worker in de browserrelease echt draait: niet geverifieerd. F51 blijft Kritiek om de plastics (alleen mesh) en de mesh-terugval/preview/worker (F139).')
# --- nieuwe bevindingen, ontdubbeld, F147+ ---
def N(i, area, sev, prio, title, alias, ev, fix, repro='–', status='Nieuw'):
    L.append(dict(id=i, area=area, sev=sev, old='—', title=title, status=status, prio=prio, ev=ev, repro=repro, fix=fix, alias=alias, team='Nieuw in de teamronde; ' + alias))
N('F147', 'Testen/CI', 'Major', 'P0', 'CI: mesh-, B-rep- en worker-regressie in één run-stap met bash -e; B-rep en worker draaien nooit zolang mesh rood is',
  'Strati F148, Riki F147, Risk F148, MT5 Dev F147',
  'Geverifieerd: .github/workflows/ci.yml:38-46 is één `run:`-blok zonder continue-on-error; run-regression.mjs eindigt met exit 1 bij rood; mesh is lokaal reproduceerbaar rood (logs/regression-rerun.log). Ook "git diff --exit-code" en de eindgate van de desktopchecks (ci.yml:48-51) worden dan niet bereikt. README.md:90 "De CI draait … een B-rep-pass" is daardoor bij een rode mesh-pass feitelijk onwaar.',
  'Drie aparte stappen met id en continue-on-error, plus een eindstap die alle uitkomsten controleert (zoals nohooks/selftest).', repro='sed -n 38,46p .github/workflows/ci.yml')
N('F148', 'Bewijs/claims', 'Major', 'P1', 'Windows-log round2b is een kopie van het 0.5.9-log; het 98/98-log draaide op een niet-gecommitte werkboom',
  'Strati F147, Webi F147, Riki F149a/b',
  'Geverifieerd: regels 1-99 van win/regression-round2b.log zijn byte-identiek aan regels 2-100 van win/regression-0.5.9.txt. Dat log start 2026-10-30 22:03:47 CET (kop "regression 0.5.9"), 45 min vóór a3bfaf7 (22:48:35 CET), en bevat round2.mjs (r.99), dat pas in a3bfaf7 werd toegevoegd (git log --diff-filter=A).',
  'Per release één ruw log met commit-hash en versie in de kop; nooit logs samenplakken.', repro='diff <(sed -n 1,99p win/regression-round2b.log) <(sed -n 2,100p win/regression-0.5.9.txt)')
N('F149', 'Bewijs/claims', 'Major', 'P1', 'Claims zonder platform of log: 98/98 zonder "Windows", "CI draait B-rep-pass", "0.5.10 geïnstalleerd (19/19)"',
  'Riki F148, Strati F152, Webi (19/19), Risk §4.5',
  'Geverifieerd: TASKS.md:810 en commit a3bfaf7 noemen 98/98 / B-rep 12/12 / worker 6/6 zonder platform, terwijl eerdere commits "Windows" vermeldden; README.md:55-56 zegt dat de cijfers Windows-cijfers zijn. README.md:90 claimt een CI-B-rep-pass (zie F147). TASKS.md:814 claimt "release 0.5.10 geïnstalleerd (19/19)" zonder enig log; QA schreef eerder ten onrechte "niet voor 0.5.10 geclaimd".',
  'Elke claim met platform, commit en pad naar het ruwe log.')
N('F150', 'Release', 'Major', 'P2', 'Build-log meldt "signing with signtool.exe", maar alle 0.5.10-binaries zijn NotSigned',
  'Strati F153, Risk F154, MT5 Dev F151',
  'Geverifieerd: win/desktop-build.log:67-74 (5× "signing with signtool.exe"); Get-AuthenticodeSignature op 2-11 (alleen lezen): installed exe, Setup, portable en win-unpacked NotSigned (win/signature-0.5.10.txt). Het build-log wekt dus een valse indruk; package.json heeft geen certificaatconfiguratie (MT5 Dev).',
  'forceCodeSigning of een expliciete "unsigned"-melding in de build; de AuthenticodeSignature-uitvoer bij elke release in win/ bewaren.')
N('F151', 'Testen/CI', 'Minor', 'P2', 'Self-tests draaien ongepackaged (packaged:false) en met SwiftShader: geen installer-test en geen echte no-WebGL-test',
  'Strati F154, Riki F151, MT5 Dev (MT5D-06/F97)',
  'Geverifieerd: logs/self-test-nogpu.json:3 en logs/self-test-softgl.json:3 "packaged": false. "Zonder GPU" betekent hier software-GL, niet geen WebGL.',
  'Self-test ook op de geïnstalleerde exe draaien (Windows) en één run met WebGL echt uit.')
N('F152', 'Testen/CI', 'Major', 'P1', 'De strikte QA-tests (T1/T3/M1-M5) staan buiten de repo; geen gate vangt F139/F140',
  'Strati F155 (vervolg F130 / team-N8)',
  'Geverifieerd: tools/qa-src/ staat alleen in de QA-map; src/qa is na de run uit de kloon verwijderd (git status schoon). F139 en F140 zijn alleen door deze tests gevonden.',
  'qaStrict/qaBrep in de repo opnemen als vitest-suite (T3 B-rep: 30439,91 ± 0,01).')
N('F153', 'Dataverlies', 'Major', 'P1', 'AutoRecover heeft alleen de documentnaam als sleutel: documenten met dezelfde naam overschrijven en wissen elkaars kopie',
  'Risk F150',
  'Geverifieerd: electron/main.cjs:342 recoverFile(name) = gesaneerde naam (80 tekens) + .autorecover.kcad; recover:remove (main.cjs:381-384) wist op naam; volgens Risk wordt alleen het actieve document geschreven (autoRecover.ts:42-60) en wist MenuBar.tsx:75 na opslaan op naam (niet regel voor regel door QA nagelezen).',
  'Sleutel op pad of document-id; alle dirty documenten schrijven.')
N('F154', 'Dataverlies', 'Major', 'P1', 'Herstelde AutoRecover-kopie opent als "opgeslagen" (dirty:false), zonder fsync en zonder e2e-test',
  'Risk F151 (Riki: desktop-restore-autosave niet in CI)',
  'Geverifieerd: slices/document.ts:87 zet dirty:false bij openen; recover:write (main.cjs:344-357) doet tmp+rename zonder fsync, anders dan atomicWrite (main.cjs:123-130); e2e/desktop-restore-autosave.mjs bestaat maar staat niet in ci.yml.',
  'Herstel openen als dirty met "(Recovered)" in de titel, fsync toevoegen, e2e-test in CI.')
N('F155', 'Testen/CI', 'Major', 'P1', 'skip() telt als groen: ~120 optionele stappen kunnen overslaan zonder dat een run faalt',
  'Webi F149, Risk F153 (heropent F119 deels)',
  'Geverifieerd: e2e/lib/check.mjs:35 skip() logt en geeft een waarde terug, de exitcode (:29) houdt er geen rekening mee; rg telt 122 skip(-aanroepen in e2e (Risk: 53 → 121 sinds 0.5.1). Webi noemt 7 skips die klikfouten slikken (o.a. full:322, configurations:173, brep:102, bodies:64, inventory47:171/197, sheetexport:72).',
  'Skipbudget per script; het aantal skips in de eindgate opnemen; klik-timeouts nooit als optioneel behandelen.')
N('F156', 'Security', 'Major', 'P2', 'recover:*-IPC accepteert een door de renderer gekozen map (met %ENV%-expansie)',
  'Webi F148',
  'Geverifieerd: main.cjs:338-341 recoverDir(folder) breidt %VAR% uit en accepteert elk absoluut pad; recover:write maakt die map aan (mkdir recursive) en schrijft daar *.autorecover.kcad. Dat breekt de regel uit main.cjs (alleen bekende handles/paden). Wel beperkt tot de eigen bestandsextensie.',
  'Map in main vastleggen (userData/backup of een via dialoog gekozen en bewaarde map); de renderer stuurt geen pad mee.')
N('F157', 'Weergave', 'Major', 'P2', 'Two/Four View: de extra vensters hebben geen studio-omgeving, modellen worden zwarte silhouetten',
  'Webi F150',
  'Geverifieerd: ViewPane.tsx:20 maakt een eigen WebGLRenderer zonder makeStudioEnvironment (alleen glSetup.ts:23 roept het aan); shots/m7-fourview.png: Front/Top/Right donkergrijs zonder randen, alleen Isometric normaal.',
  'ViewPane via createRenderer (glSetup.ts) laten lopen; dat lost ook F143 op.')
N('F158', 'Testen/CI', 'Major', 'P1', 'De release rebuildt in de worker, maar de regressie draait standaard op de UI-thread',
  'Webi F151',
  'Geverifieerd: prefs.ts:21 perf.rebuildWorker=true in de release; de e2e-build gebruikt de worker alleen met ?rebuild=worker (worker-pass 6 scripts, 5/6 lokaal, logs/regression-worker.log). Het verzonden pad heeft dus de kleinste dekking.',
  'Hoofdregressie op het releasepad (worker + B-rep), mesh/UI-thread als extra pass.')
N('F159', 'Kernel', 'Major', 'P0', 'B-rep-resultaat vervangt het mesh-resultaat zonder volume-kruiscontrole; mesh-waarschuwingen van exacte bodies worden weggegooid',
  'Risk F147',
  'Geverifieerd: src/app/brepRefine.ts:51-70 refinedResult wisselt exacte bodies in zonder vergelijking met het mesh-volume; waarschuwingen blijven alleen voor facet-bodies (:67-69). Daardoor blijft F140 stil.',
  'Bij |V_exact − V_mesh|/V > 0,5 %: melding "exact en facet wijken af" en de feature markeren.')
N('F160', 'Testen/CI', 'Major', 'P1', 'Regressielog per pass overschreven: B-rep-bewijs verdwijnt uit het CI-artefact',
  'Risk F149',
  'Geverifieerd: e2e/run-regression.mjs:11-12 schrijft regression-<versie>-partial.txt met writeFileSync voor elke gedeeltelijke run; de worker-pass overschrijft zo de B-rep-pass (ci.yml:44/46, artefact ci.yml:52-57).',
  'Bestandsnaam per pass (suffix kernel/rebuild).')
N('F161', 'Weergave', 'Minor', 'P3', 'Shading-naad en spikkels; STEP-import toont mesh ("300 triangles")',
  'Webi F152',
  'Volgens Webi: naad in shots/e10-fillet.png, spikkels in e19, STEP-import als mesh (shots/step-imported.png). Niet zelf opnieuw beoordeeld door QA: niet geverifieerd.',
  'Normalen/AO bij exacte bodies nakijken; STEP-import als B-rep tonen.')
N('F162', 'Security', 'Minor', 'P3', 'gpu:setSoftware bewaart enable-unsafe-swiftshader permanent in gpu.json',
  'Webi F153',
  'Geverifieerd: main.cjs:35-44 leest gpu.json vóór Chromium start en zet enable-unsafe-swiftshader; main.cjs:388 gpu:setSoftware schrijft die keuze weg.',
  'Alleen per sessie of met duidelijke melding en terugzetknop.')
N('F163', 'Merken', 'Minor', 'P2', 'Merk- en neutral-checks blind voor Weldments, Sustainability Extras en "reference frames"; docs/26 legt 1-op-1-pass vast',
  'Riki F150, Risk F152',
  'Geverifieerd: Weldments 0× in tools/rename-trademarks.cjs (29× in src); materials.ts:124/140 "Sustainability Extras"; docs/26-zelfcontrole-1op1.md:1-5 (vergelijking met SOLIDWORKS Design 2026-frames). Volgens Risk missen ook app.css:972, StatusBar.tsx:202, materialDialog.tsx:116 de neutral-check.',
  'Patronen toevoegen; docs/26 niet publiceren.')
N('F164', 'Testen/CI', 'Minor', 'P3', 'src/core/drawing/dbg.test.ts is een debugtest zonder assertie en telt mee in de 454',
  'Risk F155',
  'Geverifieerd: het enige *.test.ts in src zonder expect/assert (rg --files-without-match).',
  'Verwijderen of asserties toevoegen.')
N('F165', 'Data', 'Minor', 'P3', 'Oude "SW-Density" in vergelijkingen wordt bij openen niet omgezet',
  'Risk F156',
  'Geverifieerd: equations.ts:262 accepteert ^(?:SW-)?Density$ bij lezen; geen herschrijving van bestaande expressies gevonden.',
  'Bij openen herschrijven naar "Density".')
N('F166', 'Assembly', 'Minor', 'P3', 'solveMates stopt stil na een vast aantal passes; niet-convergentie is niet te onderscheiden van een conflict',
  'Riki F152',
  'Geverifieerd: assembly.ts:441 for (pass < passes); mateStatus.ts heeft volgens Riki (:8,18) geen aparte status voor niet-convergentie (niet regel voor regel door QA nagelezen).',
  'Status "niet geconvergeerd" met residu tonen.')
N('F167', 'Topologie', 'Major', 'P0', 'De voorgestelde fix voor F140 zit op de verkeerde laag; de oorzaak is niet bekend',
  'MT5 Dev F148',
  'Geverifieerd: edgesets.ts:337-354 splitPieces eist al colineair (≥0,9999) en binnen de oorspronkelijke rand (1e-3). Het B-rep-pad matcht op de tessellatie en vertaalt met brepEdgesOn (tol max(0,05; 1 % lengte), brep.ts:266-268 volgens MT5 Dev). QA\'s "waarschijnlijk de achterrand van de sleuf" is een hypothese.',
  'Eerst de gematchte mesh-randen en OCCT-randen loggen en B-T3 als unit-test (30439,91 ± 0,01); pas dan de matcher aanpassen; tot dan een waarschuwing bij gesplitste randen.')
N('F168', 'QA-rapport', 'Minor', 'P4', 'Fouten in het eerste QA-rapport 0.5.10 (formule, round2b, 827 kB, CI groen, Windows-log, Faceted-bewijs, 19/19)',
  'Strati F149/F150/F151, Riki F149c-e, MT5 Dev F150, Risk §4.1/§4.5, Webi (F126)',
  'Gecorrigeerd in deze versie: (a) 8,584 mm³ = 10·R²·(1−π/4), niet 10·(4−π)·R²; (b) round2b bevat 98+12+6 en is een kopie (F148); (c) 827 kB is verouderd (0.5.2-claim), niet onwaar; (d) de repo claimt geen "CI groen" (README.md:55-56), wel een CI-B-rep-pass (README.md:90), die onbewezen is; (e) het 98/98-log draaide op de niet-gecommitte 0.5.10-werkboom; (f) "Faceted 1/1" komt uit de e2e-build; (g) TASKS.md:814 claimt wel 19/19 voor 0.5.10.',
  'Opgelost in dit rapport.', status='Opgelost')
N('F169', 'QA-rapport', 'Minor', 'P3', 'QA-diagnoselog bevat een foute theoriewaarde (T2diag)',
  'MT5 Dev F149',
  'Geverifieerd: qaDiag.test.ts:45 gebruikte R − 3 + 3k i.p.v. R − 3k (k = (10−3π)/(12−3π)). Bron gecorrigeerd in tools/qa-src/qaDiag.test.ts; juiste theorie 355,93 / 428,74 (gelijk aan B-rep). logs/qa-diag.log is niet opnieuw gegenereerd en toont nog 335,79 / 408,60. Het T2-oordeel gebruikte al de juiste waarde.',
  'qaDiag opnieuw draaien bij de volgende QA-ronde.', status='Deels opgelost')
N('F170', 'QA-rapport', 'Minor', 'P4', 'Pariteit was te mild bij stille fouten',
  'MT5 Dev F152; Strati, Riki, Risk, Webi (pariteitsnotities)',
  'Herberekend (§5): stil fout resultaat ⇒ kapot (rij 11); rij 3, 30, 41 en 52 naar deels. 70,2 % → 66,1 %.',
  'Opgelost in dit rapport.', status='Opgelost')
L.sort(key=lambda f: int(f['id'][1:]))
json.dump(L, open(D + 'findings.json', 'w'), ensure_ascii=False, indent=1)
from collections import Counter
op = [f for f in L if not f['status'].startswith('Opgelost')]
print(len(L), 'open', len(op), Counter(f['sev'] for f in op), 'kritiek', [f['id'] for f in op if f['sev'] == 'Kritiek'])
print('prio', Counter(f['prio'] for f in op))
