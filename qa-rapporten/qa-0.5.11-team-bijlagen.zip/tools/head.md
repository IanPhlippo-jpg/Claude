# QA-rapport Phlippo CAD 0.5.10 — strikte eindcontrole tegen SOLIDWORKS

*Opgesteld op 2 november 2026 (Europe/Brussels); bijgewerkt na de teamronde (5 reviews, team/), 2 november 2026 ca. 16:00 CET. De strengste score en de strengste ernst per bevinding winnen. Alle cijfers komen uit runs op de QA-box (Linux, xvfb + SwiftShader) of uit bestanden in deze map. Niets is overgenomen zonder controle; zelfgerapporteerde Windows-cijfers staan apart.*

## 0. Versie en scope

| | |
|---|---|
| Versie | **0.5.10**, HEAD `a4b1e92` ("TASKS: 0.5.10 uitgebracht", 30-10-2026 22:51 CET), branch `claude/fase1-schetser` |
| Vorige QA | 0.5.1 (`46fc2f3`), score 5/10 na teamronde, pariteit 58,9 % |
| Delta | 21 commits (0.5.2 → 0.5.10) in 3 dagen; 222 gewijzigde bestanden, waarvan 146 in src/electron/e2e/tools (+5375 / −942 regels); de rest is vooral `graphify-out/` (64 MB, F142) |
| Testomgeving | Box-kloon `/workspace/phlippo-cad/app-0.5.10`, Node + Playwright-Chromium (SwiftShader), Electron onder xvfb; Windows-laptop alleen gelezen |
| Bewijs | `logs/` (alle runs), `shots/` (34 headless-screenshots uit de 0.5.10-regressie), `win/` (Windows-logs van de laptop, zelfrapportage), `tools/` (QA-scripts en eigen tests `tools/qa-src/*.test.ts`) |

## 1. Oordeel (executive summary)

**Is het klaar? Nee.** 0.5.10 is wel een duidelijke stap vooruit: de mate-solver werkt nu echt (M1, M3 en M5 correct), conflicten worden gedetecteerd, de fillet op een revolve-rand na een maatwijziging klopt (T2), de Options-dialoog liegt niet meer (inerte opties grijs), het programma start netjes zonder GPU, en er zijn reorder, PDF/DXF-export, auto-centermarks/verborgen lijnen (alleen unit-getest) en de plastics-features bijgekomen. Pariteit stijgt van 58,9 % naar **66,1 %** (streng, na teamronde; QA-eerste telling 70,2 %). Dat is een bovengrens: geen enkele rij is naast echte SOLIDWORKS-beelden gelegd (Webi).

Toch blijft het **NO-GO** voor "klaar" of publiceren. Na de teamronde staan er **9 Kritieke** bevindingen open (F31, F50, F51, F54, F93, F105, F111, F139, F140). De drie hoofdredenen:

1. **Stil foute geometrie in de release-standaard.** Op de B-rep-kernel (standaard in de release) rondt een fillet op een gesplitste rand een extra rand van 10 mm af (T3: precies 8,584 mm³ = 10 mm · R²·(1−π/4) bij R = 2 te veel weggenomen), zonder waarschuwing (**F140, Kritiek**). Er is geen kruiscontrole tussen exact en mesh die dit zou vangen (F159). Op de mesh-kernel (terugval, preview, plastics, e2e-build) voegt een fillet op een gatrand volume toe in plaats van het weg te nemen, bij Ø35 zonder enige waarschuwing (**F139, nu Kritiek**). Beide fouten vallen door de 454 unit-tests en de hele e2e-regressie heen; de QA-tests die ze vinden staan niet in de repo (F152).
2. **"98/98 groen" klopt niet op Linux.** Lokaal is het 93/98. Na herhaling blijven drawing (Ø35 niet gepakt, sinds 0.5.1), inventory47 en videos46 reproduceerbaar rood. De CI-job die exact deze run doet is dus vrijwel zeker rood (F54, F144), en omdat mesh, B-rep en worker in één bash -e-stap staan, draaien de B-rep- en workerpass in CI dan nooit (F147). Het enige 98/98-log van Windows heet `regression-0.5.9.txt`, is gestart 45 min vóór de versie-commit en draaide op een niet-gecommitte werkboom (het bevat round2.mjs, dat pas in a3bfaf7 kwam); `regression-round2b.log` is daar een letterlijke kopie van (F148).
3. **De claims zijn weer niet eerlijk genoeg.** 98/98 staat zonder platform in commit en TASKS; "release 0.5.10 geïnstalleerd (19/19)" (TASKS.md:814) heeft geen log; het build-log meldt "signing with signtool.exe" terwijl alle binaries NotSigned zijn (F149, F150). De README-status stopt bij 0.5.4. (De bundel-claim 827 kB is een verouderde 0.5.2-claim, geen 0.5.10-claim; de bundel is weer gegroeid naar 849 kB, F118.)

**Lijkt het echt op SOLIDWORKS?** Visueel: ja, opvallend. CommandManager, FeatureManager-boom, statusbalk, heads-up-toolbar, studio-look met schaduw en de assemblage-/tekening-weergaven liggen heel dicht bij het origineel (shots/walk-18-done.png, shots/deurkruk-assembly.png). Functioneel: alleen voor de basis. Schetsen, extrude/revolve, fillet, assemblage en tekening werken. Maar de kern die SOLIDWORKS betrouwbaar maakt, namelijk exacte geometrie die na wijzigingen stabiel blijft, is nog niet robuust. Daarnaast ontbreken IGES/DWG/Parasolid, design tables en een Toolbox. En 334 van de 379 opties doen niets. In Two/Four View worden de extra vensters zwarte silhouetten (F157, shots/m7-fourview.png).

**Eindscore na teamronde: 5/10** (QA-eerste oordeel 6/10; Strati, Riki, Webi en MT5 Dev 5/10, Risk 6/10; de strengste wint). 0.5.1: 5/10. **GO/NO-GO: NO-GO** voor "klaar" en publiceren (unaniem); **voorwaardelijk GO** voor eigen concept- en hobbywerk (unaniem, voorwaarden in §7.3 en §10).

## 2. Delta sinds 0.5.1

| Release | Wat volgens de commits | QA-bevinding |
|---|---|---|
| 0.5.2 | F109 solver, F108 DOF/conflict, F111 split-edge-fillet, F110 revolve-fillet, F112 inerte opties grijs + AutoRecover naar schijf, F113 reorder, F114 DXF/PDF, F116, F118 bundle 919→827 kB, F119–F123, F125, F131/F132 | Solver, conflict, T2, F112-eerlijkheid, reorder en DXF/PDF kloppen. **F111 alleen op mesh** (B-rep fout, F140). Bundel sindsdien weer gegroeid (827 → 849 kB, F118). |
| 0.5.3 | Concentric-conflict (F108) | Klopt (M5) |
| 0.5.4 | Software-GL (F115/F128), plastics (F121), statusprompts herschreven (F135/F136), F129, F133, F134 | Software-GL en self-test zonder GPU kloppen; multi-view onbeveiligd (F143); plastics alleen mesh |
| 0.5.5 | Plastics-preview | Gezien in shots/plastics-part.png |
| 0.5.6–0.5.9 | Look-kalibratie (studio-look, AO, vlakken, 1:1 tegen SW-frames, docs/26) | Visueel sterk, niet pixel-geverifieerd naast SOLIDWORKS (F16/F21/F22) |
| 0.5.10 | Testronde (docs/27); commit a3bfaf7 en TASKS.md:810: "unit 454, regressie 98/98, B-rep 12/12, worker 6/6" | Unit 454/454 klopt; e2e-claims kloppen niet op Linux |

## 3. Testresultaten (box, echte cijfers)

| Test | Resultaat | Bewijs |
|---|---|---|
| `npm ci` | OK | logs/npm-ci.log |
| Typecheck | EXIT 0 | logs/typecheck.log |
| Unit (vitest) | **454/454** in 117 bestanden | logs/vitest.log |
| CI-checks (merken, neutraal, regelbudget) | 3× EXIT 0 | logs/ci-checks.log |
| npm audit | 17 (15 moderate, 2 high, allemaal build-keten); `--omit=dev`: 0 | logs/audit.log, logs/audit-prod.log |
| Release-build | index 849,37 kB (gzip 233,87) | logs/build-release.log |
| Self-test Electron zonder GPU | **8/8**: B-rep exact, Fillet1 44742,52, STEP exact, worker 1143/1143, save + .bak | logs/self-test-nogpu.json |
| Self-test met SwiftShader | **8/8** | logs/self-test-softgl.json |
| desktop-nohooks (PHLIPPO_SOFTWARE_GL=1) | **10/10** | logs/desktop-nohooks-softgl.log |
| e2e-regressie standaard (mesh) | **93/98**: features, drawing, inventory47, rebuildworker, videos46 rood | logs/regression.log |
| Herhaling van de 5 rode scripts | features 65/65 en rebuildworker 10/10 groen; **drawing, inventory47, videos46 weer rood** → effectief 95/98 | logs/regression-rerun.log |
| e2e B-rep-pass | **11/12** (features TimeoutError); herhaling features 65/65 | logs/regression-brep.log, logs/regression-rerun-brep.log |
| e2e worker-pass | **5/6** (features TimeoutError) | logs/regression-worker.log |
| Repo schoon na tests | ja; de QA-map `src/qa/` is na de run uit de box-kloon verwijderd (git status schoon). De QA-tests staan dus niet in de repo (F152) | logs/git-status-after.log |
| Windows (zelfrapportage) | 98/98 (log heet 0.5.9, draaide op de niet-gecommitte 0.5.10-werkboom) + 12/12 + 6/6; round2b r.1-99 is een kopie van het 0.5.9-log (F148); NSIS + portable gebouwd, alle NotSigned | win/regression-0.5.9.txt, win/regression-round2b.log, win/desktop-build.log, win/signature-0.5.10.txt |

### 3.1 Eigen strikte QA-tests (bronnen in tools/qa-src/)

| Test | Wat | Mesh | B-rep |
|---|---|---|---|
| T1 | Fillet R2 op gatrand, daarna gat Ø35→Ø50 | **FOUT**: verlies −4,6 mm³ (verwacht +137,2), alleen waarschuwing "not closed ≈18,5 mm²"; Ø35 direct −34,8 zonder waarschuwing (F139) | Exact: 96,8 / 137,2 |
| T2 | Fillet op revolve-rand na maatwijziging | OK (432,68 vs 428,74) | Exact |
| T3 | Fillet op een rand die later gesplitst wordt | OK (30439,07 vs 30439,91) | **FOUT**: 30431,33, extra rand van 10 mm afgerond (F140) |
| M1 | Mate-keten, beide ref-volgordes | B=25 in beide | – |
| M2 | Conflicterende mates | Conflict gedetecteerd; de oudere mate gemarkeerd (F141) | – |
| M3 | Keten van 4, slechtste volgorde | OK | – |
| M4 | Onderbepaald | OK | – |
| M5 | Gesloten lus + concentric-conflict | OK, conflict gedetecteerd | – |
| E1 | Circulaire vergelijking | Gemeld | – |

Bewijs: logs/qa-strict-tests.log (9 tests, 1 rood: T1), logs/qa-brep-tests.log, logs/qa-diag.log. Let op (F169, MT5 Dev): de regels T2diag in qa-diag.log tonen een foute theoriewaarde (335,79 / 408,60) door een formulefout in de testbron; de juiste theorie is 355,93 / 428,74 (bron in tools/qa-src gecorrigeerd, log niet opnieuw gedraaid). Het T2-oordeel hierboven gebruikte al de juiste waarde.

## 4. Claimcontrole

| Claim (bron) | Oordeel | Bewijs |
|---|---|---|
| Unit 454 (TASKS.md:810) | **Waar** | logs/vitest.log 454/454 |
| Regressie 98/98 (TASKS.md:810, commit a3bfaf7) | **Onwaar op Linux** (93/98, na herhaling 95/98). Windows: het log heet 0.5.9 en draaide op de niet-gecommitte 0.5.10-werkboom (bevat round2.mjs); gelijkheid met de release niet geverifieerd. Claim noemt geen platform (F149) | logs/regression.log, logs/regression-rerun.log, win/regression-0.5.9.txt |
| Release 0.5.10 geïnstalleerd 19/19 (TASKS.md:814; TASKS.md:807 deed hetzelfde voor 0.5.9) | **Onbewezen**: geen log (correctie: eerder stond hier ten onrechte "niet voor 0.5.10 geclaimd") | – |
| B-rep 12/12, worker 6/6 | **Deels**: 11/12 en 5/6 lokaal, features groen bij herhaling (flaky) | logs/regression-brep.log, logs/regression-worker.log |
| F109 solver opgelost | **Waar** | QA M1/M3/M5 |
| F108 DOF/conflict | **Waar**, met kanttekening (oudere mate gemarkeerd, F141) | QA M2/M5 |
| F110 revolve-fillet | **Waar** | QA T2 |
| F111 split-edge-fillet opgelost | **Half waar**: mesh ja, B-rep (release-standaard) fout | QA T3 B-rep, F140 |
| F112 inerte opties grijs, AutoRecover naar schijf | **Waar** (334/379 grijs; autoRecover.ts schrijft), maar herstel niet e2e-getest | options.tsx:78-81, logs/prefs-unused.txt |
| F113 reorder | **Waar** | e2e/reorder.mjs:52-69 dragTo, 10/10 |
| F114 DXF/PDF | **Waar** (IGES/DWG/Parasolid nog niet) | sheetexport 12/12 |
| F115 zonder GPU nette afhandeling | **Grotendeels waar** (hoofdviewport, self-test); ViewPane onbeveiligd | glSetup.ts:11-17, ViewPane.tsx:20 |
| F118 bundle 919→827 kB (TASKS.md:763, 0.5.2) | **Verouderd** (claim hoort bij 0.5.2; of 827 kB toen klopte: niet zelf geverifieerd, Strati mat 826,66 kB op 46a1bd9). Nu 849,37 kB: weer gegroeid zonder budget | logs/build-release.log:50 |
| F10 Ø35 (impliciet "alles groen") | **Onwaar**: nog altijd rood op Linux | logs/regression-rerun.log |
| "CI groen" | **Wordt niet geclaimd** (correctie): README.md:55-56 zegt zelf dat de Actions-uitslag niet leesbaar is. Wél geclaimd: "De CI draait de desktopchecks en een B-rep-pass" (README.md:90): **onbewezen**, en bij een rode mesh-pass feitelijk onwaar (F147) | ci.yml:38-46; geen Actions-run; lokaal 3 reproduceerbaar rode scripts |
| F50 handelsmerkvrij | **Deels**: "Weldments" zichtbaar als tab (29× in src, 0× in de merkcheck), "Sustainability Extras" | shots/walk-18-done.png, materials.ts:124/140 |
| Signing (build-log "signing with signtool.exe") | **Onwaar**: alle vier 0.5.10-binaries NotSigned (F150) | win/desktop-build.log:67-74, win/signature-0.5.10.txt |

### 4.1 De 9 kritieke punten uit 0.5.1 en M1/M2/T2/T3

| ID | 0.5.1 | 0.5.10 (QA → na teamronde) |
|---|---|---|
| F31 CI/exitcodes | Kritiek | Deels opgelost; QA Major → **Kritiek** (Strati, Webi, MT5 Dev; CI kan B-rep/worker niet draaien, F147) |
| F50 Handelsmerken | Kritiek | Deels opgelost; QA Major → **Kritiek** (Strati; blokkeert publiceren) |
| F51 Mesh-kernel primair | Kritiek | Deels opgelost, **blijft Kritiek** (unaniem; mesh-fout F139) |
| F93 Claims kloppen niet | Kritiek | Deels opgelost, **blijft Kritiek** (unaniem; 98/98, 19/19, signing) |
| F108 Mate-conflict | Kritiek | **Opgelost** |
| F109 Mate-solver | Kritiek | **Opgelost** |
| F111 Split-edge-fillet | Kritiek | Deels; QA Major → **Kritiek** (Strati, MT5 Dev); B-rep-deel ook als **F140 Kritiek** |
| F112 Options-façade | Kritiek | Deels → **Major** (unaniem aanvaard; eerlijk, maar 88 % inert) |
| F115 Zonder WebGL | Kritiek | Deels → **Major** (unaniem aanvaard; F143 resteert) |
| M1 / M2 | kapot / ontbreekt | OK / OK met F141 |
| T2 / T3 | kapot | OK / mesh OK, B-rep fout |
