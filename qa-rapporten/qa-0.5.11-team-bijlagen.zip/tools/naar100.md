# Weg naar 100 % — Phlippo CAD na 0.5.11 (herzien na teamreview)

*Opgesteld 3 november 2026 (Europe/Brussels, UTC+1), herzien dezelfde dag na de vijf teamreviews (Strati, Riki, Webi, Risk, MT5D; `team/`). Ieder punt heeft een meetbare acceptatietest, de plek in de code (bestand:regel op HEAD `db0d4b2`) en een inschatting in werkdagen voor één ontwikkelaar met de huidige agent-setup. Statussen en cijfers: `findings.json` en `parity.json`. De eerste versie van dit plan staat als `tools/naar100-v1.md`; de fouten daarin zijn bevinding F182.*

## 1. Waar we staan

- **Strikte pariteit: {PCT} %** ({A} aanwezig, {D} deels, {O} ontbreekt, {K} kapot). De eerste versie zei 75,0 %; zie F181.
- **3 Kritiek open:** F177 (stille foute fillet op een gesplitste rand na een maatwijziging, onder "exact"), F175 (facetten onder het label "exact": ellips, spline, wrap-patch) en F176 (geen groene CI op de release-commit).
- **Geen enkel "groen" buiten de QA-box op HEAD.**

## 2. Meetbare definitie van "100 %" (overgenomen van Strati §5.5)

Een release is **100 % SW-gelijk** als al het volgende waar is, op één release-commit:

1. **Pariteit:** 62/62 rijen "aanwezig", waarbij rij 37, 42/51 en 54 vooraf door Ian zijn herdefinieerd en ondertekend (§6). Een rij is pas aanwezig als:
   - (a) elk deelitem uit de rijnaam een geautomatiseerde test in de repo heeft (vitest of e2e) die in CI op `?kernel=brep&rebuild=worker` draait;
   - (b) **geometrie:** volume en oppervlak gelijk aan de R0-waarde binnen |ΔV| ≤ max(0,01 mm³; 1·10⁻⁵ relatief) voor exacte bodies; een facet-body maakt de rij niet aanwezig;
   - (c) **2D/tekening:** maten binnen 0,01 mm van R0; aantal zichtbare en verborgen lijnen gelijk aan de R0-PDF;
   - (d) **STEP:** round-trip naar SW (R0) geeft gelijk volume binnen 1·10⁻³ mm³ en dezelfde vlaktypes (ellips = `ELLIPSE`, spline = `B_SPLINE_*`, geen polylijnstroken);
   - (e) **UI-rijen:** een **gedragsscript per commando** (functionele pariteit). *Geen pixel-overlay op SW-screenshots* (juridische grens, §7).
2. **Bevindingen:** 0 open van welke ernst ook, en 0 "niet geverifieerd" in `findings.json`.
3. **Naamgevingsrobuustheid:** een propertysuite van ≥ 500 willekeurige bewerkreeksen (feature invoegen vóór een fillet/chamfer, verwijderen, maat of aantal wijzigen). Orakel: herbouw met handmatig gekozen randen, plus R0 voor 30 vaste gevallen. Uitkomst **0 stille afwijkingen**; elke afwijking geeft een waarschuwing.
4. **Eerlijkheid:** elke body met `exact: true` heeft alleen analytische of NURBS-vlakken (STEP-check). "Faceted" is waar voor elke andere body.
5. **Bewijs:** een groene GitHub Actions-run met artefacten waarin `commit` = de tag, op een **echte git-kloon** (geen stand-in); Windows-regressie mesh, release en B-rep op dezelfde commit; self-test met `packaged: true` vanuit de geïnstalleerde exe; `Get-AuthenticodeSignature` = Valid; een desktop-installed-log met de 19 checknamen.
6. **Stabiliteit:** 3 opeenvolgende CI-runs over 2 releases groen zonder rerun; geen rij teruggezakt; elk e2e-script N ≥ 10 keer groen.

## 3. Plafond: wat haalbaar is zonder geld en zonder herdefinitie

| Rij / bevinding | Waarom niet gratis | Beste haalbare |
|---|---|---|
| 42 PDF/DXF/**DWG** | DWG lezen/schrijven vergt de ODA-SDK (betaald) | PDF en DXF wel; rij blijft **deels** |
| 51 IGES/DXF/DWG/**Parasolid** (F114, F199) | Parasolid is van Siemens; geen vrije writer bekend (niet geverifieerd). **IGES kan niet met de meegeleverde OCCT**: `replicad_single.d.ts`/`replicad_multi.d.ts` bevatten 0× `IGESControl_Writer`. IGES vergt een eigen opencascade.js-build met de IGES-module (gratis, ±3–5 d) | IGES via eigen build + 3D-DXF; rij blijft **deels** |
| 60 Code-signing (F49/F117) | Authenticode-certificaat kost geld; gratis alleen via SignPath Foundation als de repo publiek en OSS is | **ontbreekt**, tenzij Ian kiest (§6) |
| 59 Installer | De installer zelf kan volledig worden (P2-13); blijft alleen deels zolang SmartScreen waarschuwt. *Dat is hetzelfde gemis als rij 60*; hier strikt mee geteld | **deels** zonder signing |
| 54 Iconen/lettertype pixelgelijk | 1:1 kopiëren schendt auteurs- en merkrecht (F50, F189) | **Herdefiniëren** (§6), anders deels |
| 37 Toolbox | De Toolbox-inhoud is SW-eigendom | Eigen ISO/DIN-bibliotheek; **herdefiniëren** (§6), anders deels |

**Eerlijk plafond zonder betaalde posten en zonder herdefinitie:** 56 aanwezig, 5 deels (37, 42, 51, 54, 59), 1 ontbreekt (60) = (56 + 2,5)/62 = **94,4 %**. (De eerste versie zei 95,2 %: rij 37 stond daar tegelijk bij "naar aanwezig" en bij "deels", en rij 42 kwam in geen enkele weeklijst voor; F182.) Telt men rij 59 los van de signing (alleen P2-13), dan is het 95,2 %; wij houden de strengere 94,4 %.

**Zonder R0 (SOLIDWORKS-referentie):** 17 rijen zijn alleen met een SW-referentie te meten (3, 6, 7, 10, 15, 16, 17, 18, 19, 20, 33, 37, 41, 47, 52, 54, 56). Zonder R0 blijven die hoogstens deels: 41 aanwezig, 20 deels, 1 ontbreekt = (41 + 10)/62 = **82,3 %**. (Met rij 59 los van signing: 83,1 %.) **Zonder R0 is ±83 % het maximum, hoe goed de code ook is.**

## 4. Fasen met poorten (structuur van Strati §5.6, aangevuld)

Een fase is pas klaar als de poort volledig waar is. Geen enkele rij mag in een latere fase terugzakken.

| Fase | Inhoud | Poort (alles moet waar zijn) | Strati | QA (herzien) |
|---|---|---|---|---|
| **F0 · Waarheid** | §5 P0-1 … P0-10 | **G0:** Actions groen op de release-commit (echte git-kloon); de STRATI-01-tests (F177) groen met juist volume of een expliciete waarschuwing; ellips/spline/wrap `exact:false` of echt exact; strikte pariteit opnieuw geteld volgens §2-1; **0 Kritiek** | 7–10 d | 11–15 d |
| **R0 · Referentie** (parallel) | SW-referentiepakket (zie §5) plus de STRATI-01-modellen en de varianten van rij 11. Eigenaar en licentie vooraf vastgelegd | **GR:** `qa-referentie/` met een JSON per rij en model, door Ian goedgekeurd | 3–5 d + licentie | 3–5 d + licentie |
| **F1 · Geometrie** | §5 P1-1 … P1-10, rij 11 volledig in B-rep, de propertysuite (§2-3) | **G1:** 0× Faceted in de featurelijst van R0; propertysuite 0 stil; STEP-vlaktypes juist; rijen 10, 11, 15, 16, 18, 19, 29, 30, 31, 33 aanwezig volgens §2-1 | 35–42 d | 43–57 d |
| **F2 · Functies** | §5 P2-1 … P2-16, met realistische tijd | **G2:** rijen 3, 6, 7, 17, 20, 27, 41, 44, 47, 52, 53, 56 aanwezig; geen F1-rij teruggezakt | 40–43 d | 47–55 d |
| **F3 · Release en besluiten** | P2-13/14, P3, juridische toets, de besluiten uit §6 | **G3:** de definitie uit §2, volledig | 5–8 d + besluiten | 5–6 d + besluiten |

### Doorlooptijd (eerlijke bandbreedte)

| Bron | Schatting tot 100 % (§2) |
|---|---|
| Eerste versie van dit plan | 60–80 d (rekenfout: de posten telden op tot 82–89 d; F182) |
| Strati | 90–105 d |
| Risk | 80–110 d |
| MT5D | 110–150 d |
| **QA herzien (som van §5)** | **109–138 d** (F0 11–15 + R0 3–5 + F1 43–57 + F2 47–55 + F3 5–6) |

**Eerlijk: 95–150 werkdagen kernwerk; met 15 % buffer voor onbekenden (gebogen-randtopologie F178, CI-flakiness F195, de onverklaarde hang in F178) 110–175 werkdagen, ≈ 5½–8½ maanden voor één ontwikkelaar.** Daarbij komt de doorlooptijd van de besluiten in §6 (licentie, certificaat). Deze schattingen zijn niet geverifieerd; het enige harde punt is dat de onderkant van de eerste versie (60 d) niet houdbaar is.

## 5. Werkpakketten

### P0 — Waarheid en release-gate (F0; ≈ 11–15 d)

| # | Wat | Dekt | Acceptatietest (meetbaar) | Code | Inschatting |
|---|---|---|---|---|---|
| P0-1 | **Eerlijk label, interim (eerst, vóór alles):** bodies met ellips, spline of wrap-patch en bodies waarop een fillet een gesplitste/gebogen referentie heeft, krijgen `exact:false` en een waarschuwing tot de echte fix | F175, F177, F178 | Ellips 40×20×10: statusbalk "Faceted", boom niet "Exact surfaces"; T3+sleuf+basis 100: waarschuwing zichtbaar | `occt/brep.ts:68-75`, `rebuild.ts:2848-2849`, StatusBar | 1–2 d |
| P0-2 | **STRATI-01-fix:** gesplitste referentie neemt alle stukken langs dezelfde lijn/kromme mee; waarschuwing zodra `matchEdge` uit meerdere kandidaten kiest | F177, F111 | T3 + basis 80 → 100: 38422,743 ± 1e-3 mm³ (B-rep) / ± 1,5 mm³ (mesh), of een expliciete waarschuwing; varianten A–E uit `tools/qa-src/qaTeam.test.ts` als asserts in `src/qa/` | `src/core/features/edgesets.ts:308-310, :338-355` | 2–3 d |
| P0-3 | **Volume-kruiscontrole per feature, onafhankelijk van `matchEdges`** + bbox, oppervlak, zwaartepunt en face/edge-aantallen | F172, F179, F159, F48 | Per fillet/chamfer: som van gematchte stuklengtes = lengte van het oorspronkelijke vlakkenpaar langs dezelfde lijn. Per feature: \|ΔV\|, \|ΔA\|, Δzwaartepunt, Δbbox en #faces/#edges tegen de andere kernel. **Tessellatie-bewuste drempel:** \|ΔV\| > max(3 × de gemeten tessellatiefout van die feature; 1e-4 relatief) — de oude drempel max(0,5 mm³; 0,1 %) ligt onder het tessellatieverschil op een correct T3 (0,794–0,845 mm³) en geeft valse alarmen (RISK-01). Waarschuwing bij elke feature, niet alleen de laatste; e2e-test | `volumeCheck.ts:8`, `brepRefine.ts:77, :89-90` | 2–3 d |
| P0-4 | **`volumeCheck.test.ts:9` omkeren:** `volumeMismatch(30439.07, 30431.33)` moet een waarschuwing geven | F198 | Test rood op de huidige code, groen na P0-3 | `src/core/features/volumeCheck.test.ts:9` | 0,1 d |
| P0-5 | Eén volledig groene GitHub Actions-run op de release-commit, vanuit een **echte git-kloon** | F176, F54, F31, F147, F98, F180, rij 61/62 | `gh run view <id> --json jobs`: alle jobs `success`; artefacten met `commit` = release-commit; mesh 98/98, release 98/98, brep **14/14** (loftface en pmsweep toegevoegd), 0 skips boven budget; multibody groen (F195) | `ci.yml:89-137`, `e2e/run-regression.mjs:48-52` | 1 d + minutenquotum (gratis: repo publiek, of self-hosted runner) |
| P0-6 | **Windows-job in CI** | F190, F93 | `windows-latest`: mesh, release en packaged self-test op dezelfde commit | `ci.yml` | 1 d |
| P0-7 | QA-tests strakker en in de repo, **met asserts**; randkeuze op positie | F173, F130, F185 | M3, M5 en "nieuwste mate gemarkeerd" in `mateStatus.test.ts`; `qaStrict.test.ts:26` ≤ 2 % van het **verlies**; `:69` ≤ 1,5 mm³; B-rep ≤ 1e-3 mm³; elke diagnosetest heeft `expect`; B-T3 kiest de rand op y = 10, z = −40 | `src/qa/qaStrict.test.ts:19-70`, `qaBrep.test.ts:56-68` | 1 d |
| P0-8 | **Herhaalde runs en mutatietests** | F184, F145 | Elk e2e-script N ≥ 10 keer groen in CI; mutaties (matchEdge kiest altijd het eerste stuk; volumeCheck-drempel × 10) worden door de tests gevangen | `e2e/run-regression.mjs`, vitest | 1–2 d |
| P0-9 | Bewijs op HEAD: Windows-logs, desktop-installed-log, checks/desktop-logs, ongesplitste logs | F93, F149, F126, F148, F97, F151, F180 | `win/*.txt` met de release-commit in de kop; `desktop-installed-<v>.txt` met commit, tijd en 19 checknamen; elke pass één log met eigen DONE-regel | `tools/sign-report.cjs`, `electron/selftest*` | 1 d |
| P0-10 | Release-pass ook buiten de box | F105 | release 98/98 op Windows en in Actions; het overgeslagen sheetexport-stapje groen of bewust uit het budget | `ci.yml:105-115`, `e2e/sheetexport.mjs` | 0,5 d |

### R0 — SOLIDWORKS-referentiepakket (parallel; ≈ 3–5 d + licentie)

Bouw in SOLIDWORKS de QA-modellen T1–T3, M1–M5, **de STRATI-01-modellen (T3 + sleuf + basis 100; gebogen rand R10 + fillet R2)**, de varianten van rij 11 (variabel, face fillet, full round, setback, chamfer-varianten) en één model per referentierij. Exporteer per model Mass Properties (volume, oppervlak, zwaartepunt op 0,001), STEP, een tekening als PDF en per commando een gedragsbeschrijving. Leg alles vast in `qa-referentie/` met een JSON per rij. **Eigenaar en licentie: besluit van Ian (§6).** De screenshots zijn alleen intern referentiemateriaal, nooit in de repo.

### P1 — Exacte geometrie (F1; ≈ 43–57 d)

| # | Wat | Dekt | Acceptatietest | Code | Inschatting |
|---|---|---|---|---|---|
| P1-1 | Exacte ellipsen en splines | F175, rij 30/31 | Ellips 40×20×10: V = 6283,185 ± 0,001; STEP bevat `ELLIPSE` en `B_SPLINE_CURVE_WITH_KNOTS`, 0 polylijnstroken | `occt/brep.ts:4, :68-75, :144` | 3 d |
| P1-2 | **Randen van het exacte lichaam uit de B-rep-topologie** (geen 32 segmenten op een boog); tangentketens als één selectie | F178 | Plaat met R10-boog: de boog is 1 rand; fillet R2 erop in B-rep, verlies 12,881 ± 0,001 mm³, geen mesh-terugval; de hang (sleuf + fillet op 32 segmenten) gereproduceerd en weg | `occt/brep.ts` (edges), `edgesets.ts` | 4–6 d |
| P1-3 | **Alle filletsoorten in B-rep + tests per soort**: variabel, multi-radius, face fillet, full round, setback, partial, chamfer-varianten | rij 11, F51 | Per soort een test tegen gesloten vorm of R0 binnen 1e-3 mm³; geen "has no exact (B-rep) version" | `rebuild.ts:858-864` (brepRoundable) | 5–8 d |
| P1-4 | Plastics exact: Indent, Lip/Groove, Snap Hook, Mounting Boss | F51, F121, rij 16/31 | Geen mesh-waarschuwing (`rebuild.ts:3314`); volume tegen R0 binnen 1e-3; 0× Faceted | `features/plastics.ts`, `brepKernel.ts:50` | 8–10 d |
| P1-5 | Wrap/Deform/Flex/Freeform en surfaces exact | F175 (wrap), rij 15/18 | Emboss/deboss: STEP zonder PLANE-strook op de cilinder; volume tegen R0 | `rebuild.ts:2187-2188`, `occt/brep.ts:363` | 6–8 d |
| P1-6 | Loft > 2 profielen en guide curves in B-rep | rij 10 | 3 profielen: volume tegen R0 binnen 0,01 % | `occt/brep.ts` loft | 3 d |
| P1-7 | Topologische naamgeving + **propertysuite** (§2-3) | F47, F177, rij 29 | T4–T7 (sweep, loft, patroon, shell) én ≥ 500 willekeurige reeksen: 0 stil | `src/qa/` (nieuw) | 6–8 d |
| P1-8 | Sheet metal: exacte flange repareren, K-factor, flat pattern | F197, rij 19 | Geen stille mesh-terugval (`rebuild.ts:1600-1604`); flat-patternlengte van 3 bochten = R0 ± 0,01 mm | `features/sheetmetal*.ts` | 4–5 d |
| P1-9 | Mechanische mates met gedragstests; conflictheuristiek | rij 33, F186 | cam/hinge/screw/rack-pinion/linear coupler: positie na 10 mm/30° ± 1e-6; grens "unconverged" getest | `assembly.ts:430-444`, `mateStatus.ts:124-128` | 3–4 d |
| P1-10 | `.kcad`-compatibiliteit en AutoRecover van 0.5.10 | F184, F188 (RISK-05) | Fixtures van 0.5.10 openen identiek (volume, featurelijst); een 0.5.10-autorecoverkopie verschijnt in Document Recovery | `persistence.ts`, `electron/recover.cjs:27-29` | 1–2 d |

### P2 — Functionele gaten (F2; ≈ 47–55 d)

| # | Wat | Dekt | Acceptatietest | Code | Inschatting |
|---|---|---|---|---|---|
| P2-1 | IGES-export via **eigen opencascade.js-build** (met IGES-module) en 3D-DXF; niet-bestaande formaten uit Options | F114, F171, F199, rij 51 | T1 als IGES, terug ingelezen: volume binnen 1e-3; Options ▸ Export toont alleen bestaande formaten | `occtClient.ts:50`, `prefsSchema.ts:313-314` | 5–7 d |
| P2-2 | Options die echt werken | F112, rij 53 | Elke getoonde optie heeft een effecttest (of is weg) | `prefsWired.ts:5`, `prefsSchema.ts` | 6–8 d |
| P2-3 | Design tables (CSV/XLSX via SheetJS) | rij 44 | 3 configuraties × 4 maten: import en round-trip identiek | `src/core/document/` | 3 d |
| P2-4 | Instant2D, Magnified Selection, 3D-schetsmaten | F124, rij 6/7 | e2e: maat slepen wijzigt waarde; 3D-schets volledig bepaald | `src/core/sketch/`, `Viewport.tsx` | 5 d |
| P2-5 | AlongX/Y/Z | rij 3 | `relations2.test.ts`: AlongZ houdt x, y gelijk na sleep | `equations.ts:307-323` | 1 d |
| P2-6 | Instant3D-handvatten | rij 17 | e2e: 4 featuretypes, ± 0,01 | `store.ts:828-839` | 3 d |
| P2-7 | Undo/redo 200 stappen bewezen | rij 27 | e2e 200× undo/redo | `src/core/document/history.ts:5` | 0,5 d |
| P2-8 | Eigen normdelenbibliotheek (ISO 4762, 4032, 7089) | rij 37 | 30 normdelen; Smart Fasteners kiest M6 bij Ø6,6 | `store.ts:461` | 4 d |
| P2-9 | HLR, centermarks, analyses tegen R0 | F122, rij 41/47 | Lijntellingen = R0-PDF; analyses binnen 1 % | `drawing/autoMarks.ts`, `hlr.ts` | 4 d |
| P2-10 | Performance: budget en worker overal | F137, F46, rij 56 | `rebuildBudgetMs` 45 000 → 5 000 (`rebuild.ts:853`, gebruikt in `store.ts:1234, :1261`); browser standaard in de worker; features-script ≤ 120 s in CI (nu dicht bij 900 s, F195) | `rebuild.ts:853`, `rebuildWorker.ts:25-36` | 4–5 d |
| P2-11 | Frames (weldments) tegen SW | rij 20 | 5 ISO-profielen; cut-list = R0 ± 0,01 mm | `features/weldments.ts` | 2 d |
| P2-12 | UI-gedrag naast SW: CommandManager, taakvenster, heads-up — **functioneel, geen pixelkopie** | rij 52, rij 54, F16, F21, F22 | Per commando een gedragsscript (zelfde stappen, zelfde uitkomst als R0); eigen iconen | `ui/icons.tsx`, `Ribbon.tsx` | 3–4 d |
| P2-13 | Gepackaged self-test en fuses-test in de installer | F151, F196, rij 59 | Self-test vanuit de geïnstalleerde exe (`packaged:true`) in de Windows-CI; fuses gelezen met `@electron/fuses` | `electron/main*`, ci.yml | 1–2 d |
| P2-14 | Code-signing (na besluit §6) | F49, F117, rij 60 | `Get-AuthenticodeSignature` = Valid op setup, portable en exe | electron-builder-config | 1 d + aanvraag |
| P2-15 | Extra views interactief en zonder 1500 ms-readback | F192, F191 | Selecteren/draaien/zoomen in elk pane; geen periodieke readback zonder wijziging | `ViewPane.tsx` | 3 d |
| P2-16 | CI-stabiliteit multibody en features | F195, F183 | multibody groen in 3 runs op rij; features met ≥ 30 % marge op de timeout | `e2e/multibody.mjs`, `ci.yml` | 1–2 d |

### P3 — Hygiëne (F3; ≈ 5–6 d)

| # | Wat | Dekt | Acceptatietest | Code | Inschatting |
|---|---|---|---|---|---|
| P3-1 | Docs gelijk aan de werkelijkheid | F38, F129 | Script vergelijkt getallen in README/TASKS met vitest-output | `TASKS.md`, `docs/28` | 0,5 d |
| P3-2 | Line-budget-caps | F134 | `rebuild.ts`-cap ≤ 2500 (nu 3398) | `tools/line-budget.cjs:12-21` | 2 d |
| P3-3 | Dev-audit naar 0 | F138 | `npm audit` 0 moderate/high | `package.json` | 0,5 d |
| P3-4 | Bundelruimte | F174 | Release-index ≤ 800 kB | `vite.config.ts`, `bundle-budget.cjs:8` | 1 d |
| P3-5 | Kleine UI-restpunten | F24, F28, F161, F193, F194 | Units/Material leesbaar; één productnaam; overige zoals eerder | `Ribbon.tsx`, `occtClient.ts:50` | 1–2 d |

## 6. Besluiten voor Ian (geen techniek; zonder deze besluiten is 100 % niet te halen)

| # | Besluit | Opties | Gevolg |
|---|---|---|---|
| B1 | **Rij 37 (Toolbox) en rij 54 (iconen/lettertype) herdefiniëren** | (a) rij 37 = "eigen ISO/DIN-normdelenbibliotheek met Smart Fasteners", rij 54 = "eigen, consistente iconenset; gedragsgelijk, niet pixelgelijk"; (b) laten staan | (a) maakt 100 % mogelijk; (b) houdt beide rijen definitief op deels |
| B2 | **DWG (rij 42) en Parasolid (rij 51)** | (a) betalen (ODA-lidmaatschap; Parasolid-licentie bij Siemens); (b) met handtekening buiten scope | (b) = de rijen uit de 62 halen of definitief deels |
| B3 | **Code-signing (rij 60)** | (a) betaald Authenticode-certificaat; (b) repo publiek + OSS + SignPath Foundation; (c) ongesigneerd laten | (c) = rij 60 blijft ontbreekt, rij 59 deels |
| B4 | **SolidWorks-licentie voor R0** | (a) eigen licentie/maker-licentie; (b) iemand met SW die de modellen bouwt; (c) geen R0 | (c) = plafond ±83 % (§3) |
| B5 | **Repo publiek maken?** | Ja geeft gratis CI-minuten en de OSS-signing-route; maar eerst §7 | Nee = self-hosted runner of betaalde minuten |

## 7. Juridische grens (F189, RISK-06, WEBI-07)

- **Vóór de repo publiek gaat:** `docs/26` en `docs/06` (SW-specifieke inhoud, o.a. docs/06:3) uit de repo en uit de git-historie.
- **Functionele, geen visuele pariteit.** Geen pixelkopie van iconen, lettertype of lay-out; geen SW-screenshots in de repo; de R0-screenshots blijven intern.
- Geen SW-merknamen in UI of productnaam (de merkencheck blijft); materiaalnamen niet 1:1 uit de SW-bibliotheek; een eigen EULA.
- Een juridische toets door een mens vóór publicatie. QA is geen jurist.

## 8. Volgorde

1. **Week 1–2: F0.** Eerst P0-1 (eerlijk label), dan P0-2 t/m P0-4, dan CI (P0-5/6) en bewijs. Besluiten B1–B5 aanvragen; R0 starten zodra B4 rond is.
2. **Week 3–13: F1** (geometrie), met de propertysuite vanaf het begin.
3. **Week 14–24: F2** (functies).
4. **Week 25–30: F3** (release, besluiten, juridische toets), P3 doorlopend.

Resultaat zonder betaalde posten en zonder herdefinitie: **94,4 %**. Met B1 (herdefinitie) en B2/B3 (betalen of buiten scope met handtekening): 100 % volgens §2.
