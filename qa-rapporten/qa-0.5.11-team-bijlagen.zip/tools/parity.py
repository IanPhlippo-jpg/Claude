import json, copy
P = json.load(open('/workspace/phlippo-cad/report-0.5.1/parity.json'))
R = json.load(open('/workspace/phlippo-cad/report-0.5.10/tools/results.json'))
rows = copy.deepcopy(P['rows'])
for r in rows: r['old'] = r['status']
A,D,O,K='aanwezig','deels','ontbreekt','kapot'
def s(i, st, ev): rows[i]['status'] = st; rows[i]['ev'] = ev
s(2, A, 'Intersection/Merge/Equal Curvature: equations.ts:307-323 + relations2.test.ts (AlongXYZ = 3D-schets, rij 5)')
s(8, A, 'Revolve-fillet na maatwijziging OK: QA T2 mesh+B-rep (logs/qa-strict-tests.log, logs/qa-brep-tests.log)')
s(10, D, 'T2 OK, maar mesh-fillet op gatrand fout (F139) en B-rep T3 te veel afgerond (F140)')
s(15, D, 'Aanwezig (plastics.ts, 12 unit-tests, e2e plastics) maar alleen mesh-kernel, vereenvoudigd (F121)')
s(16, D, 'Drag Handles (hernoemd van Instant3D): alleen diepte van blind extrude (store.ts:828-839); geen e2e of unit-test gevonden')
s(24, A, 'Slepen in boom (FeatureTreeBody.tsx:213) + reorder.test.ts')
s(27, D, 'Mesh: maat Ø35→Ø50 rand gevonden maar fillet-volume fout (F139); B-rep correct')
s(28, D, 'T2/T3 mesh OK; T3 B-rep (release-standaard) rondt extra rand af (F140)')
s(32, D, 'Typen aanwezig (types.ts) en solver nu correct voor M1/M3/M5 (logs/qa-strict-tests.log); mechanische mates (cam/hinge/screw/rack-pinion/linear coupler) nog zonder gedragstests')
s(33, A, 'QA M1 beide volgordes, M3 keten-4, M5 gesloten lus correct (logs/qa-strict-tests.log)')
s(34, D, 'Conflict gedetecteerd (M2, M5) met under/over-status, maar de verkeerde (oudere) mate gemarkeerd (F141)')
s(36, D, 'Auto Fasteners (store.ts:461); geen Toolbox-bibliotheek')
s(38, R['row38'], R['row38_ev'])
s(40, A, 'core/drawing/autoMarks.ts + hlr.ts met unit-tests')
s(41, D, 'PDF/DXF: sheetExport.ts, export2d.test.ts, e2e/sheetexport.mjs; DWG ontbreekt')
s(50, O, 'IGES/DWG/Parasolid ontbreken nog (DXF alleen 2D-tekening, rij 41)')
s(52, D, 'Eerlijk: 334/379 grijs "Not available"; maar slechts 45 werken (F112)')
s(53, D, 'Niet naast SOLIDWORKS geverifieerd (F16/F21/F22)')
s(54, D, 'Alleen "Weldments" resteert (F50); e2e-comments noemen SOLIDWORKS (F136)')
s(55, D, 'Release: worker standaard; worker-pass ' + R['worker_summary'] + '; budget 45 s (F137); ' + R['F125_short'])
s(56, D, 'AutoRecover schrijft nu echt (autoRecover.ts) + browser-autosave; herstel na crash niet end-to-end getest')
s(57, R['row57'], R['row57_ev'])
s(58, D, 'NSIS + portable gebouwd (win/desktop-build.log); ongesigneerd')
s(59, O, 'Get-AuthenticodeSignature: NotSigned')
s(60, R['row60'], R['row60_ev'])
s(61, K if R['linux_red'] else O, R['row61_ev'])

RG='logs/regression.log'
EV = {
0:'model.ts add*; smoke 13/13, slot 9/9, sketchcurves 13/13, ellipsetext 6/6 (RG); shots/walk-12-dimensioned.png',
1:'solver.ts; relations 14/14 (RG); shots/gj1-relations.png',
3:'solver.test.ts over/conflict in vitest 454/454 (logs/vitest.log)',
4:'sketchtools 13/13, sketchtools2 4/4 (RG)',
7:'endconditions 15/15 mesh én B-rep (RG, logs/regression-brep.log); features 65/65 bij herhaling (logs/regression-rerun.log); shots/walk-15-extruded.png',
9:'Sweep/Loft aanwezig (shots/e18-sweep.png, pmsweep 54/54, loftface 7/7 in RG); B-rep-loft nog 2 profielen; Sweep1 faalde 1× in features (F145)',
11:'rib 10/10 (RG); shots/e16-shell.png',
12:'Hole Tool: shots/e12-hole-preview.png; gj 37/37 incl. ANSI-gat (RG)',
13:'features 65/65 (logs/regression-rerun.log), componentpattern 6/6, sketchpattern 2/2 (RG)',
14:'wrap 4/4, gj (deform) 37/37 (RG); mesh-terugval, Faceted',
17:'surfaces 7/7, gd 23/23 (RG); mesh-terugval',
18:'sheetmetal 14/14, sheetmetal2 7/7, ge 59/59 (RG); shots/ge14-sweptflange.png; geen virtual sharp',
19:'gh 29/29 (RG), shots/gh6-frame.png; naam "Weldments" (F50)',
20:'multibody 14/14 mesh én B-rep (RG, logs/regression-brep.log); shots/m5-combined.png',
21:'shots/walk-18-done.png (History, Sensors, Annotations, Solid Bodies, Material, vlakken, Origin)',
22:'FeatureTreeBody.tsx rollback; full 68/68 en relations 14/14 (RG)',
23:'features 65/65 (logs/regression-rerun.log), qa1 26/26 (RG)',
25:'gb 32/32 (RG); shots/gb-parentchild.png',
29:'self-test 8/8: B-rep exact, Fillet1 exact 44742,52, STEP exact (logs/self-test-nogpu.json); B-rep-pass 11/12, features groen bij herhaling (logs/regression-brep.log, logs/regression-rerun-brep.log)',
30:'Mesh primair in browser: statusbalk "Faceted 1/1" (shots/walk-18-done.png); plastics alleen mesh (F51/F121)',
31:'assembly 21/21, assembly2 15/15, configurations 25/25 (RG); shots/deurkruk-assembly.png',
35:'explode 18/18, asmcut 3/3 (RG); shots/deurkruk-exploded.png',
37:'drawing2 13/13, section 9/9, drawingfix 16/16, viewlayout 16/16 (RG); shots/drawfix-three.png, shots/deurkruk-tekening.png',
39:'drawingfix 16/16, drawopts 21/21, annotations 3/3+4/4+3/3 (RG); shots/drawfix-tables.png',
42:'configurations 25/25 (RG)',
44:'shots/e22-equations-applied.png; QA E1 circulair gemeld (logs/qa-strict-tests.log)',
45:'shots/e19-mass-properties.png, shots/e20-measure.png',
46:'draftcheck 9/9, thickness 2/2 (RG); geen numerieke assert op undercut/thickness',
47:'self-test: "Save writes the .kcad atomically and keeps a .bak" (logs/self-test-nogpu.json)',
48:'self-test STEP exact (logs/self-test-nogpu.json); step 11/11 mesh én B-rep (RG, logs/regression-brep.log); shots/step-imported.png',
49:'MenuBar.tsx:149-153 STL, MenuBar.tsx:278 "Save As ▸ 3MF"; gb (exportopties) 32/32 (RG)',
51:'shots/walk-18-done.png, shots/deurkruk-assembly.png, shots/walk-02-front-plane-rmb.png; maar context-toolbar faalt op Linux (F144)',
}
for k,v in EV.items(): rows[k]['ev'] = v.replace('(RG', '(' + RG).replace(' RG)', ' ' + RG + ')').replace(', RG,', ', ' + RG + ',')
w = {A:1, D:0.5, O:0, K:0}
from collections import Counter as _C
pct_qa = round(100*sum(w[r['status']] for r in rows)/len(rows), 1)
# --- teamronde: strengste verdedigbare pariteit (team/strati.md, riki.md, webi.md, risk.md, mt5dev.md) ---
def t(i, st, why):
    r = rows[i]; r['status_qa'] = r['status']; r['status'] = st; r['ev'] = r['ev'] + ' — Teamronde: ' + why
t(2, D, 'deels (Strati, Riki, Risk, Webi): AlongXYZ komt 0× voor in src; bewijs alleen code + unit-test (relations2.test.ts)')
t(10, K, 'kapot (MT5 Dev): stil fout volume op beide kernels (F139 mesh, F140 B-rep); stil fout resultaat ⇒ kapot')
t(29, D, 'deels (Strati, Risk, MT5 Dev): de exacte kernel geeft stil een fout volume (F140, Kritiek) op precies dit pad')
t(40, D, 'deels (Strati, Risk, Webi): alleen unit-tests (autoMarks.test.ts, hlr.test.ts); geen verborgen lijnen in de shots; centermarks ontbreken in Detail B (shots/deurkruk-tekening.png)')
t(51, D, 'deels (Riki, Risk): context-toolbar reproduceerbaar rood (inventory47, videos46; logs/regression-rerun.log, F144)')
rows[30]['ev'] = 'Plastics alleen mesh (F51/F121); mesh-terugval/preview/worker fout bij gatrand-fillet (F139). Correctie teamronde: de shot "Faceted 1/1" (shots/walk-18-done.png) komt uit de e2e-build (TEST_HOOKS → mesh); een gewone browserbuild zet B-rep aan (brepRefine.ts:37); of de OCCT-worker in de browserrelease draait: niet geverifieerd'
rows[24]['ev'] = 'e2e/reorder.mjs sleept met dragTo, reorder 10/10 (logs/regression.log:94); FeatureTreeBody.tsx:213 + reorder.test.ts. Teamronde: blijft aanwezig (e2e-bewijs, niet alleen code)'
from collections import Counter
c = Counter(r['status'] for r in rows)
pct = round(100*sum(w[r['status']] for r in rows)/len(rows), 1)
json.dump({'rows': rows, 'counts': dict(c), 'pct': pct, 'pct_0_5_1': P['pct'], 'pct_qa_voor_teamronde': pct_qa, 'team': {'Strati': 66.9, 'Riki': 68.5, 'Risk': 66.9, 'MT5 Dev': 68.5, 'Webi': 'geen getal; rij 3 overgeteld, 0/62 rijen met SOLIDWORKS-referentie'}}, open('/workspace/phlippo-cad/report-0.5.10/parity.json','w'), ensure_ascii=False, indent=1)
print(len(rows), dict(c), pct)
for r in rows:
    if r['status'] != r['old']: print(' ', r['item'][:50], r['old'], '->', r['status'])
