import json, copy
D = '/workspace/phlippo-cad/report-0.5.11/'
P = json.load(open(D + 'parity-0.5.10.json'))
R = json.load(open(D + 'tools/results-0511.json'))
rows = [copy.deepcopy(r) for r in P['rows']]
for r in rows: r['old'] = r['status']
A, Dl, O, K = 'aanwezig', 'deels', 'ontbreekt', 'kapot'
def s(n, st, ev): rows[n-1]['status'] = st; rows[n-1]['ev'] = ev
br, rl = R['brep'], R['release']
f = lambda x: f'{x[0]}/{x[1]}' if x else 'loopt'
s(11, A, 'F139 opgelost (mesh T1 verlies 97,61/138,46 vs 96,80/137,25), F140 ingetrokken als QA-fout; B-rep T1/T2/T3 exact = formule (logs/qa-ext-tests.log, logs/qa-t3diag.log); filletopts groen in mesh-pass')
s(28, A, 'T1 Ø35→Ø50: rand teruggevonden en correct afgerond op mesh én B-rep (logs/qa-ext-tests.log)')
s(29, Dl, 'Gesplitste rand (T3) en revolve (T2) correct op beide kernels; sweep/loft-randen na maatwijziging niet getest')
s(30, A, 'self-test 8/8 zonder GPU en met SwiftShader: B-rep exact 44858,407, Fillet1 exact 44742,522, STEP exact (logs/self-test-*.json)')
s(31, Dl, 'Plastics behalve Dome nog mesh (F51/F121); ellips/spline als segmenten (F175); wrap-patch polyhedraal')
s(35, A, 'M2: nieuwste mate gemarkeerd (F141 opgelost), M5 over/onder, "Not Converged" in statusbalk (StatusBar.tsx:111)')
s(39, A, 'drawing 28/28 op Linux HEAD (F10 opgelost; logs/regression-mesh.log)')
s(55, A, 'Frames / Additional Materials; rename-trademarks.cjs bewaakt; disclaimer (shots/home-brep.png); neutral-comments ook over e2e')
s(57, A, 'desktop-recover 21/21 (crash-herstel, eigen kopie per document, opent dirty), desktop-autosave ok')
s(58, A, 'viewpanes 35/35 incl. zonder WebGL, self-test zonder GPU 8/8 en softGL 8/8, desktop-nohooks 10/10')
s(61, A if (br and br[0]==br[1] and rl and rl[0]==rl[1]) else Dl, f'vitest 487/487; Linux-box mesh 98/98, B-rep {f(br)}, release {f(rl)}; zelftests 8/8')
s(62, Dl, 'Op de Linux-box reproduceerbaar groen (mesh 98/98 op HEAD), maar geen groene Actions-run op HEAD (quotum; F176)')
s(20, Dl, 'Naam nu "Frames" en gh 29/29 eerder; profielbibliotheek, end caps/gussets niet tegen SOLIDWORKS gemeten')
s(52, Dl, 'Context-toolbar nu groen op Linux (F144), maar CommandManager/taakvenster niet pixel- of gedragsgewijs naast SOLIDWORKS gelegd')
s(53, Dl, 'Ongewijzigd: 45/379 opties werken (F112); Export biedt IGES/DWG zonder exporter (F171)')
w = {A: 1, Dl: 0.5, O: 0, K: 0}
from collections import Counter
c = Counter(r['status'] for r in rows)
pct = round(100 * sum(w[r['status']] for r in rows) / len(rows), 1)
ref = [i+1 for i, r in enumerate(rows) if i+1 in (3,6,7,10,15,16,17,18,19,20,33,37,41,47,52,54,56)]
json.dump({'rows': rows, 'counts': dict(c), 'pct': pct, 'pct_0_5_10': P['pct'], 'sw_ref_nodig': ref}, open(D + 'parity.json', 'w'), ensure_ascii=False, indent=1)
print(len(rows), dict(c), pct, 'was', P['pct'])
