import json, copy, re, os
D = '/workspace/phlippo-cad/report-0.5.11/'
B = json.load(open(D + 'findings-0.5.10.json'))
F = {f['id']: copy.deepcopy(f) for f in B}
for f in F.values(): f['old'] = f['status']
def done(p):
    try: s = open(D + p, encoding='utf8', errors='replace').read()
    except FileNotFoundError: return None
    m = re.findall(r'DONE (\d+)/(\d+) green, (\d+) optional', s)
    return (int(m[-1][0]), int(m[-1][1]), int(m[-1][2])) if m else None
BR = done('logs/regression-brep.log'); RL = done('logs/regression-release.log')
def fmt(r, n): return f'{r[0]}/{r[1]} groen, {r[2]} skips' if r else f'nog niet afgerond (zie {n})'
BRs, RLs = fmt(BR, 'logs/regression-brep.log'), fmt(RL, 'logs/regression-release.log')
BRok = bool(BR and BR[0] == BR[1]); RLok = bool(RL and RL[0] == RL[1])
MESH = 'Linux-box HEAD db0d4b2, mesh-pass 98/98 groen, 0 skips (logs/regression-mesh.log)'
def up(i, status, ev, sev=None, prio=None, title=None, fix=None, repro=None):
    f = F[i]; f['status'] = status
    f['ev'] = '0.5.11: ' + ev + ' || 0.5.10: ' + f['ev'][:400]
    if sev: f['sev'] = sev
    if prio: f['prio'] = prio
    if title: f['title'] = title
    if fix: f['fix'] = fix
    if repro: f['repro'] = repro
OP, DE, OPEN, NV, IN = 'Opgelost', 'Deels opgelost', 'Open', 'Niet geverifieerd', 'Ingetrokken (QA-fout)'
up('F10', OP, 'drawing 28/28 op Linux (' + MESH + '); Ø35-maat wordt gepakt en hersteld na reload.')
for i in ('F16', 'F21', 'F22'):
    up(i, NV, 'Niet te meten zonder SOLIDWORKS-referentie naast elkaar (zelfde model, zelfde resolutie). Geen wijziging in 0.5.11.')
up('F24', DE, 'Niet opnieuw onderzocht in 0.5.11 (geen commit raakt het); status ongewijzigd overgenomen.')
up('F28', DE, 'Niet opnieuw onderzocht in 0.5.11; status ongewijzigd overgenomen.')
up('F31', DE, 'Exitcodes en DONE-regel met skip-budget werken (' + MESH + '). Een groene GitHub Actions-run op HEAD ontbreekt: laatste runs 41542259973 (c1fc039) en 41551048560 (75ceeea) hadden rode shards; de run op 772236a startte niet (minutenquotum).', sev='Major', prio='P0')
up('F38', DE, 'README heeft nu "Status 0.5.11 (in voorbereiding)" (README.md:47); TASKS.md noemt nog "qaBrep.test.ts (11)" terwijl het er 13 zijn (README klopt).', sev='Minor', prio='P3')
up('F46', DE, 'Release: worker standaard (rebuildworker 10/10 Linux, 152 s). Browser-e2e en dev draaien mesh-CSG nog op de UI-thread; budget 45 s (F137).', prio='P2')
up('F47', DE, 'T1 (gatrand Ø35→Ø50), T2 (revolve) en T3 (gesplitste rand) nu correct op mesh én B-rep (logs/qa-ext-tests.log, logs/qa-t3diag.log). Naamgeving over sweep/loft/patterns/shell niet getest.', prio='P2')
up('F48', DE, 'Volume-kruiscontrole B-rep↔mesh bestaat (volumeCheck.ts:8) maar met drempel 0,5 %: te ruim (F172).', prio='P2')
up('F49', OPEN, 'win/signature-0.5.11.txt: setup, portable en win-unpacked exe alle NotSigned; nu eerlijk gemeld ("not code-signed: there is no certificate").', prio='P2')
up('F50', OP, 'Zichtbare termen omgezet: tab "Frames" (Ribbon.tsx:47, customize.tsx:17), knop "Frame" (Ribbon.tsx:476), "Additional Materials"; rename-trademarks.cjs:25-27 bewaakt Weldment(s)/Sustainability; disclaimer legal.ts:3 en in Welcome (shots/home-brep.png). Interne ids (weldment) blijven, niet zichtbaar. Juridische toets door een mens blijft aanbevolen.')
up('F51', DE, 'Kritiek → Major: per feature nu een waarschuwing "has no exact (B-rep) version … Faceted" (rebuild.ts:3313-3314) en "Faceted n/m" in de statusbalk. Nog steeds mesh: Indent, Lip/Groove, Snap Hook, Mounting Boss, wrap-patch polyhedraal; ellips/spline-randen als korte segmenten in B-rep (occt/brep.ts:4, :68).', sev='Major', prio='P1')
up('F54', DE, 'Kritiek → Major. Op de Linux-box (xvfb + SwiftShader) is de mesh-pass nu 98/98 groen op HEAD, incl. drawing, inventory47, videos46, sheetexport, features (' + MESH + '); B-rep-pass ' + BRs + '; release-pass ' + RLs + '. Wat ontbreekt: een groene Actions-run op HEAD (quotum op).', sev='Major', prio='P0')
up('F93', DE, 'Claims hebben nu platform+commit+log (README, win/linux/README.md). Resterend: "checks, desktop groen" op Linux staat in win/linux/README.md zonder ruw log van die jobs; Windows-logs zijn van 0495219/1fd00e3, niet van HEAD db0d4b2; TASKS "(11)" vs 13; docs/28 zegt over F142 alleen ".gitignore" terwijl TASKS terecht "uit de index" meldt.', sev='Major', prio='P1')
up('F94', OP, 'Pack and Go, MBD en Weldments zichtbaar weg (zie F50).')
up('F97', DE, 'win/desktop-installed-0.5.11.txt meldt alleen "19/19 checks passed": geen commit, geen lijst van checks, geen tijd. Packaged smoke bestaat, maar het bewijs is niet controleerbaar.', prio='P2')
up('F98', DE, 'Remote Actions-runs bestaan met links (41542259973, 41551048560), maar niet op HEAD en niet volledig groen.', prio='P1')
up('F99', OP, 'Statusbalk "Faceted n/m" (shots/viewpanes-four.png) en per-feature waarschuwing dat massa en STEP benaderd zijn (rebuild.ts:3314, :3317).')
up('F105', OP if (BRok and RLok) else DE, 'CI draait nu een volledige release-pass op ?kernel=brep&rebuild=worker (ci.yml:89-115) plus 12 brep-scripts (ci.yml:134-136). Box: B-rep-pass ' + BRs + ', release-pass ' + RLs + '.', prio='P1')
up('F111', OP, 'T3 (rand gesplitst door eerder ingevoegde sleuf): mesh 30439,067 en B-rep 30439,911 tegen theorie 30439,911 mm³ (logs/qa-ext-tests.log, logs/qa-t3diag.log).')
up('F112', DE, 'Ongewijzigd: WIRED_PREFS telt 45 sleutels (prefsWired.ts:5) van 379 in prefsSchema.ts; 334 grijs "Not available". Eerlijk, maar 88 % van de Options doet niets.', prio='P2')
up('F114', DE, 'Nog steeds geen IGES-, DWG- of Parasolid-export; wel PDF/DXF van tekeningen. Zie ook F171.', prio='P2')
up('F115', OP, 'ViewPane gebruikt hasWebGL/renderToCanvas uit glSetup (ViewPane.tsx:7, :78); viewpanes 35/35 incl. zonder-WebGL-stap (logs/viewpanes.log, shots/viewpanes-nowebgl.png); self-test zonder GPU 8/8.')
up('F117', OPEN, 'Samengevoegd met F49: NotSigned (win/signature-0.5.11.txt).', prio='P2')
up('F118', OP, 'Gate bestaat: tools/bundle-budget.cjs:8 BUDGET_KB=860; release-build 854,86 kB (logs/build-release.log). Nog 5,14 kB ruimte: zie F174.')
up('F119', OP, 'Runner telt skips en heeft een skip-budget per script (run-regression.mjs:24, :64, :77); mesh-pass "0 optional step(s) skipped".')
up('F120', OP, 'CI-brep-pass 12 scripts + volledige release-pass op B-rep (ci.yml:89-136).')
up('F121', DE, 'Dome exact (qaBrep "a Dome on a round pad is an exact sphere segment"); Indent, Mounting Boss, Snap Hook, Lip/Groove nog alleen mesh en vereenvoudigd; geen vergelijking met SOLIDWORKS-maatvoering.', prio='P2')
up('F122', DE, 'autoMarks/hlr bestaan met unit-tests; correctheid tegen een SOLIDWORKS-tekening niet gemeten (referentie nodig).', prio='P2')
up('F124', OPEN, 'Ongewijzigd bewuste gaten (docs/24): Instant2D, Magnified Selection, 3D-schetsmaten, virtual-sharp flange.', prio='P3')
up('F125', OP, 'rebuildworker 10/10 op Linux in 152 s (één run; logs/regression-mesh.log).')
up('F126', DE, 'Windows-logs zijn nu ruwe runner-output met kop (commit/platform), maar van 0495219 (mesh/release 98/98) en 1fd00e3 (brep 12/12), niet van HEAD db0d4b2.', prio='P2')
up('F129', DE, 'TASKS.md "qaBrep.test.ts (11)" vs werkelijk 13; docs/28 F142-tekst verouderd.', prio='P3')
up('F130', DE, 'Deels: mateStatus.test.ts:16 (M1) en :30 (M2, "one is flagged") staan in de repo; M3 (keten van 4), M5 (gesloten lus) en de eis dat de nieuwste mate gemarkeerd wordt zitten alleen in de externe QA-tests (tools/qa-src/qaStrict.test.ts). src/qa/qaStrict.test.ts bevat alleen geometrie (8 tests).', prio='P2')
up('F134', OPEN, 'line-budget.cjs:12 CAPS staan nog op de huidige grootte (rebuild.ts cap 3398, werkelijk 3393); geen doelwaarde.', prio='P3')
up('F136', OP, 'neutral-comments.cjs scant nu ook e2e/ (neutral-comments.cjs:61-74); ci-checks ok (logs/ci-checks.log).')
up('F137', OPEN, 'Budget nog 45 s (store.ts:1234, :1261 rebuildBudgetMs); browser-mesh-CSG op de UI-thread.', prio='P3')
up('F138', DE, 'npm audit: 15 moderate, 0 high (was 2 high) in de dev-keten electron-builder/minimatch; productie-afhankelijkheden 0 (logs/audit.json, logs/audit-prod.json).', prio='P3')
up('F139', OP, 'Mesh T1: verlies 97,61 mm³ bij r=17,5 (theorie 96,80) en 138,46 bij r=25 (theorie 137,25); filletApplied=true; B-rep exact 54282,076 / 44227,798 = formule (logs/qa-ext-tests.log).')
up('F140', IN, 'Diagnose (logs/qa-t3diag.log): onze 0.5.10-test koos met reduce() de eerste van de gelijke 80 mm-randen; onder B-rep is dat de z=0-rand, die de sleuf niet snijdt. Op die rand geeft B-rep exact 30431,327 = 30500−80·CORNER(2) (verschil 0). Op de juiste rand z=−40 geeft B-rep exact 30439,911 = 30500−70·CORNER(2). Er was geen fout in het programma; de reactie van de ontwikkelaar ("niet reproduceerbaar") klopte.', sev='—', prio='—')
up('F141', OP, 'M2: de nieuwste mate (m2) wordt nu als conflict gemarkeerd (logs/qa-ext-tests.log).')
up('F142', OP, 'graphify-out zit niet in de HEAD-archive (uit de index).')
up('F143', OP, 'Zie F115: ViewPane veilig zonder WebGL; viewpanes 35/35.')
up('F144', OP, 'inventory47 18/18 en videos46 25/25 op Linux (' + MESH + ').')
up('F145', OP, 'features 65/65 op mesh (163 s) en B-rep (352 s) op Linux.')
up('F146', OP, 'sheetexport 12/12, 0 skips op Linux.')
up('F147', DE, 'ci.yml splitst nu in matrix-jobs (release ×3, mesh ×3, brep) met continue-on-error en eind-gates; niet bewezen op HEAD (geen run).', prio='P0')
up('F148', DE, 'Logs hebben nu een kop met commit en platform (run-regression.mjs:48-52), maar zijn van eerdere commits dan HEAD (zie F126).', prio='P1')
up('F149', DE, 'Grotendeels opgelost: claims noemen platform/commit. Uitzondering: "checks, desktop groen" (win/linux/README.md) zonder ruw log.', prio='P1')
up('F150', OP, 'Geen valse signing-claim meer: signature-0.5.11.txt zegt "not code-signed: there is no certificate". Signing zelf: F49.')
up('F151', DE, 'Self-tests draaien nog ongepackaged; packaged smoke op Windows bestaat maar het log is onvolledig (F97).', prio='P2')
up('F152', OP, 'src/qa/qaStrict.test.ts (8 mesh) en qaBrep.test.ts (13 B-rep) in de repo, draaien in vitest 487/487; T1/T3 als gate. Mate-tests M3/M5 ontbreken (F130); toleranties te ruim (F173).')
up('F153', OP, 'desktop-recover 21/21: twee documenten "Part1" krijgen elk een eigen kopie (logs/desktop-recover.log).')
up('F154', OP, 'desktop-recover: herstelde kopie opent als "(Recovered)" en dirty; Save vraagt een bestand.')
up('F155', OP, 'Zie F119: skip-budget per script, DONE-regel toont het aantal skips.')
up('F156', OP, 'desktop-recover: een door de renderer meegegeven map wordt genegeerd.')
up('F157', OP, 'Four View toont grijze, belichte modellen met studio-omgeving (shots/viewpanes-four.png, viewpanes-four-dark.png).')
up('F158', OP, 'CI release-pass = ?kernel=brep&rebuild=worker over alle scripts (ci.yml:89-115).')
up('F159', DE, 'Kruiscontrole bestaat (volumeCheck.ts:8 VOLUME_MISMATCH = 0.005) maar 0,5 % is te ruim om een gemiste of extra fillet te vangen (F172).', sev='Major', prio='P1')
up('F160', OP, 'Eén log per pass/shard (run-regression.mjs:45-48): regression-0.5.11.txt, …-brep-…, …-brep-worker-….')
up('F161', DE, 'Niet opnieuw visueel beoordeeld; importStep loopt via OCCT (occtClient.ts:50).', prio='P3')
up('F162', OP, 'desktop-recover: gpu.json bewaart alleen de keuze, geen enable-unsafe-swiftshader.')
up('F163', OP, 'rename-trademarks.cjs:25-27 dekt Weldment(s), Sustainability(-Extras).')
up('F164', OP, 'src/core/drawing/dbg.test.ts bestaat niet meer.')
up('F165', OP, 'persistence.ts:139 zet SW-Density om naar Density; legacyNames.test.ts:11.')
up('F166', OP, 'MATE_PASSES (assembly.ts:430-444) en statusbalk "Not Converged" (StatusBar.tsx:111).')
up('F167', IN, 'Volgt uit F140: de oorzaak was onze testopstelling, niet het programma.', sev='—', prio='—')
up('F169', OP, 'Theoriewaarden opnieuw met de gesloten vorm berekend; T2 mesh 432,68 vs 428,74 (logs/qa-ext-tests.log).')
NEW = [
 ('F171', 'UI/UX', 'Minor', 'P3', 'Options ▸ Export en Import tonen IGES en DXF/DWG als formaat zonder exporter', 'prefsSchema.ts:313-314 biedt "IGES" en "DXF/DWG" (export.format staat niet in WIRED_PREFS, dus grijs), maar er is geen IGES/DWG-export (F114).', 'Tools ▸ Options ▸ Export ▸ File Format.', 'Formaten zonder exporter uit de lijst halen of markeren als "niet beschikbaar".'),
 ('F172', 'Kernel', 'Major', 'P1', 'Volume-kruiscontrole B-rep↔mesh (0,5 %) te ruim om een fillet-fout te vangen', 'VOLUME_MISMATCH = 0.005 (volumeCheck.ts:8). Op T3 (30500 mm³) is 0,5 % = 152 mm³, terwijl een complete fillet van 70 mm R2 maar 60,1 mm³ is en het F140-verschil 8,6 mm³. Een gemiste of extra fillet blijft dus onzichtbaar.', 'T3 met B-rep; vergelijk |V_brep−V_mesh| met 0,005·V.', 'Absolute + relatieve drempel per feature: |ΔV| < max(0,5 mm³, 0,1 % van het featurevolume i.p.v. bodyvolume).'),
 ('F173', 'Testen/CI', 'Minor', 'P2', 'Strikte QA-tests in de repo hebben te ruime toleranties', 'qaStrict.test.ts:26 accepteert |V−verwacht|/sharp < 0,3 % (≈160 mm³ op T1, meer dan het hele fillet-verlies van 97 mm³; gelukkig dekken :24-25 het verlies met ±5 %); :69 accepteert 25 mm³ bij "stadium". qaBrep gebruikt exacte waarden.', 'Lees qaStrict.test.ts:19-70.', 'Mesh-toleranties op ±2 % van het verlies, B-rep op 1e-3 mm³.'),
 ('F174', 'Performance', 'Minor', 'P3', 'Bundelbudget bijna op: 854,86 van 860 kB', 'logs/build-release.log: 5,14 kB ruimte; elke feature van betekenis tikt de gate.', 'npm run build (release).', 'Code-splitting van tekeningen/assemblies of budget bewust herzien met motivatie.'),
 ('F175', 'Kernel', 'Major', 'P2', 'Ellipsen en splines worden in B-rep als korte segmenten gebouwd', 'occt/brep.ts:4 en :68: "ellipses and splines are followed by short segments for now". Bodies met zulke profielen heten exact, maar hun vlakken zijn polygonaal; massa en STEP wijken af van SOLIDWORKS.', 'Extrude een ellips 40×20 × 10 mm; exact = π·20·10·10 = 6283,185 mm³; vergelijk met Mass Properties en STEP-vlaktypes.', 'Geom_Ellipse / Geom_BSplineCurve via OCCT gebruiken.'),
 ('F176', 'Testen/CI', 'Major', 'P0', 'Geen enkel volledig groen bewijs op HEAD db0d4b2 buiten deze QA-box', 'Windows-logs zijn van 0495219/1fd00e3, Actions-runs van c1fc039/75ceeea; HEAD zelf is alleen op de QA-box gedraaid. Logkop op de box zegt "commit unknown" (git-archive zonder .git).', 'Vergelijk de commit-kop van elk log met HEAD.', 'Eén Actions-run op de release-commit met alle jobs groen; artefacten met commit-kop bewaren.'),
]
for (i, area, sev, prio, title, ev, repro, fix) in NEW:
    F[i] = {'id': i, 'area': area, 'sev': sev, 'old': '—', 'title': title, 'status': 'Nieuw', 'prio': prio, 'ev': '0.5.11: ' + ev, 'repro': repro, 'fix': fix}
L = sorted(F.values(), key=lambda f: int(f['id'][1:]))
json.dump(L, open(D + 'findings.json', 'w'), ensure_ascii=False, indent=1)
from collections import Counter
openst = (DE, OPEN, NV, 'Nieuw')
c = Counter(f['status'] for f in L)
sev = Counter(f['sev'] for f in L if f['status'] in openst)
print(len(L), dict(c), 'open per sev', dict(sev))
print('Kritiek open:', [f['id'] for f in L if f['status'] in openst and f['sev'] == 'Kritiek'])
was_open = [f for f in B if f['status'] != 'Opgelost']
print('was open', len(was_open), 'now closed', sum(1 for f in was_open if F[f['id']]['status'] == OP), 'withdrawn', sum(1 for f in was_open if F[f['id']]['status'] == IN))
json.dump({'brep': BR, 'release': RL, 'counts': dict(c), 'open_sev': dict(sev)}, open(D + 'tools/results-0511.json', 'w'))
