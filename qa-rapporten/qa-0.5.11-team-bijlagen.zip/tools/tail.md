
## 7. Teamoordeel

Vijf reviewers lazen dit rapport, de logs, shots en de code (team/strati.md, team/riki.md, team/webi.md, team/risk.md, team/mt5dev.md). Regel: **de strengste score en de strengste ernst per bevinding winnen.** Elke teamclaim die de score of een ernst verandert, heeft QA zelf nagelopen in code of logs. Wat QA niet zelf kon nagaan, staat als "niet geverifieerd".

### 7.1 Oordeel per teamlid

| Teamlid | Score | Klaar | Publiceren | Eigen gebruik | Top 3 (kort) |
|---|---|---|---|---|---|
| QA (eerste oordeel) | 6/10 | NO-GO | NO-GO | Voorwaardelijk GO | F140 stil fout op B-rep; Linux 93/98; claims |
| Strati | **5/10** | NO-GO | NO-GO | Voorwaardelijk GO | Stille geometrie (F140/F139/F111); eerlijkheid claims (98/98 hergebruikt, 19/19 zonder log); gevel zonder product (F112, F50, signing, CI) |
| Riki | **5/10** | NO-GO | NO-GO | Voorwaardelijk GO | F140 op de releasekernel; F139/F51 mesh-gatrand; CI verbergt B-rep/worker (F147) en geen Actions-run |
| Webi | **5/10** | NO-GO | NO-GO | Voorwaardelijk GO | F140/F139; bewijsintegriteit (round2b = 0.5.9-run); pariteit zonder SOLIDWORKS-referentie |
| Risk & Optimization | 6/10 | NO-GO | NO-GO | Voorwaardelijk GO | F140 + geen volume-kruiscontrole (F159) + F139; CI vertelt de waarheid niet (F147, F155, F160); AutoRecover-dataverlies (F153/F154) |
| MT5 Developer | **5/10** | NO-GO | NO-GO | Voorwaardelijk GO | F140 (+F111); F139; CI en claims (F54/F31/F93) |
| **Eindoordeel** | **5/10** | **NO-GO** | **NO-GO** | **Voorwaardelijk GO** | Strengste score wint (4 van 5 reviewers: 5/10) |

Pariteit per reviewer: Strati 66,9 % (41,5/62), Riki 68,5 %, Risk 66,9 % (41,5/62), MT5 Dev 68,5 %, Webi geen getal (rij 3 overgeteld; rijen 3, 25 en 41 alleen code, 9 en 34 alleen unit-tests; 0 van 62 rijen met een SOLIDWORKS-referentie). **Strengste verdedigbare combinatie: 66,1 % (41/62)**: rij 3, 30, 41 en 52 naar deels, rij 11 naar kapot (stil fout resultaat op beide kernels). Rij 25 (reorder) blijft aanwezig: daar is e2e-bewijs (reorder 10/10, dragTo). Rijen 8, 14 en 24 blijven aanwezig met de notitie dat features pas bij herhaling groen werd (F145). Ook 66,1 % is een bovengrens zolang er geen beeld-voor-beeld-vergelijking met echte SOLIDWORKS is (F16/F21/F22).

### 7.2 Ernstcorrecties (wie wilde wat)

{{SEV_TABLE}}

Niet gewijzigd en door alle reviewers aanvaard: F112 → Major, F115 → Major (F143 resteert). F140, F51 en F93 blijven unaniem Kritiek.

### 7.3 Voorwaarden voor eigen gebruik (samengevoegd)

Alle zes oordelen geven een voorwaardelijk GO voor eigen concept- en hobbywerk, onder deze voorwaarden:

1. **Alleen de desktop-release met B-rep aan** (standaard). Niet de browser en niet de mesh-terugval vertrouwen. Staat er "Faceted n/m" in de statusbalk, dan is dat body een mesh-benadering: geen volumes of STEP daarvan vertrouwen (F51/F139).
2. **Geen fillets op randen die later door een sleuf/boss/snede gesplitst worden**, en geen fillets op gatranden van mesh-bodies. Doe je het toch: na **elke** fillet of chamfer Mass Properties nameten tegen je verwachting (F140/F139/F111).
3. **Massa en volume altijd zelf narekenen** bij werk dat moet kloppen; niets voor productie, klanten of maakwerk zonder eigen meting (F140/F139/F159).
4. **Zelf regelmatig opslaan met Ctrl+S** en eigen back-ups maken. Vertrouw AutoRecover niet bij twee open documenten met dezelfde naam, sla een herstelde kopie meteen op, en gooi de .bak/.bak2-kopieën niet weg (F153/F154; main.cjs:142-144).
5. **Geen Two/Four View** op een pc zonder WebGL (crasht de hele UI, F143), en vertrouw de extra vensters niet visueel (zwart, F157).
6. **Mate-conflicten zelf nakijken**: bij een conflict markeert Phlippo de oudere mate (F141); niet-convergentie is niet zichtbaar (F166).
7. **Niet publiceren of delen** (installer, website): ongesigneerd (F150), Weldments/trade dress (F50/F163), CI onbewezen (F31/F54/F147).

### 7.4 Nieuwe bevindingen uit de teamronde (ontdubbeld, F147–F170)

De reviewers nummerden elk vanaf F147; die nummers botsten. Hieronder de unieke nummering met de oorspronkelijke ID's als alias.

{{NEW_TABLE}}

## 8. Fixlijst voor Claude (na teamronde)

### P0 (eerst; blokkeert "klaar")
1. **F140 + F167 + F111**: eerst diagnose: log de gematchte mesh-randen en de gevonden OCCT-randen voor QA-T3. Maak B-T3 een B-rep-unit-test die 30439,91 ± 0,01 mm³ eist, en repareer pas dan de matcher (splitPieces filtert al colineair en binnen de rand; de fout zit waarschijnlijk in de B-rep-vertaling, niet geverifieerd).
2. **F159**: volume-kruiscontrole exact tegen mesh in brepRefine.ts (bij > 0,5 % afwijking: melding en feature markeren). Goedkoop, en het maakt F140-achtige fouten zichtbaar.
3. **F139**: de mesh-fillet op een gatrand moet volume wegnemen of netjes weigeren met een fout. Test op het verlies t.o.v. het eigen scherpe volume (QA-T1, Ø35 en Ø35→50).
4. **F147 + F31 + F120 + F105**: ci.yml opsplitsen in drie stappen (mesh, B-rep, worker) met id + continue-on-error en een eindgate; daarna een **link naar een groene GitHub Actions-run** op deze HEAD.
5. **F54/F144/F10**: Linux-regressie echt groen: drawing (Ø35 picked:false), inventory47 en videos46 (context-toolbar).

### P1
6. **F93/F148/F149/F126/F38/F129**: claims alleen nog met platform, commit-hash en een ruw log van precies die commit; logs nooit hergebruiken of samenplakken; "0.5.10 geïnstalleerd 19/19" onderbouwen of schrappen; README-status naar 0.5.10.
7. **F152**: de QA-tests (qaStrict, qaBrep) in de repo opnemen als vitest-suite in CI.
8. **F155/F119 + F160**: skipbudget per script en skips in de eindgate; regressielog per pass een eigen bestandsnaam.
9. **F158/F46**: de hoofdregressie op het releasepad (worker + B-rep) draaien.
10. **F153/F154**: AutoRecover op pad/document-id, herstel als dirty "(Recovered)", fsync, en desktop-restore-autosave in CI.
11. **F145**: oorzaak van de Sweep1-fout "path sketch has no lines" vinden (app- of testrace).
12. **F143/F157**: ViewPane via createRenderer met studio-omgeving en nette melding zonder WebGL; een ErrorBoundary per venster.
13. **F50/F163/F94**: "Weldments" en "Sustainability Extras" hernoemen, de merk- en neutral-checks uitbreiden, docs/26 niet publiceren.
14. **F51**: B-rep ook voor de plastics-features, en een duidelijke "Faceted"-waarschuwing bij elke mesh-terugval.

### P2
15. **F150/F49/F117**: code-signing (of een expliciete "unsigned"-melding) vóór elke publieke verspreiding; AuthenticodeSignature bij elke release loggen.
16. **F151/F97**: self-test op de geïnstalleerde exe (Windows), plus een run met WebGL echt uit.
17. **F156**: recover-map in main vastleggen; geen renderer-gekozen pad.
18. **F112**: de meest gebruikte opties echt aansluiten (backup/AutoRecover, eenheden, grid/snap, kleuren).
19. **F114**: IGES (en eventueel Parasolid via OCCT); DWG optioneel.
20. **F122**: verborgen lijnen en centermarks met een e2e-check en een shot; centermarks in detailaanzichten.
21. **F125/F105**: features- en rebuildworker-e2e deterministisch maken (wachten op "rebuild klaar").
22. **F121**: plastics op B-rep; Toolbox-light.

### P3
F141 (markeer de nieuwe mate), F166 (niet-convergentie tonen), F142 (graphify-out uit de repo), F138 (audit), F146 (pathToFileURL), F136 (neutral-comments over e2e/), F137 (rebuildbudget), F118 (bundelbudget), F134 (line-budget-doelen), F161 (shading/STEP-mesh), F162 (gpu.json), F164 (dbg.test.ts), F165 (SW-Density omzetten), F99 (test op de Faceted-indicator), F16/F21/F22 (pixelvergelijking naast echte SOLIDWORKS-shots).

## 9. Score per gebied (QA, bijgewerkt na teamronde)

| Gebied | 0.5.1 | 0.5.10 | Toelichting |
|---|---|---|---|
| Sketcher | 7 | 8 | Nieuwe relaties, conflictdetectie; 3D-schetsmaten en Instant2D ontbreken |
| Features | 6 | 7 | Plastics, sweep/loft/sheet metal/weldments aanwezig; veel op mesh-terugval |
| Topologie / robuustheid geometrie | 3 | 4 | T2 en mesh-T3 goed; B-rep-T3 (F140) en mesh-T1 (F139) stil fout |
| Assembly | 3 | 7 | Solver en conflict werken nu; mechanische mates ongetest; geen Toolbox |
| Tekeningen | 6 | 7 | Centermarks, HLR, PDF/DXF; Ø35-maat op Linux kapot |
| UI / look | 7 | 8 | Zeer dicht bij SOLIDWORKS; Options eerlijk maar grotendeels inert; "Weldments" |
| Import/export | 5 | 6 | STEP exact, PDF/DXF; geen IGES/DWG/Parasolid |
| Tests / CI / eerlijkheid | 4 | 4 | 454 unit, goede runner, desktop-checks werken; Linux rood, claims weer te rooskleurig |
| Release / installer | 4 | 4 | Builds OK; ongesigneerd terwijl het build-log "signing" meldt (F150) |
| **Totaal** | **5** | **5** | QA gaf eerst 6; na de teamronde 5 (strengste wint): stil foute geometrie op beide kernels, CI die B-rep/worker niet kan draaien, en claims die weer niet kloppen |

## 10. Voorwaardelijk gebruik

| Gebruik | Oordeel | Voorwaarde / reden |
|---|---|---|
| Eigen concept- en hobbymodellen, schetsen, eenvoudige onderdelen | **Ja, onder de voorwaarden van §7.3** | Desktop-release (B-rep) gebruiken; na elke fillet het volume/de vorm nakijken |
| Fillets op randen die later gesplitst worden (sleuf/boss over een gefilleteerde rand) | **Nee** | F140: een extra rand wordt stil afgerond |
| Fillet op gatranden op mesh-bodies ("Faceted" in de statusbalk) | **Nee** | F139: volume klopt niet, bij Ø35 zonder melding |
| Assemblages met standaard-mates | **Ja, met controle** | Solver werkt (M1–M5); bij een conflict markeert hij de oudere mate (F141); niet-convergentie onzichtbaar (F166) |
| Mechanische mates (cam, screw, rack-pinion…) | **Beperkt** | Geen gedragstests |
| Tekeningen naar PDF/DXF | **Ja, met controle** | Ø-maten nakijken (F10) |
| STEP uitwisselen | **Ja** | Exact via OCCT (self-test, step 11/11) |
| Werk voor klanten / maatvoering die moet kloppen | **Nee** | F139/F140/F159; geen IGES/DWG |
| Vertrouwen op AutoRecover | **Nee** | Sleutel op naam (F153), herstel als "opgeslagen" (F154); zelf Ctrl+S |
| Publiceren of delen (installer, website) | **Nee** | Ongesigneerd (F117/F150), "Weldments" (F50), CI onbewezen (F54/F147) |
| Zonder GPU / op een oude laptop | **Ja, met beperking** | Self-test 8/8 met software-GL (niet gepackaged, F151); vermijd 2/4-view (F143/F157) |

## 11. Werkwijze en beperkingen van deze QA

- Alle runs op de box (Linux, xvfb, Playwright-Chromium met SwiftShader, Electron 0.5.10 uit de kloon). De Windows-laptop is alleen gelezen. Het enige wat naar de laptop is geschreven, is dit rapport.
- De e2e-regressie is volledig gedraaid (mesh, B-rep, worker). De rode scripts zijn daarna opnieuw gedraaid om flakes van echte fouten te scheiden.
- De eigen tests (`tools/qa-src/` (qaStrict, qaBrep, qaDiag)) draaien met `npx vitest run` nadat je ze tijdelijk in `src/qa/` zet. Op de box zijn ze daarna uit de kloon verwijderd.
- Niet geverifieerd: pixelgelijkheid naast echte SOLIDWORKS-screenshots (F16/F21/F22), een GitHub Actions-run (privé-repo, geen toegang), de geïnstalleerde 19/19-claim voor 0.5.10, of het Windows-98/98-log gelijk is aan de release, de oorzaak van F140, of de Sweep1-fout (F145) in app of test zit, of de OCCT-worker in de browserrelease draait, het F143-crashscenario (alleen statisch), Webi's shading/STEP-punten (F161), en Strati's eigen build van 46a1bd9 (826,66 kB).
- Teamronde (2-11, ca. 15:25-16:00 CET): 5 reviews verwerkt (team/). QA heeft zelf nagelopen: de round2b-diff, round2.mjs in het 0.5.9-log en de commitdatum, ci.yml:38-46, README.md:46/55-56/90, TASKS.md:763/807/810/814, brepRefine.ts, main.cjs (recover, gpu), check.mjs, run-regression.mjs, dbg.test.ts, equations.ts:262, ViewPane.tsx + shots/m7-fourview.png, edgesets.ts:337-354, qaDiag.test.ts:45, en opnieuw Get-AuthenticodeSignature op de laptop (alleen lezen; win/signature-0.5.10.txt).
- Correcties t.o.v. de eerste versie van dit rapport staan als F168 (formule, round2b, 827 kB, CI groen, Windows-log, Faceted-bewijs, 19/19) en F169 (qaDiag-theorie).
- Bevindingen die niet opnieuw zijn getest, houden hun 0.5.1-status en zijn als "overgenomen" gemarkeerd in findings.json.
- Ernst: Kritiek = stil fout resultaat of een blokkade voor "klaar"; Major = belangrijk functioneel of procesgat; Minor = cosmetisch of laag risico. De strengste ernst wint.
