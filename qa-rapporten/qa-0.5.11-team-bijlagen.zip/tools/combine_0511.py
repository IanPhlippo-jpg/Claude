import re
D='/workspace/phlippo-cad/report-0.5.11/logs/'
def rd(p):
    try: return open(D+p,encoding='utf8',errors='replace').read()
    except FileNotFoundError: return ''
def done(s):
    m=re.findall(r'DONE (\d+)/(\d+) green, (\d+) optional',s); return tuple(map(int,m[-1])) if m else None
# brep: part1 (7 scripts, box reset before its DONE line) + part2
p1=rd('regression-brep-part1.log') or rd('regression-brep.log')
if not rd('regression-brep-part1.log'): open(D+'regression-brep-part1.log','w').write(p1)
l1=[l for l in p1.splitlines() if ' exit=' in l]; ok1=sum(' exit=0 ' in l for l in l1)
p2=rd('regression-brep-part2.log'); d2=done(p2)
if d2:
    open(D+'regression-brep.log','w').write('# gecombineerd: deel 1 (7 scripts, vóór box-reset) + deel 2 (7 scripts)\n'+p1.strip()+'\n'+p2.strip()+f'\nDONE {ok1+d2[0]}/{len(l1)+d2[1]} green, {d2[2]} optional step(s) skipped (combined)\n')
S=[rd(f'regression-release-shard{k}.log') for k in (1,2,3)]; ds=[done(s) for s in S]
if all(ds):
    open(D+'regression-release.log','w').write('# gecombineerd: 3 parallelle shards (E2E_SHARD k/3)\n'+'\n'.join(s.strip() for s in S)+f'\nDONE {sum(d[0] for d in ds)}/{sum(d[1] for d in ds)} green, {sum(d[2] for d in ds)} optional step(s) skipped (combined)\n')
print('brep',ok1,len(l1),d2,'release',ds)
