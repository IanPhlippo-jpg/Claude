import json
D='/workspace/phlippo-cad/report-0.5.10/'
F=json.load(open(D+'findings.json')); P=json.load(open(D+'parity.json'))
out=[open(D+'tools/head.md').read()]
c=P['counts']
out.append(f"\n## 5. Pariteitsmatrix (62 rijen)\n\nWeging: aanwezig = 1, deels = ½, ontbreekt/kapot = 0. **Pariteit: {str(P['pct']).replace('.',',')} %** (0.5.1: {str(P['pct_0_5_1']).replace('.',',')} %). Telling: {c.get('aanwezig',0)} aanwezig, {c.get('deels',0)} deels, {c.get('ontbreekt',0)} ontbreekt, {c.get('kapot',0)} kapot. Na de teamronde strenger gezet (QA-eerste telling: {str(P.get('pct_qa_voor_teamronde','')).replace('.',',')} %); afwijkingen staan vet met 'Teamronde:' in het bewijs. Ook dit is een bovengrens: geen rij is naast echte SOLIDWORKS-beelden gelegd. Elke 'aanwezig' verwijst naar een log, een shot of een code-regel. Alle genoemde logs/ en shots/ bestaan in deze map. Geen enkele rij is ingeschat zonder bewijs.\n\n| # | Gebied | Item | 0.5.1 | 0.5.10 | Bewijs |\n|---|---|---|---|---|---|")
for i,r in enumerate(P['rows']):
  st=r['status'] if r['status']==r['old'] else f"**{r['status']}**"
  out.append(f"| {i+1} | {r['area']} | {r['item']} | {r['old']} | {st} | {r['ev'].replace('|','/')} |")
from collections import Counter
op=[f for f in F if not f['status'].startswith('Opgelost')]
cs=Counter(f['sev'] for f in op)
out.append(f"\n## 6. Alle bevindingen\n\nTotaal {len(F)} bevindingen (F1–F{max(int(f['id'][1:]) for f in F)}). **Open: {len(op)}** ({cs['Kritiek']} Kritiek, {cs['Major']} Major, {cs['Minor']} Minor); opgelost: {len(F)-len(op)}. Nieuw in deze ronde: F138–F146 (QA) en F147–F170 (teamronde, ontdubbeld; aliassen in §7.4). Ernstcorrecties uit de teamronde: §7.2. Volledige data: findings.json. Het veld 'ev' begint met het 0.5.10-bewijs, gevolgd door de historie.\n\n### 6.1 Overzicht open bevindingen\n\n| Prio | ID | Ernst | Status | Gebied | Titel |\n|---|---|---|---|---|---|")
order={'P0':0,'P1':1,'P2':2,'P3':3,'P4':4}
sevo={'Kritiek':0,'Major':1,'Minor':2}
op.sort(key=lambda f:(order.get(f['prio'],9),sevo.get(f['sev'],9),int(f['id'][1:])))
for f in op: out.append(f"| {f['prio']} | {f['id']} | {f['sev']} | {f['status']} | {f['area']} | {f['title']} |")
out.append("\n### 6.2 Details open bevindingen\n")
for f in op:
  cur,_,hist=f['ev'].partition(' || ')
  if int(f['id'][1:])>=138: cur=f['ev'].replace(' || ','; '); hist=''
  elif not cur.startswith('0.5.10'): hist=f['ev']; cur='niet opnieuw getest; status overgenomen uit 0.5.1'
  out.append(f"#### {f['id']} · {f['sev']} · {f['status']} · {f['prio']} · {f['area']} — {f['title']}\n- Bewijs 0.5.10: {cur.replace('0.5.10: ','')}\n- Historie (bewijsbestanden in report-0.5.1/): {hist or '–'}\n{('- Teamronde: '+f['team']+chr(10)) if f.get('team') else ''}{('- Alias: '+f['alias']+chr(10)) if f.get('alias') else ''}- Repro: {f.get('repro','') or '–'}\n- Fix: {f.get('fix','') or '–'}\n")
cl=[f for f in F if f['status'].startswith('Opgelost') and f.get('old','')!=f['status']]
out.append("### 6.3 Deze ronde gesloten\n\n| ID | Was | Ernst | Titel | Bewijs 0.5.10 |\n|---|---|---|---|---|")
for f in cl: out.append(f"| {f['id']} | {f['old']} | {f['sev']} | {f['title']} | {f['ev'].split(' || ')[0].replace('0.5.10: ','').replace('|','/')} |")
out.append(f"\n*Verder {len(F)-len(op)-len(cl)} bevindingen die al in eerdere rondes waren opgelost (zie findings.json).*\n")
t=open(D+'tools/tail.md').read()
sv=['| ID | Titel | QA (eerste versie) | Na teamronde | Wie wilde wat |','|---|---|---|---|---|']
for f in sorted([f for f in F if f.get('team') and not f.get('alias')],key=lambda f:int(f['id'][1:])):
  sv.append(f"| {f['id']} | {f['title']} | {f.get('sev_qa',f['sev'])} / {f.get('status_qa',f['status'])} | **{f['sev']} / {f['status']} / {f['prio']}** | {f['team'].replace('|','/')} |")
nw=['| ID | Ernst | Prio | Status | Titel | Aliassen (reviewer-ID) |','|---|---|---|---|---|---|']
for f in [f for f in F if f.get('alias')]:
  nw.append(f"| {f['id']} | {f['sev']} | {f['prio']} | {f['status']} | {f['title']} | {f['alias']} |")
t=t.replace('{{SEV_TABLE}}','\n'.join(sv)).replace('{{NEW_TABLE}}','\n'.join(nw))
out.append(t)
open(D+'QA-rapport-0.5.10.md','w').write('\n'.join(out))
print(len(op),cs,len(cl))
