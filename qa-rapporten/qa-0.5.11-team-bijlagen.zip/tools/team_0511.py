# Teamintegratie 0.5.11: draait NA build_findings_0511.py en parity_0511.py. Past findings.json en parity.json aan.
import json
from collections import Counter
D = '/workspace/phlippo-cad/report-0.5.11/'
L = json.load(open(D + 'findings.json')); F = {f['id']: f for f in L}
T = json.load(open(D + 'logs/qa-team.json'))
g = lambda name, **k: next(o for o in T if o['test'] == name and all(o.get(a) == b for a, b in k.items()))
a_b = g('1a', kernel='brep')['A_slot_then_stretch']; a_m = g('1a', kernel='mesh')['A_slot_then_stretch']; a_o = g('1a', kernel='brep')['D_oracle_manual']
e_b = g('1b-ellipse', kernel='brep'); sp = g('1b-spline'); w_e = g('1c-wrap', kind='emboss'); w_d = g('1c-wrap', kind='deboss')
nl = lambda x: f'{x:.3f}'.replace('.', ',')
DE, OPEN, NIEUW, OP = 'Deels opgelost', 'Open', 'Nieuw', 'Opgelost'
def ch(i, ev=None, **k):
    f = F[i]
    if ev: f['ev'] = '0.5.11 teamronde: ' + ev + ' || ' + f['ev']
    for a, b in k.items(): f[a] = b
    f.setdefault('team', [])
# ---- herziene ernst / status
ch('F175', f'BEVESTIGD als stille fout onder het label "exact" (tools/qa-src/qaTeam.test.ts, logs/qa-team.json): ellips 40×20 × 10 mm geeft B-rep {nl(e_b["v"])} mm³ tegen π·20·10·10 = 6283,185 (−4,485 mm³, −0,071 %); body.exact = true, boom "Exact surfaces (B-rep)", geen waarschuwing, geen Faceted-cel in de statusbalk (StatusBar telt alleen !exact), volumeMismatch = null. STEP uit dezelfde B-rep: {e_b["step"]["LINE"]} LINE, {e_b["step"]["PLANE"]} PLANE, 0 ELLIPSE, 0 B_SPLINE. Spline-profiel idem: exact = true, STEP {sp["step"]["LINE"]} LINE, 0 B_SPLINE. Wrap-patch (MT5D-13) zelfde klasse: emboss {nl(w_e["v"])} vs {nl(w_e["expected"])} (ΔV {w_e["diff"]} mm³), deboss ΔV {w_d["diff"]} mm³, exact = true, geen waarschuwing; STEP {w_e["step"]["PLANE"]} PLANE-vlakken waar SOLIDWORKS een cilindrisch offsetvlak heeft (rebuild.ts:2187-2188 meshToolOf). Volgens onze eigen regel (stil fout resultaat) Kritiek.',
   sev='Kritiek', prio='P0', status=NIEUW, title='Facetgeometrie onder het label "exact": ellips, spline en wrap-patch (geen waarschuwing, STEP zonder ELLIPSE/B_SPLINE)',
   repro='Ellips 40×20 op Top, extrude 10 mm, B-rep: Mass Properties 6278,700 i.p.v. 6283,185; STEP exporteren en tellen: 0 ELLIPSE. Wrap emboss 10×10 op R20-rol diepte 2: 22 PLANE-vlakken.',
   fix='Interim (direct): bodies met ellips/spline/wrap-patch exact:false + waarschuwing tot de echte fix. Echt: Geom_Ellipse / BSplineCurve in occt/brep.ts:68-75 i.p.v. sampleEntity(…,96); wrap via exacte offset-/projectie.', team=['STRATI-02', 'MT5D-09', 'RISK-09', 'RIKI-04', 'MT5D-13'])
ch('F176', 'Ernst verhoogd naar Kritiek volgens onze eigen definitie ("stil fout resultaat óf blokkade voor klaar", MT5D). Geen enkele Actions-run op db0d4b2; de box-logs dragen "commit dcd49df", de lokale stand-in-commit van de archive (logs/git-standin.txt), niet de echte HEAD. F54 telt niet apart als Kritiek: het resterende deel van F54 is precies deze bevinding.', sev='Kritiek', prio='P0', team=['MT5D', 'STRATI-04', 'RIKI-01'])
ch('F54', 'Rest valt onder F176 (Kritiek); hier Major gehouden om niet dubbel te tellen. Daarnaast WEBI-08: multibody rood in beide Actions-runs, features dicht bij de 900 s-timeout (F195).', sev='Major', prio='P0')
ch('F111', 'HEROPEND als klasse (Strati): de basis-T3 klopt, maar een gesplitste rand na een maatwijziging en een gebogen rand niet. Zie F177 (Kritiek) en F178. Status Deels; ernst Major om F177 niet dubbel te tellen.', status=DE, sev='Major', prio='P0', team=['STRATI-01'])
ch('F105', 'Box-only: B-rep 14/14 en release 98/98 alleen op de QA-box; CI-brep-job draait 12 scripts, loftface en pmsweep ontbreken (ci.yml:137, RIKI-05). Daarom terug naar Deels (Strati).', status=DE, sev='Major', prio='P1')
ch('F145', 'Eén groene run (features 65/65 mesh en B-rep) bewijst geen stabiliteit; in 0.5.10 faalde Sweep1 1×. Deels tot N ≥ 10 herhaalde runs zonder fout (Riki).', status=DE, sev='Minor', prio='P2')
ch('F172', 'Prioriteit naar P0 (Risk). Let op voor de fix: de in NAAR-100 voorgestelde drempel max(0,5 mm³; 0,1 %) ligt onder het tessellatieverschil op een correct T3 (0,794–0,845 mm³, logs/qa-t3diag.log) en geeft dus valse alarmen (RISK-01). Ook een perfecte drempel vangt F177 niet: mesh geeft daar dezelfde fout (F179).', prio='P0')
ch('F140', 'Terecht ingetrokken voor 0.5.11 (B-rep op de juiste rand z=−40 gemeten: 30439,911 = formule); voor 0.5.10 afgeleid, niet gedraaid (app-0.5.10 heeft geen vite, logs/qa-t3diag-on-0.5.10.log). De bewering van Webi dat brep.ts/edgesets.ts tussen 0.5.10 en 0.5.11 wijzigden, wordt door de CR-gestripte diffs van Strati, Riki en MT5D tegengesproken.', team=['STRATI-07', 'WEBI'])
ch('F51', 'Aanvulling (Strati): face fillet, full round, setback, partial en andere niet-constante varianten vallen buiten brepRoundable (rebuild.ts:858-864) en worden dus facet; voor variabel/face/full round/chamfer-varianten is er geen 0.5.11-volumebewijs.')
ch('F50', 'Aanvulling (RISK-06, WEBI-07): zie F189 voor de juridische grens van de repo-inhoud; materiaalbibliotheek volgt SW-naamgeving.')
# ---- nieuwe bevindingen F177+
NEW = [
 ('F177', 'Topologie', 'Kritiek', 'P0', NIEUW, 'Fillet op een gesplitste rand na een maatwijziging rondt stil maar één stuk af (onder "exact", zonder waarschuwing)',
  f'Gereproduceerd op de box (tools/qa-src/qaTeam.test.ts, logs/qa-team.json). T3 (80×40×10, fillet R2 op de z=−40-rand, sleuf 35–45 ervóór), daarna basis 80 → 100 mm. B-rep: {nl(a_b["v"])} mm³, verwacht 38500 − 90·CORNER(2) = {nl(a_b["expected"])} (+{nl(a_b["diff"])} mm³ = precies 55 mm fillet te weinig); exact = true, geen fout, geen waarschuwing, geen Faceted. Mesh geeft dezelfde fout ({nl(a_m["v"])}), dus volumeMismatch = null. Orakel (zelfde model, beide stukken 55 + 35 mm met de hand gekozen): {nl(a_o["v"])} = formule. Controles: alleen basis 100 zonder sleuf = 39914,159 = formule; alleen sleuf (T3) = 30439,911 = formule. Oorzaak volgens Strati: edgesets.ts:338-355 en :308-310 kiezen bij meerdere kandidaten één stuk; rebuild.ts:2848-2849.',
  'Zie bewijs; vergelijk Mass Properties met 38422,743.', 'Bij een gesplitste referentie alle stukken langs dezelfde lijn/kromme meenemen; waarschuwen zodra matchEdge uit meerdere kandidaten kiest (edgesets.ts:310); propertysuite (NAAR-100 §5.5-3).', ['STRATI-01']),
 ('F178', 'Kernel', 'Major', 'P0', NIEUW, 'Gebogen rand van een exact lichaam bestaat uit 32 rechte segmenten; fillet erop valt naar mesh en is ±10× fout',
  'Eigen test (tools/qa-src/qaCurved.test.ts, logs/qa-curved.log): plaat 80×40×10 met R10-hoekboog, B-rep scherp 31785,398 = formule, maar de bovenste boogrand verschijnt als 32 rechte randen van 0,491 mm (de onderste lus als één rand van 115,706). Fillet R2 op alle 32: waarschuwing "no exact (B-rep) version … approximate", verlies 135,498 mm³ tegen 12,881 (Pappus) — geen benadering maar ±10,5× te veel. Eén segment: verlies 0,753. SOLIDWORKS kiest één boogrand met tangentpropagatie. De combinatie sleuf vóór de fillet + 32 segmenten gaf > 10 min geen resultaat (door ons afgebroken; niet geïsoleerd). Strati\'s variant "gebogen gesplitste rand" was daardoor niet zuiver te meten.',
  'Zie bewijs.', 'Randen van het exacte lichaam uit de B-rep-topologie (TopExp) halen, niet uit tessellatie; tangentketens als één selectie.', ['STRATI-01(b)']),
 ('F179', 'Kernel', 'Major', 'P0', NIEUW, 'Kruiscontrole is structureel blind: beide kernels delen de randresolutie, waarschuwing alleen bij de laatste feature',
  f'F177 toont het: mesh {nl(a_m["v"])} en B-rep {nl(a_b["v"])} maken dezelfde fout, volumeMismatch = null. De randkeuze (matchEdges) is gedeeld (rebuild.ts:2837-2838, :818, :821). De waarschuwing hangt aan de laatste feature (brepRefine.ts:77, :89-90), is alleen een waarschuwing en heeft geen e2e. volumeCheck.test.ts:9 legt vast dat het F140-verschil (30439,07 vs 30431,33) géén waarschuwing geeft (F198).',
  'Zie F177.', 'Onafhankelijke controle: som van gematchte stuklengtes tegen de lengte van het oorspronkelijke vlakkenpaar; per feature; e2e.', ['STRATI-03', 'RISK-02']),
 ('F180', 'QA-proces', 'Major', 'P1', DE, 'Herkomst en logverwijzingen van het QA-rapport waren niet sluitend',
  'Box-logs dragen "commit dcd49df" (lokale stand-in-commit, logs/git-standin.txt), terwijl het rapport "commit unknown" zei; inhoud = db0d4b2 volgens provenance.txt en de zip-comment (688/688 bestanden, Risk). 28 pariteitsrijen verwezen naar logs die in deze map niet bestaan (logs/regression.log, regression-rerun.log, qa-strict-tests.log, qa-brep-tests.log); rij 56 gebruikte 0.5.10-cijfers; prefs-unused.txt en regression-worker.log ontbraken; B-rep deel 1 heeft geen eigen DONE-regel (gecombineerd log); desktop-installed is 2 regels. In deze revisie hersteld: alle rij-verwijzingen wijzen naar bestaande 0.5.11-logs, rij 56 herzien, de herkomstzin gecorrigeerd. Open: een echte git-kloon en een ongesplitste B-rep-run.',
  'rg "logs/regression.log" parity.json (vóór deze revisie 28 rijen).', 'Echte git clone op de release-commit; logs niet combineren maar per run bewaren.', ['RIKI-01', 'RIKI-02', 'RIKI-03', 'RISK-03', 'RISK-04', 'RISK-10', 'WEBI-01', 'MT5D-12', 'MT5D-17', 'STRATI-04']),
 ('F181', 'QA-proces', 'Major', 'P1', OP, 'Pariteit en ernst in de eerste versie van dit rapport te gunstig',
  'Rijen 11, 30, 49, 55, 61 stonden op aanwezig en 62 op deels zonder voldoende bewijs; "0 Kritiek" hield geen stand (F175, F177, F176). In deze revisie hersteld: 70,2 % strikt (zie §5).', '–', '–', ['STRATI-05', 'WEBI-02']),
 ('F182', 'QA-proces', 'Major', 'P1', OP, 'NAAR-100 rekende fout en sprak zichzelf tegen',
  'Posten telden op tot 82–89 d tegen "60–80"; P2 40,5–42,5 vs "25–30"; P3 5 vs "2–3"; rij 37 en 42 tegenstrijdig; plafond 95,2 % moest 94,4 % zijn (83,1 % zonder R0); IGES via OCCT kan niet (geen IGESControl_Writer in replicad_single.d.ts); P0-2-drempel gaf valse alarmen; signing dubbel bestraft (59/60); paden P2-7 (src/core/document/history.ts:5) en P2-10 (rebuild.ts:853). In deze revisie hersteld.', '–', '–', ['STRATI-06', 'RIKI-06', 'RIKI-07', 'RIKI-08', 'MT5D-14', 'MT5D-15', 'MT5D-16', 'RISK-01']),
 ('F183', 'Testen/CI', 'Minor', 'P2', NIEUW, 'CI-brep-job draait 12 van de 14 B-rep-scripts (loftface en pmsweep ontbreken)', 'ci.yml:137 noemt 12 scripts; op de box draaiden er 14 (logs/regression-brep.log).', 'Lees ci.yml:133-138.', 'loftface en pmsweep toevoegen.', ['RIKI-05', 'MT5D-16d']),
 ('F184', 'Testen/CI', 'Major', 'P1', NIEUW, 'Geen herhaalde runs, mutatietests, rand-asserts of .kcad-compatibiliteitstest',
  'Elke groene pass is één run; geen mutatietest die bewijst dat de QA-tests een fout vangen; geen assert op welke rand gefillet wordt; geen test dat .kcad van 0.5.10 opent.', '–', 'N ≥ 10 herhalingen in CI; Stryker of handmatige mutaties op edgesets/volumeCheck; rand-asserts; fixture-bestanden van 0.5.10.', ['RIKI-09']),
 ('F185', 'QA-proces', 'Major', 'P1', DE, 'Eigen QA-diagnosetests hebben 0 asserts; B-T3 kiest nog de z=0-rand',
  'Geteld (rg -c "expect\\("): tools/qa-src/qaBrep.test.ts 0, qaDiag 0, qaT3diag 0, qaTeam 0, qaCurved 0; alleen qaStrict.test.ts heeft 20. qaBrep.test.ts:63 kiest met reduce de eerste langste rand: onder B-rep de z=0-rand (zelfde fout als F140). De cijfers komen uit JSON-logs en worden handmatig tegen formules gelegd.', 'rg -c "expect\\(" tools/qa-src/*.ts', 'Diagnosetests omzetten naar asserts met positie-gebaseerde randkeuze.', ['RISK-08']),
 ('F186', 'Assembly', 'Minor', 'P3', NIEUW, 'Mate-conflict-heuristiek: "unconverged" hangt aan een tweede solve van 128 iteraties', 'mateStatus.ts:124-128: een geschonden mate die na 128 extra iteraties klopt telt als niet-geconvergeerd, niet als conflict; geen test voor de grens.', '–', 'Convergentiecriterium expliciet maken en testen.', ['RIKI-10']),
 ('F187', 'QA-proces', 'Minor', 'P3', OP, 'Onze QA-tests stonden ongetrackt in src/qaext van de testboom', 'Na deze ronde verwijderd uit app-0.5.11/src; bronnen staan alleen in tools/qa-src/.', '–', '–', ['RIKI-11']),
 ('F188', 'Robuustheid', 'Minor', 'P2', NIEUW, 'AutoRecover-kopieën van 0.5.10 worden mogelijk niet getoond', 'recover.cjs:27-29: alleen namen met ~<16 hex>.autorecover.kcad gelden als herstelbestand; oudere kopieën zonder sleutel vallen erbuiten (niet in een e2e getest).', 'Leg een 0.5.10-autorecover in de map en start 0.5.11.', 'Oude naamvorm ook herkennen of eenmalig migreren.', ['RISK-05']),
 ('F189', 'Juridisch', 'Major', 'P1', NIEUW, 'Juridische grens: interne SW-documentatie en pixel-overlay-plan horen niet in een publieke repo',
  'docs/26 en docs/06:3 bevatten SW-specifieke inhoud; NAAR-100 P2-12 stelde een overlay binnen 4 px op SW-screenshots voor; geen EULA. Materiaalbibliotheek volgt SW-naamgeving (WEBI-07).', '–', 'docs/26 en docs/06 uit de repo vóór publiceren; functionele, geen visuele pariteit; geen pixelkopie; juridische toets door een mens.', ['RISK-06', 'WEBI-07']),
 ('F190', 'Testen/CI', 'Major', 'P1', NIEUW, 'Geen Windows-job in CI', 'ci.yml heeft alleen ubuntu-runners; de Windows-logs zijn handmatig van 0495219/1fd00e3.', '–', 'windows-latest-job met mesh/release en de packaged self-test.', ['RISK-07']),
 ('F191', 'Performance', 'Minor', 'P3', NIEUW, 'Extra views tekenen elke 1500 ms opnieuw met een CPU-readback', 'ViewPane rendert periodiek opnieuw en leest pixels terug, ook zonder wijziging.', '–', 'Alleen bij wijziging renderen.', ['WEBI-03']),
 ('F192', 'UI/UX', 'Major', 'P2', NIEUW, 'Extra views (Two/Four View) zijn niet interactief', 'In SOLIDWORKS kun je in elk viewport selecteren, draaien en zoomen; hier zijn de extra panes alleen beelden.', 'Four View, klik in een extra pane.', 'Interactie per pane.', ['WEBI-04']),
 ('F193', 'UI/UX', 'Minor', 'P3', NIEUW, 'Keuzelijst "Units" onleesbaar; Material-tabs lopen over', 'Zie shots van Options/Material (Webi).', '–', 'Breedte/omloop corrigeren.', ['WEBI-05']),
 ('F194', 'UI/UX', 'Minor', 'P3', NIEUW, 'Productnaam in drie vormen', 'Venstertitel, installer en About gebruiken verschillende schrijfwijzen.', '–', 'Eén naam.', ['WEBI-06']),
 ('F195', 'Testen/CI', 'Major', 'P1', NIEUW, 'Multibody rood in beide Actions-runs; features dicht bij de 900 s-timeout', 'Actions-runs 41542259973 en 41551048560: multibody rood; features-scripts lopen tegen 900 s. Op de box groen (14/14), dus platform- of timing-afhankelijk.', '–', 'Oorzaak in CI vinden; timeouts met marge.', ['WEBI-08']),
 ('F196', 'Installer', 'Minor', 'P2', NIEUW, 'Electron-fuses niet getest in de gepackagede app', 'Fuses staan in de config, maar geen test controleert ze in de geïnstalleerde exe.', '–', '@electron/fuses read in de packaged smoke.', ['WEBI-09']),
 ('F197', 'Kernel', 'Major', 'P1', NIEUW, 'Exacte sheet-metal-flange wordt bij afwijking stil vervangen door mesh', 'rebuild.ts:1600-1604: als de exacte flange > 0,5 % afwijkt van mesh, wordt het mesh-resultaat gehouden ("an edge flange and a hem short of material on the exact path"). Het exacte defect blijft verborgen.', '–', 'Het exacte flange-pad repareren; afwijking melden.', ['MT5D-10']),
 ('F198', 'Testen/CI', 'Major', 'P1', NIEUW, 'Unit-test legt blindheid van de kruiscontrole vast', 'volumeCheck.test.ts:9: expect(volumeMismatch(30439.07, 30431.33)).toBeNull(): het verschil van een hele extra fillet (8,58 mm³) moet stil blijven.', '–', 'Omkeren zodra de controle per feature werkt (F172).', ['MT5D-11']),
 ('F199', 'Import/Export', 'Minor', 'P2', NIEUW, 'Meegeleverde OCCT heeft geen IGES-writer', 'replicad_single.d.ts en replicad_multi.d.ts: 0× IGESControl_Writer (STEPControl_Writer 4×). IGES-export vergt een eigen OCCT-build met de IGES-module.', 'rg IGESControl_Writer node_modules/replicad-opencascadejs/dist/*.d.ts', 'Eigen opencascade.js-build met IGES (gratis, ±3–5 d) of IGES buiten scope.', ['MT5D-15']),
]
for (i, area, sev, prio, st, title, ev, repro, fix, al) in NEW:
    F[i] = {'id': i, 'area': area, 'sev': sev, 'old': '—', 'title': title + ' [' + ', '.join(al) + ']', 'status': st, 'prio': prio, 'ev': '0.5.11 teamronde: ' + ev, 'repro': repro, 'fix': fix, 'team': al}
for f in F.values():
    if f.get('team') and f['id'] < 'F177' and not f['title'].endswith(']'): f['title'] += ' [' + ', '.join(f['team']) + ']'
L = sorted(F.values(), key=lambda f: int(f['id'][1:]))
json.dump(L, open(D + 'findings.json', 'w'), ensure_ascii=False, indent=1)
openst = (DE, OPEN, 'Niet geverifieerd', NIEUW)
c = Counter(f['status'] for f in L); sv = Counter(f['sev'] for f in L if f['status'] in openst)
print(len(L), dict(c), 'open', sum(sv.values()), dict(sv), 'Kritiek', [f['id'] for f in L if f['status'] in openst and f['sev'] == 'Kritiek'])
R = json.load(open(D + 'tools/results-0511.json')); R['counts'] = dict(c); R['open_sev'] = dict(sv); json.dump(R, open(D + 'tools/results-0511.json', 'w'))
# ---- pariteit: strengste verdedigbare telling (unie van de teamverlagingen met bewijs)
P = json.load(open(D + 'parity.json')); rows = P['rows']
A, Dl, O = 'aanwezig', 'deels', 'ontbreekt'
def s(n, st, ev, who): rows[n-1]['status'] = st; rows[n-1]['ev'] = ev; rows[n-1]['team'] = who
s(11, Dl, f'Constante fillet T1–T3 correct; maar gesplitste rand na maatwijziging stil fout onder exact (F177: {nl(a_b["v"])} vs 38422,743, logs/qa-team.json), gebogen rand 10× fout via mesh (F178, logs/qa-curved.log), face fillet/full round/setback alleen mesh (rebuild.ts:858-864); filletopts 16/16 mesh (logs/regression-mesh.log) en B-rep (logs/regression-brep.log)', 'Strati, Riki + box-test')
s(30, Dl, f'Self-test 8/8 (logs/self-test-*.json) maar "packaged": false; ellips/spline/wrap heten exact terwijl ze facetten zijn (F175: ellips {nl(e_b["v"])} vs 6283,185, STEP 0 ELLIPSE)', 'Strati, Riki, Risk, Webi + box-test')
s(49, Dl, f'step 11/11 mesh (logs/regression-mesh.log) en B-rep (logs/regression-brep.log), self-test STEP; maar "exacte" STEP van een ellips bevat {e_b["step"]["LINE"]} LINE en 0 ELLIPSE (F175, logs/qa-team.json)', 'Riki, MT5D + box-test')
s(55, Dl, 'Code-bewaking ok (rename-trademarks.cjs, logs/trademark-check.log, logs/ci-checks.log; disclaimer shots/home-brep.png), maar geen juridische toets; docs/26 en docs/06 met SW-inhoud in de repo; materiaalnamen volgen SW (F189)', 'Strati, Risk')
s(61, Dl, 'vitest 487/487 (logs/vitest.log); box mesh 98/98, B-rep 14/14, release 98/98 (logs/regression-*.log) — maar alleen box, één run per pass (F184), CI-brep 12/14 scripts (F183), QA-diagnosetests zonder asserts (F185), toleranties te ruim (F173)', 'Strati, Webi')
s(62, O, 'Geen enkele groene GitHub Actions-run op HEAD db0d4b2 (quotum); laatste runs 41542259973/41551048560 op andere commits met rode shards (F176, F195). Box-groen is geen CI.', 'Riki')
s(56, Dl, 'Release: worker standaard; box rebuildworker 10/10 in 152 s (logs/regression-mesh.log) en release-pass 98/98 met worker (logs/regression-release.log); budget 45 s (F137); browser-mesh-CSG op de UI-thread (F46). Geen herhaalde runs.', 'MT5D-17 (bewijs ververst)')
# verwijzingen naar logs die hier niet bestaan herstellen
import re, os
rep = {'logs/regression.log:94': 'logs/regression-mesh.log', 'logs/regression.log': 'logs/regression-mesh.log', 'logs/regression-rerun.log': 'logs/regression-mesh.log', 'logs/qa-strict-tests.log': 'logs/qa-ext-tests.log', 'logs/qa-brep-tests.log': 'logs/qa-ext-tests.log', 'vitest 454/454': 'vitest 487/487', 'features 65/65 bij herhaling': 'features 65/65 mesh en B-rep (één run)'}
fixed = []
for i, r in enumerate(rows, 1):
    ev0 = r['ev']
    for a, b in rep.items(): r['ev'] = r['ev'].replace(a, b)
    if r['ev'] != ev0: fixed.append(i)
# controle: elk genoemd log bestaat
miss = {}
for i, r in enumerate(rows, 1):
    for p in re.findall(r'logs/[\w.\-*{}]+', r['ev']):
        p = p.rstrip('.,;)')
        if '*' in p or '{' in p: continue
        if not os.path.exists(D + p): miss.setdefault(i, []).append(p)
w = {A: 1, Dl: 0.5, O: 0, 'kapot': 0}
cc = Counter(r['status'] for r in rows); pct = round(100 * sum(w[r['status']] for r in rows) / len(rows), 1)
P['counts'] = dict(cc); P['pct'] = pct; P['pct_eerste_versie_0511'] = 75.0; P['log_refs_hersteld'] = fixed
P['team_pct'] = {'Strati': 71.8, 'Riki': 71.8, 'Webi': 73.4, 'MT5D': 74.2, 'Risk': 74.2, 'QA (unie, deze revisie)': pct}
json.dump(P, open(D + 'parity.json', 'w'), ensure_ascii=False, indent=1)
print('parity', dict(cc), pct, 'refs hersteld', len(fixed), fixed, 'missend', miss)
