// QA 0.5.10 adversarial checks (same T1-T3/M1/M2/E1 as 0.5.1, now with assertions) (box-only, NOT part of the repo)
import { describe, expect, it } from 'vitest';
import { createDocument, type Component, type Mate, type MateRef } from '../core/document/types';
import { addCircle, addLine, createSketch } from '../core/sketch/model';
import { rebuildDocument } from '../core/features/rebuild';
import { edgeRef } from '../core/features/edgesets';
import { meshVolume } from '../core/features/solid';
import { solveMates } from '../core/assembly/assembly';
import { mateStatus } from '../core/assembly/mateStatus';
import { evaluateEquations } from '../core/document/equations';

const rect = (s: ReturnType<typeof createSketch>, x0: number, y0: number, x1: number, y1: number) => {
  const c = [{ x: x0, y: y0 }, { x: x1, y: y0 }, { x: x1, y: y1 }, { x: x0, y: y1 }];
  for (let i = 0; i < 4; i++) s = addLine(s, c[i], c[(i + 1) % 4])[0];
  return s;
};
const log = (k: string, v: unknown) => console.log(`QA ${k}: ${JSON.stringify(v)}`);

describe('QA topological naming', () => {
  it('T1 fillet on hole rim survives hole diameter 35 -> 50', () => {
    const doc = createDocument();
    doc.sketches.sk1 = rect(createSketch('sk1', 'Sketch1', 'top'), 0, 0, 80, 80);
    doc.sketches.sk2 = addCircle(createSketch('sk2', 'Sketch2', 'top'), { x: 40, y: 40 }, 17.5)[0];
    doc.features.push({ id: 'f1', type: 'extrude', name: 'B', sketchId: 'sk1', suppressed: false, op: 'boss', end: 'blind', depth: 10, reverse: false } as never);
    doc.features.push({ id: 'f2', type: 'extrude', name: 'C', sketchId: 'sk2', suppressed: false, op: 'cut', end: 'throughAll', depth: 0, reverse: true, direction2: { end: 'throughAll', depth: 0 } } as never);
    const b0 = rebuildDocument(doc).bodies[0];
    const rims = b0.edges.filter((e) => e.closed);
    log('T1 rims', rims.map((e) => [Math.round(e.length), +e.centroid.y.toFixed(2)]));
    const top = rims.reduce((a, b) => (b.centroid.y > a.centroid.y ? b : a));
    doc.features.push({ id: 'r1', type: 'fillet', name: 'Fillet1', suppressed: false, size: 2, edges: [edgeRef(top)] } as never);
    const v0 = meshVolume(rebuildDocument(doc).bodies[0].geometry);
    const sk = doc.sketches.sk2; const rid = Object.keys(sk.scalars ?? {})[0];
    (doc.sketches as Record<string, unknown>).sk2 = { ...sk, scalars: { ...sk.scalars, [rid]: 25 } };
    const r = rebuildDocument(doc);
    const v1 = meshVolume(r.bodies[0].geometry);
    const sharpVol = 80 * 80 * 10 - Math.PI * 25 * 25 * 10;
    const dS = createDocument(); dS.sketches = { ...doc.sketches }; dS.features = doc.features.filter((f) => f.id !== 'r1');
    const sharpMesh = meshVolume(rebuildDocument(dS).bodies[0].geometry); const lossT1 = sharpMesh - v1;
    log('T1 loss vs own sharp mesh', { sharpMesh, lossT1, expected: 137.2, warnings: r.warnings });
    log('T1', { errors: r.errors, v0, v1, sharpVol, filletApplied: v1 < sharpVol - 1 });
    expect(r.errors.r1).toBeUndefined();
    expect(lossT1).toBeGreaterThan(137.2 * 0.9);
    expect(lossT1).toBeLessThan(137.2 * 1.1);
  });

  it('T2 fillet on revolve edge survives outer radius 30 -> 36', () => {
    const doc = createDocument();
    let s = createSketch('sk1', 'Sketch1', 'front');
    let axis; [s, axis] = addLine(s, { x: 0, y: -10 }, { x: 0, y: 60 }, true);
    s = rect(s, 10, 0, 30, 40);
    doc.sketches.sk1 = s;
    doc.features.push({ id: 'f1', type: 'revolve', name: 'Revolve1', sketchId: 'sk1', suppressed: false, op: 'boss', axisEntityId: axis.id, angle: 360, reverse: false } as never);
    const b0 = rebuildDocument(doc).bodies[0];
    expect(b0).toBeTruthy();
    const rims = b0.edges.filter((e) => e.closed);
    log('T2 rims', rims.map((e) => [Math.round(e.length), +e.centroid.y.toFixed(2)]));
    const outerTop = rims.filter((e) => e.centroid.y > 39).reduce((a, b) => (b.length > a.length ? b : a));
    doc.features.push({ id: 'r1', type: 'fillet', name: 'Fillet1', suppressed: false, size: 3, edges: [edgeRef(outerTop)] } as never);
    const before = rebuildDocument(doc);
    const vb = meshVolume(before.bodies[0].geometry);
    const sk = doc.sketches.sk1;
    doc.sketches.sk1 = { ...sk, points: Object.fromEntries(Object.entries(sk.points).map(([id, p]) => [id, Math.abs(p.x - 30) < 1e-9 ? { ...p, x: 36 } : p])) };
    const r = rebuildDocument(doc);
    const v = meshVolume(r.bodies[0].geometry);
    const sharp = Math.PI * (36 * 36 - 100) * 40;
    log('T2', { errorsBefore: before.errors, vb, errors: r.errors, v, sharp, filletApplied: v < sharp - 5 });
    const dS = createDocument(); dS.sketches = { ...doc.sketches }; dS.features = doc.features.filter((f) => f.id !== 'r1');
    const sharpMesh = meshVolume(rebuildDocument(dS).bodies[0].geometry);
    const loss = sharpMesh - v; log('T2 loss vs own sharp mesh', { sharpMesh, loss, expected: 428.7 });
    expect(r.errors.r1).toBeUndefined();
    expect(loss).toBeGreaterThan(428.7 * 0.9);
    expect(loss).toBeLessThan(428.7 * 1.1);
  });

  it('T3 fillet edge split by an earlier slot cut', () => {
    const doc = createDocument();
    doc.sketches.sk1 = rect(createSketch('sk1', 'Sketch1', 'top'), 0, 0, 80, 40);
    doc.features.push({ id: 'f1', type: 'extrude', name: 'B', sketchId: 'sk1', suppressed: false, op: 'boss', end: 'blind', depth: 10, reverse: false } as never);
    const b0 = rebuildDocument(doc).bodies[0];
    const tops = b0.edges.filter((e) => e.straight && Math.abs(e.centroid.y - 10) < 1e-6);
    const longest = tops.reduce((a, b) => (b.length > a.length ? b : a));
    log('T3 edge', { len: longest.length, c: longest.centroid.toArray() });
    doc.features.push({ id: 'r1', type: 'fillet', name: 'Fillet1', suppressed: false, size: 2, edges: [edgeRef(longest)] } as never);
    const v1 = meshVolume(rebuildDocument(doc).bodies[0].geometry);
    // insert a cut slot 10 wide across the whole plate before the fillet
    doc.sketches.sk3 = rect(createSketch('sk3', 'Sketch3', 'top'), 35, 25, 45, 45);
    doc.features.splice(1, 0, { id: 'f3', type: 'extrude', name: 'Slot', sketchId: 'sk3', suppressed: false, op: 'cut', end: 'throughAll', depth: 0, reverse: true, direction2: { end: 'throughAll', depth: 0 } } as never);
    const r = rebuildDocument(doc);
    const v2 = meshVolume(r.bodies[0].geometry);
    const sharp = 80 * 40 * 10 - 10 * 15 * 10;
    log('T3 bodies', r.bodies.length);
    const loss = (1 - Math.PI / 4) * 4;
    log('T3', { errors: r.errors, v1, v2, sharp, expectedBothHalves: sharp - loss * 70, oneHalf: sharp - loss * 35, nothing: sharp });
    expect(Math.abs(v2 - (sharp - loss * 70))).toBeLessThan(5);
  });
});

describe('QA assembly mates', () => {
  const comp = (id: string, fixed: boolean, position: [number, number, number]): Component => ({ id, name: id, part: createDocument(id), position, rotation: [0, 0, 0, 1], fixed, suppressed: false });
  const face = (componentId: string, normal: [number, number, number], point: [number, number, number]): MateRef => ({ componentId, kind: 'face', label: componentId, normal, point });
  const mate = (id: string, type: Mate['type'], refs: [MateRef, MateRef], extra: Partial<Mate> = {}): Mate => ({ id, type, name: id, refs, aligned: false, suppressed: false, ...extra });
  it('M1 chain A(fixed) <- C <- B: B floating, mated only to floating C', () => {
    const A = comp('A', true, [0, 0, 0]), B = comp('B', false, [0, 100, 0]), C = comp('C', false, [0, 50, 0]);
    const m1 = mate('m1', 'distance', [face('B', [0, -1, 0], [0, 0, 0]), face('C', [0, 1, 0], [0, 10, 0])], { value: 5 });
    const m2 = mate('m2', 'coincident', [face('C', [0, -1, 0], [0, 0, 0]), face('A', [0, 1, 0], [0, 10, 0])]);
    const out = solveMates([A, B, C], [m1, m2]);
    const pos = Object.fromEntries(out.map((c) => [c.id, c.position.map((v) => +v.toFixed(3))]));
    // expected: C bottom on A top (C.y = 10), C top at 20, B bottom 5 above -> B.y = 25
    log('M1', pos);
    expect(pos.B[1]).toBeCloseTo(25, 3); expect(pos.C[1]).toBeCloseTo(10, 3);
    const m1s = { ...m1, refs: [m1.refs[1], m1.refs[0]] as [MateRef, MateRef] };
    const out2 = solveMates([A, B, C], [m1s, m2]);
    const pos2 = Object.fromEntries(out2.map((c) => [c.id, c.position.map((v) => +v.toFixed(3))]));
    log('M1 swapped refs', pos2);
    expect(pos2.B[1]).toBeCloseTo(25, 3);
  });
  it('M2 conflicting distance mates give no error', () => {
    const A = comp('A', true, [0, 0, 0]), B = comp('B', false, [0, 50, 0]);
    const m1 = mate('m1', 'distance', [face('A', [0, 1, 0], [0, 10, 0]), face('B', [0, -1, 0], [0, 0, 0])], { value: 10 });
    const m2 = mate('m2', 'distance', [face('A', [0, 1, 0], [0, 10, 0]), face('B', [0, -1, 0], [0, 0, 0])], { value: 20 });
    const out = solveMates([A, B], [m1, m2]);
    const st = mateStatus(out, [m1, m2]);
    log('M2', { B: out[1].position.map((v) => +v.toFixed(3)), violated: [...st.violated], comps: st.components });
    expect(st.violated.size).toBeGreaterThan(0);
    expect(st.components.B).toBe('over');
  });
  it('M3 four-chain D->B->C->A(fixed), components and mates listed in worst order', () => {
    const A = comp('A', true, [0, 0, 0]), B = comp('B', false, [0, 300, 0]), C = comp('C', false, [0, -80, 0]), D = comp('D', false, [0, 500, 0]);
    const mDB = mate('mDB', 'distance', [face('D', [0, -1, 0], [0, 0, 0]), face('B', [0, 1, 0], [0, 10, 0])], { value: 3 });
    const mBC = mate('mBC', 'distance', [face('B', [0, -1, 0], [0, 0, 0]), face('C', [0, 1, 0], [0, 10, 0])], { value: 5 });
    const mCA = mate('mCA', 'coincident', [face('C', [0, -1, 0], [0, 0, 0]), face('A', [0, 1, 0], [0, 10, 0])]);
    const out = solveMates([D, B, C, A], [mDB, mBC, mCA]);
    const pos = Object.fromEntries(out.map((c) => [c.id, +c.position[1].toFixed(3)]));
    const st = mateStatus(out, [mDB, mBC, mCA]);
    log('M3', { pos, violated: [...st.violated], comps: st.components });
    expect(pos.C).toBeCloseTo(10, 3); expect(pos.B).toBeCloseTo(25, 3); expect(pos.D).toBeCloseTo(38, 3);
    expect(st.violated.size).toBe(0);
  });
  it('M5 closed loop: C mated to fixed A and to B (consistent), then the same loop with a conflict', () => {
    const A = comp('A', true, [0, 0, 0]), B = comp('B', false, [0, 77, 0]), C = comp('C', false, [0, -40, 0]);
    const mAB = mate('mAB', 'distance', [face('B', [0, -1, 0], [0, 0, 0]), face('A', [0, 1, 0], [0, 10, 0])], { value: 10 });
    const mCB = mate('mCB', 'distance', [face('C', [0, -1, 0], [0, 0, 0]), face('B', [0, 1, 0], [0, 10, 0])], { value: 10 });
    const mCA = mate('mCA', 'distance', [face('C', [0, -1, 0], [0, 0, 0]), face('A', [0, 1, 0], [0, 10, 0])], { value: 30 });
    const out = solveMates([C, B, A], [mCB, mCA, mAB]);
    const pos = Object.fromEntries(out.map((c) => [c.id, +c.position[1].toFixed(3)]));
    const st = mateStatus(out, [mCB, mCA, mAB]);
    const bad = { ...mCA, value: 35 };
    const out2 = solveMates([C, B, A], [mCB, bad, mAB]);
    const st2 = mateStatus(out2, [mCB, bad, mAB]);
    log('M5', { pos, violated: [...st.violated], comps: st.components, conflict: { pos: Object.fromEntries(out2.map((c) => [c.id, +c.position[1].toFixed(3)])), violated: [...st2.violated], comps: st2.components } });
    expect(pos.B).toBeCloseTo(20, 3); expect(pos.C).toBeCloseTo(40, 3);
    expect(st.violated.size).toBe(0);
    expect(st2.violated.size).toBeGreaterThan(0);
  });
  it('M4 consistent redundant mates (distance 10 twice) are not flagged as conflict', () => {
    const A = comp('A', true, [0, 0, 0]), B = comp('B', false, [0, 50, 0]);
    const m1 = mate('m1', 'distance', [face('A', [0, 1, 0], [0, 10, 0]), face('B', [0, -1, 0], [0, 0, 0])], { value: 10 });
    const m2 = mate('m2', 'distance', [face('B', [0, -1, 0], [0, 0, 0]), face('A', [0, 1, 0], [0, 10, 0])], { value: 10 });
    const out = solveMates([A, B], [m1, m2]);
    const st = mateStatus(out, [m1, m2]);
    log('M4', { B: out[1].position[1], violated: [...st.violated], comps: st.components });
    expect(out[1].position[1]).toBeCloseTo(20, 3);
    expect(st.violated.size).toBe(0);
  });
});

describe('QA equations', () => {
  it('E1 circular reference is reported', () => {
    const doc = createDocument();
    (doc as { equations?: unknown }).equations = [{ id: 'e1', target: 'a', expression: 'b + 1' }, { id: 'e2', target: 'b', expression: 'a * 2' }];
    const r = evaluateEquations(doc);
    log('E1', r.errors);
    expect(Object.keys(r.errors).length).toBeGreaterThan(0);
  });
});
