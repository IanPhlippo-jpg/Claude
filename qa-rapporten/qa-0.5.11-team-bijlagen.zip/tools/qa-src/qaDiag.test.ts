import { it } from 'vitest';
import { createDocument } from '../core/document/types';
import { addCircle, addLine, createSketch } from '../core/sketch/model';
import { rebuildDocument } from '../core/features/rebuild';
import { edgeRef } from '../core/features/edgesets';
import { meshVolume } from '../core/features/solid';
const rect = (s: ReturnType<typeof createSketch>, x0: number, y0: number, x1: number, y1: number) => {
  const c = [{ x: x0, y: y0 }, { x: x1, y: y0 }, { x: x1, y: y1 }, { x: x0, y: y1 }];
  for (let i = 0; i < 4; i++) s = addLine(s, c[i], c[(i + 1) % 4])[0];
  return s;
};
it('T1 diag', () => {
  const mk = (r: number) => { const doc = createDocument();
    doc.sketches.sk1 = rect(createSketch('sk1', 'Sketch1', 'top'), 0, 0, 80, 80);
    doc.sketches.sk2 = addCircle(createSketch('sk2', 'Sketch2', 'top'), { x: 40, y: 40 }, r)[0];
    doc.features.push({ id: 'f1', type: 'extrude', name: 'B', sketchId: 'sk1', suppressed: false, op: 'boss', end: 'blind', depth: 10, reverse: false } as never);
    doc.features.push({ id: 'f2', type: 'extrude', name: 'C', sketchId: 'sk2', suppressed: false, op: 'cut', end: 'throughAll', depth: 0, reverse: true, direction2: { end: 'throughAll', depth: 0 } } as never);
    return doc; };
  for (const r of [17.5, 25]) {
    const doc = mk(r); const b = rebuildDocument(doc).bodies[0];
    const vs = meshVolume(b.geometry);
    const top = b.edges.filter((e) => e.closed).reduce((a, c) => (c.centroid.y > a.centroid.y ? c : a));
    doc.features.push({ id: 'r1', type: 'fillet', name: 'Fillet1', suppressed: false, size: 2, edges: [edgeRef(top)] } as never);
    const rr = rebuildDocument(doc);
    console.log('QA T1diag', JSON.stringify({ r, sharpMesh: vs, filleted: meshVolume(rr.bodies[0].geometry), loss: vs - meshVolume(rr.bodies[0].geometry), errors: rr.errors, warnings: rr.warnings, ref: edgeRef(top) }));
  }
  // the T1 sequence: fillet at 17.5, then change to 25
  const doc = mk(17.5); const b = rebuildDocument(doc).bodies[0];
  const top = b.edges.filter((e) => e.closed).reduce((a, c) => (c.centroid.y > a.centroid.y ? c : a));
  doc.features.push({ id: 'r1', type: 'fillet', name: 'Fillet1', suppressed: false, size: 2, edges: [edgeRef(top)] } as never);
  const sk = doc.sketches.sk2; const rid = Object.keys(sk.scalars ?? {})[0];
  (doc.sketches as Record<string, unknown>).sk2 = { ...sk, scalars: { ...sk.scalars, [rid]: 25 } };
  const r2 = rebuildDocument(doc);
  const sharp25 = (() => { const d = mk(25); return meshVolume(rebuildDocument(d).bodies[0].geometry); })();
  console.log('QA T1seq', JSON.stringify({ v: meshVolume(r2.bodies[0].geometry), sharpMesh25: sharp25, loss: sharp25 - meshVolume(r2.bodies[0].geometry), errors: r2.errors, warnings: r2.warnings }));
});
it('T2 diag', () => {
  const mk = (R: number) => { const doc = createDocument(); let s = createSketch('sk1', 'Sketch1', 'front');
    let axis; [s, axis] = addLine(s, { x: 0, y: -10 }, { x: 0, y: 60 }, true); s = rect(s, 10, 0, R, 40); doc.sketches.sk1 = s;
    doc.features.push({ id: 'f1', type: 'revolve', name: 'Revolve1', sketchId: 'sk1', suppressed: false, op: 'boss', axisEntityId: axis.id, angle: 360, reverse: false } as never); return doc; };
  for (const R of [30, 36]) { const doc = mk(R); const b = rebuildDocument(doc).bodies[0]; const vs = meshVolume(b.geometry);
    const ot = b.edges.filter((e) => e.closed && e.centroid.y > 39).reduce((a, c) => (c.length > a.length ? c : a));
    doc.features.push({ id: 'r1', type: 'fillet', name: 'Fillet1', suppressed: false, size: 3, edges: [edgeRef(ot)] } as never);
    const rr = rebuildDocument(doc); const v = meshVolume(rr.bodies[0].geometry);
    console.log('QA T2diag', JSON.stringify({ R, sharpMesh: vs, sharpExact: Math.PI * (R * R - 100) * 40, filleted: v, loss: vs - v, theoryLoss: (1 - Math.PI / 4) * 9 * 2 * Math.PI * (R - 3 * (10 - 3 * Math.PI) / (12 - 3 * Math.PI)), errors: rr.errors, warnings: rr.warnings })); }
});
