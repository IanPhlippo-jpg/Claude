// QA 0.5.10: T1-T3 on the B-rep kernel (OpenCascade), box-only
import { afterAll, beforeAll, it } from 'vitest';
import { readFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import { createDocument } from '../core/document/types';
import { addCircle, addLine, createSketch } from '../core/sketch/model';
import { rebuildDocument } from '../core/features/rebuild';
import { setBrepKernel } from '../core/features/brepKernel';
import { edgeRef } from '../core/features/edgesets';
import { meshVolume } from '../core/features/solid';
import { occtKernel } from '../core/occt/brep';
beforeAll(async () => {
  const require = createRequire(import.meta.url);
  const init = (await import('replicad-opencascadejs')).default as unknown as (o: { wasmBinary: Uint8Array }) => Promise<unknown>;
  const OC = await init({ wasmBinary: readFileSync(require.resolve('replicad-opencascadejs/wasm')) });
  const replicad = await import('replicad'); replicad.setOC(OC as never);
  setBrepKernel(occtKernel(OC, replicad));
}, 60000);
afterAll(() => setBrepKernel(null));
const rect = (s: ReturnType<typeof createSketch>, x0: number, y0: number, x1: number, y1: number) => {
  const c = [{ x: x0, y: y0 }, { x: x1, y: y0 }, { x: x1, y: y1 }, { x: x0, y: y1 }];
  for (let i = 0; i < 4; i++) s = addLine(s, c[i], c[(i + 1) % 4])[0];
  return s;
};
const vol = (b: { exactVolume?: number; geometry: never; exact?: boolean }) => ({ exact: !!b.exact, v: b.exactVolume ?? meshVolume(b.geometry) });
const log = (k: string, v: unknown) => console.log(`QA ${k}: ${JSON.stringify(v)}`);
it('B-T1 hole rim fillet, hole 35 -> 50', () => {
  const doc = createDocument();
  doc.sketches.sk1 = rect(createSketch('sk1', 'Sketch1', 'top'), 0, 0, 80, 80);
  doc.sketches.sk2 = addCircle(createSketch('sk2', 'Sketch2', 'top'), { x: 40, y: 40 }, 17.5)[0];
  doc.features.push({ id: 'f1', type: 'extrude', name: 'B', sketchId: 'sk1', suppressed: false, op: 'boss', end: 'blind', depth: 10, reverse: false } as never);
  doc.features.push({ id: 'f2', type: 'extrude', name: 'C', sketchId: 'sk2', suppressed: false, op: 'cut', end: 'throughAll', depth: 0, reverse: true, direction2: { end: 'throughAll', depth: 0 } } as never);
  const b0 = rebuildDocument(doc).bodies[0];
  const top = b0.edges.filter((e) => e.closed).reduce((a, c) => (c.centroid.y > a.centroid.y ? c : a));
  doc.features.push({ id: 'r1', type: 'fillet', name: 'Fillet1', suppressed: false, size: 2, edges: [edgeRef(top)] } as never);
  const r0 = rebuildDocument(doc);
  const sk = doc.sketches.sk2; const rid = Object.keys(sk.scalars ?? {})[0];
  (doc.sketches as Record<string, unknown>).sk2 = { ...sk, scalars: { ...sk.scalars, [rid]: 25 } };
  const r1 = rebuildDocument(doc);
  const L = (r: number) => (1 - Math.PI / 4) * 4 * 2 * Math.PI * (r + 2 * (10 - 3 * Math.PI) / (12 - 3 * Math.PI));
  log('B-T1', { at35: vol(r0.bodies[0] as never), sharp35: 64000 - Math.PI * 17.5 ** 2 * 10, expLoss35: L(17.5), at50: vol(r1.bodies[0] as never), sharp50: 64000 - Math.PI * 625 * 10, expLoss50: L(25), errors: r1.errors, warnings: r1.warnings });
}, 60000);
it('B-T2 revolve tube fillet, r 30 -> 36', () => {
  const doc = createDocument(); let s = createSketch('sk1', 'Sketch1', 'front');
  let axis; [s, axis] = addLine(s, { x: 0, y: -10 }, { x: 0, y: 60 }, true); s = rect(s, 10, 0, 30, 40); doc.sketches.sk1 = s;
  doc.features.push({ id: 'f1', type: 'revolve', name: 'Revolve1', sketchId: 'sk1', suppressed: false, op: 'boss', axisEntityId: axis.id, angle: 360, reverse: false } as never);
  const b0 = rebuildDocument(doc).bodies[0];
  const ot = b0.edges.filter((e) => e.closed && e.centroid.y > 39).reduce((a, c) => (c.length > a.length ? c : a));
  doc.features.push({ id: 'r1', type: 'fillet', name: 'Fillet1', suppressed: false, size: 3, edges: [edgeRef(ot)] } as never);
  const r0 = rebuildDocument(doc);
  const sk = doc.sketches.sk1;
  doc.sketches.sk1 = { ...sk, points: Object.fromEntries(Object.entries(sk.points).map(([id, p]) => [id, Math.abs(p.x - 30) < 1e-9 ? { ...p, x: 36 } : p])) };
  const r1 = rebuildDocument(doc);
  const L = (R: number) => (1 - Math.PI / 4) * 9 * 2 * Math.PI * (R - 3 * (10 - 3 * Math.PI) / (12 - 3 * Math.PI));
  log('B-T2', { at30: vol(r0.bodies[0] as never), sharp30: Math.PI * 800 * 40, expLoss30: L(30), at36: vol(r1.bodies[0] as never), sharp36: Math.PI * (1296 - 100) * 40, expLoss36: L(36), errors: r1.errors });
}, 60000);
it('B-T3 split edge', () => {
  const doc = createDocument();
  doc.sketches.sk1 = rect(createSketch('sk1', 'Sketch1', 'top'), 0, 0, 80, 40);
  doc.features.push({ id: 'f1', type: 'extrude', name: 'B', sketchId: 'sk1', suppressed: false, op: 'boss', end: 'blind', depth: 10, reverse: false } as never);
  const b0 = rebuildDocument(doc).bodies[0];
  const longest = b0.edges.filter((e) => e.straight && Math.abs(e.centroid.y - 10) < 1e-6).reduce((a, b) => (b.length > a.length ? b : a));
  doc.features.push({ id: 'r1', type: 'fillet', name: 'Fillet1', suppressed: false, size: 2, edges: [edgeRef(longest)] } as never);
  doc.sketches.sk3 = rect(createSketch('sk3', 'Sketch3', 'top'), 35, 25, 45, 45);
  doc.features.splice(1, 0, { id: 'f3', type: 'extrude', name: 'Slot', sketchId: 'sk3', suppressed: false, op: 'cut', end: 'throughAll', depth: 0, reverse: true, direction2: { end: 'throughAll', depth: 0 } } as never);
  const r = rebuildDocument(doc);
  const sharp = 30500, loss = (1 - Math.PI / 4) * 4;
  log('B-T3', { v: vol(r.bodies[0] as never), both: sharp - loss * 70, oneHalf: sharp - loss * 35, errors: r.errors, warnings: r.warnings });
}, 60000);
