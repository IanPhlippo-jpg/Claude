// QA 0.5.11: F140 diagnosis - which edge did B-T3 pick?
import { afterAll, beforeAll, it } from 'vitest';
import { readFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import { createDocument } from '../core/document/types';
import { addLine, createSketch } from '../core/sketch/model';
import { rebuildDocument } from '../core/features/rebuild';
import { setBrepKernel } from '../core/features/brepKernel';
import { edgeRef } from '../core/features/edgesets';
import { meshVolume } from '../core/features/solid';
import { occtKernel } from '../core/occt/brep';
let K: unknown;
beforeAll(async () => {
  const require = createRequire(import.meta.url);
  const init = (await import('replicad-opencascadejs')).default as unknown as (o: { wasmBinary: Uint8Array }) => Promise<unknown>;
  const OC = await init({ wasmBinary: readFileSync(require.resolve('replicad-opencascadejs/wasm')) });
  const replicad = await import('replicad'); replicad.setOC(OC as never);
  K = occtKernel(OC as never, replicad as never); setBrepKernel(K as never);
}, 60000);
afterAll(() => setBrepKernel(null));
const rect = (s: ReturnType<typeof createSketch>, x0: number, y0: number, x1: number, y1: number) => {
  const c = [{ x: x0, y: y0 }, { x: x1, y: y0 }, { x: x1, y: y1 }, { x: x0, y: y1 }];
  for (let i = 0; i < 4; i++) s = addLine(s, c[i], c[(i + 1) % 4])[0];
  return s;
};
const CORNER = 4 * (1 - Math.PI / 4);
for (const kernel of ['brep', 'mesh'] as const) for (const which of ['z0', 'zm40'] as const) for (const slotMode of ['bothDirs', 'plain'] as const) {
  it(`T3 ${kernel} ${which} ${slotMode}`, () => {
    if (kernel === 'mesh') setBrepKernel(null); else setBrepKernel(K as never);
    const doc = createDocument();
    doc.sketches.sk1 = rect(createSketch('sk1', 'Sketch1', 'top'), 0, 0, 80, 40);
    doc.features.push({ id: 'f1', type: 'extrude', name: 'B', sketchId: 'sk1', suppressed: false, op: 'boss', end: 'blind', depth: 10, reverse: false } as never);
    const b0 = rebuildDocument(doc).bodies[0];
    const longs = b0.edges.filter((e) => e.straight && Math.abs(e.centroid.y - 10) < 1e-6 && Math.abs(e.length - 80) < 1e-3);
    const first = b0.edges.filter((e) => e.straight && Math.abs(e.centroid.y - 10) < 1e-6).reduce((a, b) => (b.length > a.length ? b : a));
    const edge = longs.reduce((a, x) => (which === 'zm40' ? (x.centroid.z < a.centroid.z ? x : a) : (x.centroid.z > a.centroid.z ? x : a)));
    doc.features.push({ id: 'r1', type: 'fillet', name: 'Fillet1', suppressed: false, size: 2, edges: [edgeRef(edge)] } as never);
    doc.sketches.sk3 = rect(createSketch('sk3', 'Sketch3', 'top'), 35, 25, 45, 45);
    const slot = slotMode === 'bothDirs'
      ? { id: 'f3', type: 'extrude', name: 'Slot', sketchId: 'sk3', suppressed: false, op: 'cut', end: 'throughAll', depth: 0, reverse: true, direction2: { end: 'throughAll', depth: 0 } }
      : { id: 'f3', type: 'extrude', name: 'Slot', sketchId: 'sk3', suppressed: false, op: 'cut', end: 'throughAll', depth: 0, reverse: false };
    doc.features.splice(1, 0, slot as never);
    const r = rebuildDocument(doc);
    const b = r.bodies[0] as unknown as { exact?: boolean; exactVolume?: number; geometry: never };
    const v = b.exactVolume ?? meshVolume(b.geometry);
    const exp = which === 'zm40' ? 30500 - 70 * CORNER : 30500 - 80 * CORNER;
    console.log(`QA T3diag ${JSON.stringify({ kernel, which, slotMode, firstPickZ: first.centroid.z, picked: edge.centroid, exact: !!b.exact, v: +v.toFixed(3), expected: +exp.toFixed(3), diff: +(v - exp).toFixed(3), errors: r.errors, warnings: r.warnings })}`);
  }, 60000);
}
