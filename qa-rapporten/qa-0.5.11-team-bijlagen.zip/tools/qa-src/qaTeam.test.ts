// QA 0.5.11 team-integratie: controles 1a (STRATI-01), 1b (F175 ellips), 1c (MT5D-13 wrap). Diagnose + asserts op meetbare feiten.
import { afterAll, beforeAll, it } from 'vitest';
import { readFileSync, writeFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import { createDocument } from '../core/document/types';
import { addArc, addCircle, addEllipse, addLine, addSpline, createSketch } from '../core/sketch/model';
import { rebuildDocument } from '../core/features/rebuild';
import { setBrepKernel } from '../core/features/brepKernel';
import { edgeRef } from '../core/features/edgesets';
import { meshVolume } from '../core/features/solid';
import { volumeMismatch } from '../core/features/volumeCheck';
import { occtKernel } from '../core/occt/brep';
import { shapesToStep } from '../core/occt/step';
import { CORNER, extrude, fillet, rect, t3Slot } from '../qa/qaModels';

let K: unknown; let RC: unknown;
const out: unknown[] = [];
beforeAll(async () => {
  const require = createRequire(import.meta.url);
  const init = (await import('replicad-opencascadejs')).default as unknown as (o: { wasmBinary: Uint8Array }) => Promise<unknown>;
  const OC = await init({ wasmBinary: readFileSync(require.resolve('replicad-opencascadejs/wasm')) });
  const replicad = await import('replicad'); replicad.setOC(OC as never); RC = replicad;
  K = occtKernel(OC as never, replicad as never); setBrepKernel(K as never);
}, 60000);
afterAll(() => { setBrepKernel(null); writeFileSync(process.env.QA_TEAM_OUT ?? '/tmp/qa-team.json', JSON.stringify(out, null, 1)); });
const use = (k: 'brep' | 'mesh') => setBrepKernel(k === 'brep' ? (K as never) : null);
type Doc = ReturnType<typeof createDocument>;
const measure = (doc: Doc) => {
  const r = rebuildDocument(doc);
  const b = r.bodies[0] as unknown as { id: string; exact?: boolean; exactVolume?: number; geometry: never };
  const mv = meshVolume(b.geometry);
  const v = b.exactVolume ?? mv;
  const faceted = r.bodies.filter((x) => !(x as { exact?: boolean }).exact).length;
  return { r, b, v, mv, exact: !!b.exact, faceted, nBodies: r.bodies.length, errors: r.errors, warnings: r.warnings ?? {} };
};
const log = (o: Record<string, unknown>) => { out.push(o); console.log('QA TEAM ' + JSON.stringify(o)); };
const statusText = (m: ReturnType<typeof measure>) => (m.faceted > 0 ? `Faceted ${m.faceted}/${m.nBodies}` : '(geen Faceted-cel)');
const treeTitle = (m: ReturnType<typeof measure>) => (m.exact ? 'Exact surfaces (B-rep)' : 'Faceted (mesh kernel): STEP writes it as sewn facets');

// ---------- 1a STRATI-01 (a): T3 + sleuf vóór de fillet + basis 80 -> 100 ----------
const t3At = (len: number) => {
  const doc = createDocument();
  doc.sketches.s1 = rect('s1', 'top', 0, 0, len, 40);
  doc.features.push(extrude('e1', 's1', 'boss', 10));
  return doc;
};
const pickZm40 = (doc: Doc, len: number) => rebuildDocument(doc).bodies[0].edges.filter((e) => e.straight && Math.abs(e.length - len) < 1e-3 && Math.abs(e.centroid.y - 10) < 1e-3).reduce((a, x) => (x.centroid.z < a.centroid.z ? x : a));
const stretch = (doc: Doc, from: number, to: number) => { for (const p of Object.values(doc.sketches.s1.points) as { x: number }[]) if (Math.abs(p.x - from) < 1e-9) p.x = to; };
for (const kernel of ['brep', 'mesh'] as const) {
  it(`1a ${kernel}`, () => {
    use(kernel);
    const C = CORNER(2);
    // varianten: A = Strati (sleuf ervóór, dan 80->100); B = alleen 80->100 (geen sleuf); C = alleen sleuf (repo-T3); D = orakel: eerst bouwen op 100 + sleuf, beide stukken handmatig kiezen
    const res: Record<string, unknown> = {};
    for (const variant of ['A_slot_then_stretch', 'B_stretch_only', 'C_slot_only', 'E_stretch_then_slot'] as const) {
      const doc = t3At(80);
      const edge = pickZm40(doc, 80);
      doc.features.push(fillet('r1', 2, [edge]));
      if (variant !== 'B_stretch_only' && variant !== 'E_stretch_then_slot') { t3Slot(doc, 'through'); doc.features.splice(1, 0, doc.features.pop()!); }
      if (variant !== 'C_slot_only') stretch(doc, 80, 100);
      if (variant === 'E_stretch_then_slot') { t3Slot(doc, 'through'); doc.features.splice(1, 0, doc.features.pop()!); }
      const m = measure(doc);
      const exp = variant === 'B_stretch_only' ? 40000 - 100 * C : variant === 'C_slot_only' ? 30500 - 70 * C : 38500 - 90 * C;
      res[variant] = { v: +m.v.toFixed(3), expected: +exp.toFixed(3), diff: +(m.v - exp).toFixed(3), exact: m.exact, errors: m.errors, warnings: m.warnings, status: statusText(m) };
    }
    // orakel D: model 100 + sleuf, beide stukken op z=-40 met de hand
    {
      const doc = t3At(100); t3Slot(doc, 'through');
      const pieces = rebuildDocument(doc).bodies[0].edges.filter((e) => e.straight && Math.abs(e.centroid.y - 10) < 1e-3 && Math.abs(e.centroid.z + 40) < 1e-3 && e.length > 30);
      doc.features.push(fillet('r1', 2, pieces));
      const m = measure(doc);
      res.D_oracle_manual = { pieces: pieces.map((p) => +p.length.toFixed(3)), v: +m.v.toFixed(3), expected: +(38500 - 90 * C).toFixed(3), diff: +(m.v - (38500 - 90 * C)).toFixed(3), errors: m.errors, warnings: m.warnings };
    }
    log({ test: '1a', kernel, silentWrongIfHalf: +(38500 - 35 * C).toFixed(3), ...res });
  }, 120000);
}
// cross-kernel vangnet voor variant A
it('1a vangnet', () => {
  const build = (k: 'brep' | 'mesh') => { use(k); const doc = t3At(80); const edge = pickZm40(doc, 80); doc.features.push(fillet('r1', 2, [edge])); t3Slot(doc, 'through'); doc.features.splice(1, 0, doc.features.pop()!); stretch(doc, 80, 100); return measure(doc); };
  const b = build('brep'); const m = build('mesh');
  log({ test: '1a-vangnet', exactV: +b.v.toFixed(3), meshV: +m.v.toFixed(3), volumeMismatch: volumeMismatch(m.v, b.v) });
}, 120000);

// ---------- STRATI-01 (b): gebogen open rand (R10-hoekboog) gesplitst door sleuf ervóór ----------
const arcPlate = () => {
  let s = createSketch('s1', 's1', 'top');
  s = addLine(s, { x: 0, y: 0 }, { x: 80, y: 0 })[0];
  s = addLine(s, { x: 80, y: 0 }, { x: 80, y: 30 })[0];
  s = addArc(s, { x: 70, y: 30 }, { x: 80, y: 30 }, { x: 70, y: 40 }, true)[0];
  s = addLine(s, { x: 70, y: 40 }, { x: 0, y: 40 })[0];
  s = addLine(s, { x: 0, y: 40 }, { x: 0, y: 0 })[0];
  const doc = createDocument(); doc.sketches.s1 = s; doc.features.push(extrude('e1', 's1', 'boss', 10)); return doc;
};
const arcSlot = (doc: Doc) => { doc.sketches.s2 = rect('s2', 'top', 74, 30, 76, 45); doc.features.push(extrude('c1', 's2', 'cut', 0, { end: 'throughAll' })); };
const topArcs = (doc: Doc) => rebuildDocument(doc).bodies[0].edges.filter((e) => !e.straight && Math.abs(e.centroid.y - 10) < 1e-3 && e.centroid.x > 69);
for (const kernel of ['brep', 'mesh'] as const) {
  it(`1a-b gebogen ${kernel}`, () => {
    use(kernel);
    const d1 = arcPlate(); const arc = topArcs(d1);
    d1.features.push(fillet('r1', 2, arc)); arcSlot(d1); d1.features.splice(1, 0, d1.features.pop()!);
    const m1 = measure(d1);
    const d2 = arcPlate(); arcSlot(d2); const pieces = topArcs(d2); d2.features.push(fillet('r1', 2, pieces));
    const m2 = measure(d2);
    const d3 = arcPlate(); arcSlot(d3); const m3 = measure(d3);
    log({ test: '1a-b', kernel, arcEdgesBefore: arc.map((e) => +e.length.toFixed(3)), piecesOracle: pieces.map((e) => +e.length.toFixed(3)), sharp: +m3.v.toFixed(3), insertedBefore: { v: +m1.v.toFixed(3), errors: m1.errors, warnings: m1.warnings }, oracle: { v: +m2.v.toFixed(3), errors: m2.errors }, diff: +(m1.v - m2.v).toFixed(3), lossInserted: +(m3.v - m1.v).toFixed(3), lossOracle: +(m3.v - m2.v).toFixed(3) });
  }, 120000);
}

// ---------- 1b F175: ellips 40x20 x 10 ----------
const stepCounts = async (r: ReturnType<typeof rebuildDocument>) => {
  const id = r.bodies[0].id; const shape = (r as { brep?: Record<string, unknown> }).brep?.[id];
  if (!shape) return null;
  const { bytes, volumes } = await shapesToStep(RC as never, [{ name: 'b', shape }]);
  const t = new TextDecoder().decode(bytes);
  const c = (re: RegExp) => (t.match(re) ?? []).length;
  return { ELLIPSE: c(/=\s*ELLIPSE\(/g), B_SPLINE: c(/B_SPLINE_CURVE/g), LINE: c(/=\s*LINE\(/g), PLANE: c(/=\s*PLANE\(/g), CYL: c(/CYLINDRICAL_SURFACE/g), stepVolume: +volumes[0].toFixed(3) };
};
for (const kernel of ['brep', 'mesh'] as const) {
  it(`1b ellips ${kernel}`, async () => {
    use(kernel);
    const doc = createDocument();
    doc.sketches.s1 = addEllipse(createSketch('s1', 's1', 'top'), { x: 0, y: 0 }, { x: 20, y: 0 }, 10)[0];
    doc.features.push(extrude('e1', 's1', 'boss', 10));
    const m = measure(doc); const exp = Math.PI * 20 * 10 * 10;
    const step = kernel === 'brep' ? await stepCounts(m.r) : null;
    log({ test: '1b-ellipse', kernel, v: +m.v.toFixed(3), meshV: +m.mv.toFixed(3), expected: +exp.toFixed(3), diff: +(m.v - exp).toFixed(3), relPct: +((m.v - exp) / exp * 100).toFixed(4), exact: m.exact, tree: treeTitle(m), status: statusText(m), errors: m.errors, warnings: m.warnings, volumeMismatch: volumeMismatch(m.mv, m.v), step });
  }, 120000);
}
// controle: cirkel R10 x 10 (moet exact + CYLINDRICAL_SURFACE)
it('1b controle cirkel brep', async () => {
  use('brep');
  const doc = createDocument(); doc.sketches.s1 = addCircle(createSketch('s1', 's1', 'top'), { x: 0, y: 0 }, 10)[0]; doc.features.push(extrude('e1', 's1', 'boss', 10));
  const m = measure(doc); const exp = Math.PI * 100 * 10;
  log({ test: '1b-circle-control', v: +m.v.toFixed(3), expected: +exp.toFixed(3), diff: +(m.v - exp).toFixed(4), exact: m.exact, step: await stepCounts(m.r) });
}, 120000);
// spline: gesloten profiel spline + lijn
it('1b spline brep', async () => {
  use('brep');
  let s = createSketch('s1', 's1', 'top');
  const [s1, sp] = addSpline(s, [{ x: 0, y: 0 }, { x: 10, y: 12 }, { x: 25, y: 8 }, { x: 40, y: 0 }]);
  s = addLine(s1, sp.points[sp.points.length - 1], sp.points[0])[0];
  const doc = createDocument(); doc.sketches.s1 = s; doc.features.push(extrude('e1', 's1', 'boss', 10));
  const m = measure(doc);
  log({ test: '1b-spline', v: +m.v.toFixed(3), meshV: +m.mv.toFixed(3), exact: m.exact, tree: treeTitle(m), status: statusText(m), errors: m.errors, warnings: m.warnings, step: m.exact ? await stepCounts(m.r) : null });
}, 120000);

// ---------- 1c MT5D-13: wrap-patch op exact lichaam ----------
for (const kind of ['emboss', 'deboss'] as const) {
  it(`1c wrap ${kind}`, async () => {
    use('brep');
    const s1 = addCircle(createSketch('s1', 's1', 'top'), { x: 0, y: 0 }, 20)[0];
    const s2 = rect('s2', 'front', -5, 25, 5, 35);
    const doc = { ...createDocument('Rol'), sketches: { s1, s2 } } as Doc;
    doc.features = [
      { id: 'k1', type: 'sketch', name: 'Sketch1', sketchId: 's1', suppressed: false } as never,
      extrude('f1', 's1', 'boss', 60),
      { id: 'k2', type: 'sketch', name: 'Sketch2', sketchId: 's2', suppressed: false } as never,
      { id: 'w1', type: 'wrap', name: 'Wrap1', sketchId: 's2', suppressed: false, kind, depth: 2, face: { center: [0, 0, 0], axis: [0, 1, 0], radius: 20, label: 'Face<1>' } } as never,
    ];
    const m = measure(doc);
    const cyl = Math.PI * 400 * 60;
    const patch = kind === 'emboss' ? (10 / 20) * ((22 * 22 - 400) / 2) * 10 : (10 / 20) * ((400 - 18 * 18) / 2) * 10;
    const exp = kind === 'emboss' ? cyl + patch : cyl - patch;
    const step = await stepCounts(m.r);
    log({ test: '1c-wrap', kind, v: +m.v.toFixed(3), expected: +exp.toFixed(3), diff: +(m.v - exp).toFixed(3), patchErrPct: +((m.v - exp) / patch * 100).toFixed(2), exact: m.exact, tree: treeTitle(m), status: statusText(m), errors: m.errors, warnings: m.warnings, step });
  }, 120000);
}
