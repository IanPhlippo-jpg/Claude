# Risk & Optimization — Phlippo CAD 0.5.11 (HEAD db0d4b2)

*3 november 2026, 11:32 (Europe/Brussels, CET). Strikt read-only: niets gebouwd of gedraaid (geen Electron/vitest/builds), alleen rg/lezen/kleine python-vergelijkingen. Alleen dit bestand geschreven. Alles zonder bestand:regel of logregel heet **niet geverifieerd**. Paden zonder prefix = `app-0.5.11/`; `R/` = `report-0.5.11/`.*

## 0. Herkomst en staat van de boom

- `app-0.5.11` HEAD is **dcd49df** (auteur "QA <qa@local>", 2026-11-03 09:11 CET, onderwerp gekopieerd van db0d4b2): een lokale stand-in, niet db0d4b2 zelf.
- Bewijs dat de inhoud db0d4b2 is: `phlippo-0.5.11-src.zip` heeft als zip-commentaar `db0d4b27d857c42b898bcec68c65240b3fe855e9` (git archive schrijft daar de commit-id), sha256 580b7254…175d. Ik vergeleek de zip met `git ls-files` van app-0.5.11: **688 = 688 bestanden, 0 inhoudsverschillen** (na CRLF-normalisatie, want de checkout heeft CRLF). **De boom is dus inhoudelijk db0d4b2.** De git-geschiedenis van db0d4b2 zelf is niet aanwezig: **niet geverifieerd**.
- Niet gevolgd: `src/qaext/` (QA-extra's). `e2e/run-regression.mjs:51` telt die niet mee, omdat de dirty-check `--untracked-files=no` gebruikt.

## 1. Score: **6/10** (eens met QA; intern 6,3, naar beneden afgerond)

Geometrie en AutoRecover zijn echt beter geworden (F139 opgelost, T1–T3 correct, AutoRecover in de code opgelost). Wat de score tegenhoudt:
- het vangnet tegen stille fouten is grof (F172);
- er is geen groen bewijs op HEAD buiten de box (F176);
- het bewijs per pariteitsrij is slordig (RISK-03/04/08).

## 2. GO / NO-GO

| Doel | Oordeel | Voorwaarden om te kantelen |
|---|---|---|
| **Klaar** | **NO-GO** | (a) groene Actions-run met checks, desktop en regressie op de release-commit (F176); (b) een kruiscontrole per feature die waarschuwt bij de juiste feature en een e2e-test heeft (F172, RISK-02); (c) een waarschuwing "benaderd" voor ellips- en spline-bodies (F175/RISK-09); (d) GO-voorwaarden 9 en 10 op ✅. |
| **Publiceren** | **NO-GO** | Alles van "klaar", plus: een gesigneerde installer (F49/F117, `win/signature-0.5.11.txt`: NotSigned); een Windows-run op dezelfde commit (RISK-07); juridische hygiëne vóór een publieke repo (RISK-06). |
| **Eigen gebruik (Ian)** | **GO, met voorwaarden** | Zie hieronder. |

Voorwaarden voor eigen gebruik:
1. Gebruik de desktop-build met B-rep aan, niet de browser. Mesh-only bodies krijgen geen kruiscontrole.
2. Kijk bij "Faceted n/m" in de statusbalk en bij What's Wrong. Een melding "features differ" hoort bij het hele body, niet per se bij de laatste feature (RISK-02).
3. Voor kritieke maten: controleer Mass Properties na fillets op gesplitste randen of op randen rond gaten en sleuven, met een handberekening of een SW-referentie.
4. Ellipsen en splines zijn in B-rep 96-segment polylijnen (`src/core/occt/brep.ts:68-76`). Vertrouw massa en STEP daarvan niet als exact.
5. Druk zelf op Ctrl+S. AutoRecover is een vangnet.
6. Vóór de upgrade: open crash-kopieën uit 0.5.10 eerst daarin. 0.5.11 toont ze niet meer (RISK-05).

## 3. Top 3

1. **Het vangnet tegen stille geometriefouten is te grof.** `volumeCheck.ts:8` hanteert 0,5 % relatief per body. De eigen test geeft toe dat de F140-fout (8,58 mm³ op 30 440 = 0,03 %) eronder valt (`volumeCheck.test.ts:8-9`). De check:
   - waarschuwt alleen, het exacte body vervangt het mesh-body toch;
   - koppelt de melding aan de laatste feature (`src/app/brepRefine.ts:77`);
   - heeft geen integratie- of e2e-test;
   - werkt niet op mesh-only bodies;
   - is blind voor common-mode fouten (verkeerde schets-, mirror- of patternpositie).

   De voorgestelde drempel uit NAAR-100 P0-2 (max(0,5 mm³; 0,1 %)) zou op correcte modellen vals alarm geven (RISK-01).
2. **De CI- en bewijsketen klopt nog niet.**
   - Er is geen groene Actions-run op HEAD. De laatste runs waren rood, en de run op 772236a startte niet door het minutenquotum (`R/win/linux/README.md:8-9`, TASKS.md:835-836).
   - De Windows-logs zijn van 0495219 en 1fd00e3, niet van db0d4b2.
   - In 28 van de 62 pariteitsrijen verwijst het bewijs naar logbestanden die niet in `R/logs` staan (RISK-03).
   - De extra QA-tests (14/14) bevatten voor qaBrep, qaDiag en qaT3diag **0 asserties** (RISK-08).
3. **Het pad naar 100 % schuift richting een juridisch risico** (geen juridisch advies, wel een signaal). NAAR-100 biedt "repo publiek maken" aan als oplossing voor het Actions-quotum (P0-1) en voor gratis signing (rij 60, SignPath OSS). Dat zou publiceren:
   - `docs/26-zelfcontrole-1op1.md` (gevolgd, 63 regels, kleurgemeten framevergelijking met SOLIDWORKS Design 2026);
   - `docs/06:3` (de opdracht "exact uitzien als SOLIDWORKS");
   - 15 docs die SOLIDWORKS noemen.

   P2-12 (overlay-diff binnen 4 px) en R0 (SW-screenshots en Mass Properties) duwen ook richting een look-alike. Het gebruik van een SW-licentie om een concurrent te benchmarken kan onder de EULA vallen: **niet geverifieerd** (EULA niet gelezen). Zie RISK-06.

## 4. Ernstcorrecties

### 4.1 Houdt "0 Kritiek" stand?
**Ja, als "0 *aangetoonde* Kritiek".** Er is geen bewezen stille fout op HEAD. Per punt:

- **F139 (fillet-verlies), Opgelost: eens.**
  - Repo-test `src/qa/qaBrep.test.ts:60-79` kiest de rand op positie (`qaModels.ts:53-62`, `reduce(centroid.z min)`), met 4 sleufvarianten plus een mesh-gekozen variant, tolerantie 0,01 mm³.
  - `logs/qa-t3diag.log`: B-rep zm40 = 30439,911 (verschil 0); mesh −0,845 (tesselatie).
  - vitest.log: 121 bestanden en 487 tests geslaagd, en er zijn 121 gevolgde `*.test.ts` (`vite.config.ts:40`). Per-testnamen staan niet in het log, dus "qaBrep T3 groen" is afgeleid uit de telling.
- **F51 Major (was Kritiek): eens.**
  - `rebuild.ts:3313-3314` waarschuwt "has no exact (B-rep) version".
  - Alleen als K gezet is, het body eerder exact was (`exactBefore.has(b)`) en er nog geen warning is. Een body dat vanaf de eerste feature mesh is, krijgt dus geen melding per feature, alleen "Faceted n/m" (afgeleid uit de code; de statusbalk heb ik niet gezien).
- **F93 Major: eens.** Claims van 98/98 zonder platform of commit.
- **F31/F147/F148/F176 (CI) Major: eens.** Volgens mijn regel is een CI-waarheidsprobleem ≥ Major. F176 terecht P0.
- **F159/F172: Major, maar F172 moet P0 krijgen** (findings.json zegt P1, NAAR-100 noemt het P0-2: inconsistent). Geen Kritiek, omdat er geen bekend falend geval op HEAD is. Wel de enige verdediging tegen de klasse fouten die F140 leek te zijn.
- **F175 (ellips/spline als segmenten, toch "exact"): Major, op de grens van Kritiek** voor publiceren.
  - `brep.ts:4` en `:68-76` gebruiken `sampleEntity(sketch,e,96)`.
  - Ik vond geen gebruikerswaarschuwing (`rg approximat|segments` in `src/app` en `rebuild.ts`: alleen de F51-melding).
  - De fout is klein, maar STEP krijgt vlakke facetten op een body dat "exact" heet. Wordt **Kritiek** als het zonder label gepubliceerd wordt.
- **AutoRecover (mijn oude F150/F151 = QA F153/F154/F156), Opgelost: eens.**
  - `electron/recover.cjs:19-21` sleutel sha256(id+pad); `:41-56` tmp → fsync → rename; `:32-38` map in main; `:79-94` opruimen.
  - `src/app/slices/document.ts:75-83` geeft een id, valideert en markeert "(Recovered)" als dirty.
  - `logs/desktop-recover.log` 21/21. Dat log heeft geen commitkop.
  - Rest: RISK-05.
- **F173 (ruime toleranties), Minor: eens, één nuance.**
  - Stadium-tolerantie 25 mm³ (`qaStrict.test.ts:69`) is groter dan een fout van F140-grootte (8,58). De stadiumvariant zou die op mesh niet vangen.
  - De B-rep-tests (0,01) wel.

### 4.2 Is het intrekken van F140 terecht?
**Ja, met hoge zekerheid. Bewezen door afleiding, niet door een herhaling op 0.5.10.**
- De 0.5.10-test (`report-0.5.10/tools/qa-src/qaBrep.test.ts:62`) koos de "langste" rand bij y=10. Beide kandidaten zijn 80 mm, dus de eerste wint, en die volgorde hangt van de kernel af. Onder B-rep is dat z=0 (`qa-t3diag.log` firstPickZ 0).
- 30431,327 = 30500 − 80·CORNER(2) tot 3 decimalen. Precies de 0.5.10-waarde.
- `edgesets.ts` en `occt.worker.ts` zijn ongewijzigd tussen 0.5.10 en 0.5.11. `brep.ts` verschilt alleen door `sphere()` (:357-362).
- De herhaling op 0.5.10 faalde (vite niet opgelost, `logs/qa-t3diag-on-0.5.10.log`).
- **Restpunten:**
  - QA's eigen qaext B-T3 meet nog steeds de z=0-rand (`R/tools/qa-src/qaBrep.test.ts:62`, ongewijzigd t.o.v. 0.5.10) en heeft geen `expect`. Het "slaagt" dus altijd.
  - De repo-T3 bewijst alleen volume, niet *welke* randen gerond zijn.

### 4.3 Is F172 (volumecheck) een voldoende vangnet? **Nee.**
| Vraag | Antwoord (bewijs) |
|---|---|
| Tolerantie | 0,5 % relatief, `max(|meshV|,|exactV|)` per body; null bij NaN of 0 (`volumeCheck.ts:8`). |
| Welke operaties | Alleen bodies met `b.exact`, na elke B-rep-refine (`brepRefine.ts:71-79`). Mesh-only bodies, browser of B-rep uit: **geen check**. Assemblies en mates: **geen check**. |
| Gedrag | **Alleen waarschuwen**, en een toast "features differ … see What's Wrong" (`brepRefine.ts:89-90`). Geen blokkade, geen terugval op mesh, geen vlag op STEP of Mass Properties. Bij een time-out wel terugval op mesh (`brepRefine.ts:149`). |
| Toewijzing | Aan `b.featureIds[last]` (`brepRefine.ts:77`). Kan de verkeerde feature noemen. |
| Fouten met gelijk volume | **Niet gevangen**: gespiegeld of verschoven, verkeerde rand van dezelfde lengte, fout in een gedeelde invoer (common-mode). |
| Test | Alleen een unittest van de pure functie (`volumeCheck.test.ts`). Geen e2e of integratie van het waarschuwingspad (rg in e2e: niets gevonden). |

**Extra controles, op prioriteit:**
1. Kruiscontrole per feature in plaats van per body: Δvolume van feature *n* in mesh tegenover B-rep.
2. Een tesselatie-bewuste drempel: bijvoorbeeld k·(chordefout × gebogen oppervlak), niet een vaste mm³.
3. Topologie per fillet en chamfer: aantal nieuwe faces, en of de gerond-gemelde rand-id's de gevraagde zijn. Vangt "verkeerde rand, zelfde lengte".
4. bbox (±tesselatietolerantie), oppervlak (‰) en zwaartepunt (‰ van de diagonaal) tussen mesh en B-rep. Het zwaartepunt vangt spiegel- en verschuivingsfouten bij gelijk volume.
5. Traagheidstensor (Mass Properties) op golden models.
6. Golden models uit R0 (SW Mass Properties), plus een STEP-rondgang (export → import → volume/bbox/aantal faces).
7. Een e2e-test die een mismatch forceert en controleert dat melding, feature-id en toast verschijnen.
8. Optioneel: STEP en Mass Properties markeren als "onbetrouwbaar" zolang er een mismatch openstaat.

## 5. Oordeel NAAR-100

**Wat ontbreekt:**
- **Bewijs per rij op de release-commit.** 28 rijen citeren logbestanden die niet bestaan (RISK-03). Rij 56 heeft nog 0.5.10-cijfers ("worker-pass 5/6 … 226 s"). Eis per rij: logpad, regel en commitkop.
- **CI-waarheid.** P0-1 lost het quotum op, maar mist:
  - een Windows-job (RISK-07);
  - een verplichte status-check / branch protection: **niet geverifieerd**;
  - een eis dat de logs van het rapport uit die ene run komen.
- **Dataverlies.** Er zijn geen acceptatietests voor: upgrade-recovery (RISK-05), `.bak`/`.bak2` herstel, een schijf die vol raakt tijdens save, en openen-en-opslaan van 0.5.x-bestanden (round-trip van legacy-namen staat wel in `legacyNames.test.ts:11`).
- **Juridische en trade-dress-grens.**
  - P2-12 (4 px overlay) en R0 werken de herdefinitie van rij 54 tegen.
  - "Repo publiek" ontbreekt als risico (RISK-06).
  - F112: de Options-boom met 379 sleutels (334 zonder werking) bootst SW's structuur na. Signaal, **niet geverifieerd** of dat juridisch relevant is.

**Definitie van 100 %:** *functionele en workflow-pariteit*. Dezelfde modellen bouwbaar, met dezelfde massa, topologie en export binnen gemeten toleranties, en elke "aanwezig" bewezen op de release-commit. **Geen visuele kopie.** Rij 54 herdefiniëren tot "herkenbaar en consistent, eigen iconen". P2-12 beperken tot workflow (dezelfde commando's bereikbaar in ≤ n klikken), niet tot pixelposities.

**Schatting "~95 %" (mijn oordeel, niet gemeten):**
- Functioneel ≈ 90–95 % haalbaar.
- Strikt 95 % alleen als DWG/Parasolid, Toolbox-inhoud en signing expliciet worden uitgesloten of afgekocht.
- 60–80 werkdagen vind ik optimistisch. P1 "exacte geometrie overal" (F47 topologische naamgeving, F51, F175) is het onzekerste deel. Reken eerder op 80–110 dagen.
- Mijn strikte herberekening: rij 30 ("exacte B-rep") naar deels vanwege F175. Dan 46,0/62 = **74,2 %** (QA 75,0 %). De overige 21 rijen met verouderde bestandsnamen houd ik op "aanwezig": hun n/n-tellingen kloppen met de 0.5.11-logs (0 afwijkingen in mijn vergelijking).

## 6. Nieuwe bevindingen

| ID | Ernst | Bevinding | Bewijs | Fix |
|---|---|---|---|---|
| RISK-01 | Major | De drempel uit NAAR-100 P0-2, max(0,5 mm³; 0,1 %), geeft vals alarm: de mesh-fout op een correcte fillet is al ≈ 0,8 mm³. Bij grote gebogen delen schaalt een vaste drempel ook slecht. | `qa-t3diag.log` (mesh −0,794 / −0,845); T1 97,61 vs 96,80 | Tesselatie-bewuste drempel per feature (§4.3 punt 2) |
| RISK-02 | Major | De volume-mismatch hangt aan de laatste feature van het body, alleen als waarschuwing, zonder integratietest | `brepRefine.ts:71-79, 77, 89-90` | Kruiscontrole per feature, e2e-test, vlag op export |
| RISK-03 | Minor (bewijs) | 28 pariteitsrijen citeren niet-bestaande logs (regression.log, regression-rerun.log, qa-strict-tests.log, qa-brep-tests.log); de tellingen kloppen wel. Rij 56 noemt 0.5.10-data. | `R/parity.json` rijen 1, 2, 5, 8–10, 12–15, 18, 19, 21, 23–26, 32–34, 36, 38, 40, 43, 45, 47, 49, 50; rij 56 | `parity_0511.py`: logpaden laten valideren en falen bij een ontbrekend bestand |
| RISK-04 | Minor (bewijs) | `regression-brep-part1.log` heeft geen DONE-regel. De "combined" logs (brep 14/14, release 98/98) zijn met de hand samengevoegd. Box-logs hebben geen commitkop. | `R/logs/regression-brep*.log`, `regression-release.log` | Ruwe logs van de runner met kop gebruiken, niet samenvoegen |
| RISK-05 | Minor (dataverlies) | AutoRecover-kopieën van 0.5.10 (`<userData>/backup/<naam>.autorecover.kcad`) worden in 0.5.11 niet getoond. De andere map én de vereiste `~[0-9a-f]{16}`-sleutel sluiten ze uit, terwijl `:28-29` het tegendeel suggereert. De bestanden blijven wel staan. | `electron/recover.cjs:27-29`; 0.5.10 `electron/main.cjs` RECOVER_SUFFIX en de map `backup` | Eenmalige migratie, of oude kopieën tonen als "(oude build)" |
| RISK-06 | Major (juridisch signaal) | "Repo publiek" als oplossing voor quotum en signing zou docs/26, docs/06:3 en 15 SW-docs publiceren. P2-12 (4 px) en R0 (SW-licentie, EULA **niet geverifieerd**) vergroten het look-alike-risico. | `docs/26-zelfcontrole-1op1.md`, `docs/06:3`, NAAR-100 P0-1/rij 60/P2-12/R0 | Eerst een opgeschoonde publieke repo zonder interne docs en met geschoonde geschiedenis, of een betaald certificaat. Juridisch laten toetsen. |
| RISK-07 | Major | CI draait alleen op ubuntu-24.04; er is geen Windows-job, terwijl het product een Windows-installer is | `.github/workflows/ci.yml:13-182` | Een windows-latest-job: packaged smoke, signing-check, desktop-tests |
| RISK-08 | Major (QA-proces) | De extra QA-tests zijn grotendeels log-only: qaBrep, qaDiag en qaT3diag hebben 0 `expect`, dus "14/14" is geen bewijs. B-T3 kiest nog steeds de verkeerde rand. | `R/tools/qa-src/qaBrep.test.ts:56-68`; `rg -c expect` (alleen qaStrict: 20) | Asserties toevoegen, B-T3 de rand op positie laten kiezen, log-only tests als "diag" labelen |
| RISK-09 | Major | Ellips- en spline-bodies staan als "exact" terwijl ze polygonaal zijn. Geen waarschuwing, en STEP is gefacetteerd. | `brep.ts:4, 68-76`; geen melding gevonden met rg | Label "benaderd" in What's Wrong en Mass Properties, of echte BSpline/ellips-edges in OCCT |
| RISK-10 | Minor | Herkomst is alleen te controleren via het zip-commentaar; de lokale HEAD is een stand-in (dcd49df) | `git log` app-0.5.11; zip-commentaar | In `provenance.txt`: commit, zip-sha256 en de methode van de byte-vergelijking |

## 7. Status van mijn 10 GO-voorwaarden (0.5.10: 8 ✅ / 1 ◐ / 1 ❌ → 0.5.11: **8 ✅ / 2 ◐ / 0 ❌**)

| # | Voorwaarde | 0.5.11 | Bewijs |
|---|---|---|---|
| 1 | Atomische save met fsync | ✅ | `electron/main.cjs:127-134` |
| 2 | .bak-rotatie | ✅ | `main.cjs:146-154` (.bak en .bak2, met een waarschuwing als het mislukt) |
| 3 | Alleen bekende handles | ✅ | `main.cjs:312` |
| 4 | CSP en app:// | ✅ | `main.cjs:55, 64, 360-373` |
| 5 | Geen fs in preload | ✅ | `rg fs electron/preload.cjs`: geen treffers |
| 6 | Validatie en limieten | ✅ | `persistence.ts:34, 36`; `slices/document.ts:83` |
| 7 | Waarschuwing bij niet-opgeslagen werk | ✅ (gat gedicht) | `MenuBar.tsx:93` withUnsavedCheck; recovered doc is nu dirty (`document.ts:75-83`) |
| 8 | Rebuild-budget | ✅ | `rebuild.ts:853` 45 000 ms; B-rep time-out → mesh (`brepRefine.ts:149`) |
| 9 | e2e/CI aantoonbaar groen | ◐ (was ❌) | Box op de geverifieerde db0d4b2-inhoud: mesh 98/98, release 98/98 (samengevoegd), brep 14/14 (samengevoegd, part1 zonder DONE). Actions op HEAD: geen run. Windows: andere commits. |
| 10 | Merk | ◐ | Zie §8 |

## 8. Merkpunten

- **SW-Density: opgelost.** Migratie in `persistence.ts:139`, getest in `legacyNames.test.ts:11`.
- **Weldments → Frames: opgelost in zichtbare tekst.** `Ribbon.tsx:47, 476`; `MenuBar.tsx:381`; `FeatureTreeBody.tsx:374`. Interne ids 'weldment' zijn niet zichtbaar, dus OK. Generieke termen (Cut-List, Weld Bead, Structural Member) zijn OK.
- **Sustainability → "Additional Materials": opgelost.** `materials.ts:124, 140`; alleen de interne constante SUSTAINABILITY_LIBRARY blijft.
- **Disclaimer en trademark-check:** `legal.ts:3`; `logs/trademark-check.log` "total 0" (dry run).
- **Options (F112):** 334/379 sleutels zonder werking, eerlijk grijs. Wel een nagebootste SW-structuur (signaal, zie §5).
- **docs/06:** `:26-30, 35-56` beleid "geen 1:1 iconen" is goed. Maar `:3` legt de opdracht "exact uitzien als SOLIDWORKS" vast. Intern prima, gepubliceerd belastend.
- **docs/26 (pixelpass):** gevolgd, nu gemarkeerd "Intern werkdocument, niet voor publicatie" (F163). Dat label beschermt niets zodra de repo publiek wordt. Advies: uit de repo halen (naar een privé-map, gitignored zoals referentie-video). Daarom blijft #10 op ◐.

## 9. Zelfreview

- **Geverifieerd met bestand:regel of logregel:** herkomst (zip-commentaar plus byte-vergelijking), F140-afleiding, volumecheck, AutoRecover, CI-workflow, GO-referenties, merkteksten, parity- en findings-tellingen.
- **Niet geverifieerd:**
  - een herhaling op 0.5.10;
  - per-testnamen in vitest (alleen de telling);
  - branch protection en verplichte checks;
  - de werkelijke statusbalk "Faceted n/m" (niet gezien);
  - de SW-EULA;
  - de git-geschiedenis van db0d4b2;
  - het juridisch oordeel (alleen signalen: SAS C-406/10, BSA C-393/09, WER 6:162; geen advies).
- **Mogelijke zwakte:**
  - De 0,8 mm³ mesh-fout komt uit één model (T3/T1). De schaal op andere modellen is niet gemeten.
  - "Geen e2e voor het mismatchpad" baseer ik op rg in `e2e/`. Een indirecte dekking kan ik niet volledig uitsluiten.
- Geen bronwijzigingen, geen commits, niets gebouwd, niemand gecontacteerd. Alleen dit bestand geschreven.
