# Teamoordeel Riki (risico/robuustheid): Phlippo CAD 0.5.11

*3 november 2026 (Europe/Brussels). Alleen statische controle: geen build, geen npm install, geen e2e. Bronnen: `QA-rapport-0.5.11.md`, `NAAR-100.md`, `findings.json`, `parity.json`, `logs/`, `tools/qa-src/` en de broncode in `app-0.5.11/`. Wat ik niet zelf kon nagaan, staat er als **niet geverifieerd**.*

**HEAD.** In de opdracht staat db0d4b2. `app-0.5.11` is echter een git-archive met een lokale vervangcommit `dcd49df` (`logs/git-standin.txt`). `git cat-file -t db0d4b2` geeft "not a valid object". Dat de code bij db0d4b2 hoort, blijkt dus alleen uit de eigen verklaring in `provenance.txt` (HEAD db0d4b27…, 14 commits sinds a4b1e92). Ik heb het niet met een hash kunnen controleren (zie RIKI-01).

**`git status --porcelain`.** Vóór mijn controle: `?? src/qaext/`. Die map is QA-restmateriaal (bestanden van 3 nov. 10:17), niet van mij. Na mijn controle: idem. Ik heb alleen dit bestand geschreven.

---

## 1. Score: **6/10**

Ik geef dezelfde score als QA, maar om een andere reden.

Wat wel klopt:
- Op de box zijn alle drie de passes groen: mesh 98/98 met 0 skips, B-rep 14/14, release 98/98 met 1 skip binnen budget.
- F139 is echt opgelost.
- De mate-status maakt nu onderscheid tussen "conflict" en "niet geconvergeerd".
- De trademark-check vangt Weldments nu wel.

Wat de score drukt:
- Er is nergens groen bewijs dat ondubbelzinnig bij HEAD hoort. De vervangcommit is niet te koppelen aan db0d4b2 en de B-rep-pass is na de box-reset uit losse stukken samengesteld.
- Het label "Exact" is onwaar voor ellips- en splineprofielen.
- Het vangnet dat geometrie controleert (F172) is grover dan de fouten die het moet vangen.

## 2. GO/NO-GO

| Doel | Oordeel | Reden |
|---|---|---|
| **Klaar (SOLIDWORKS-gelijk)** | **NO-GO** | Strikte pariteit 75,0 %, naar mijn eigen lezing 71,8 % (§5). Er is geen SW-referentieset (R0), dus 17 rijen kunnen niet gemeten worden. Exactheid ontbreekt nog op veel plekken (F51, F121, F175). |
| **Publiceren** | **NO-GO** | Er is geen groene Actions-run op HEAD (F176, F31). Het bewijs op de box is niet hash-gekoppeld (RIKI-01) en deels gereconstrueerd (RIKI-02). De installer is ongesigneerd (`win/signature-0.5.11.txt`: NotSigned; F49, F117). Desktop-installed bevat alleen "19/19" (F97). |
| **Eigen gebruik** | **GO** (concept- en hobbywerk) | De standaardkernel is B-rep. T1–T3 zijn exact op de B-rep-kernel (`logs/qa-ext-tests.log:59-67`, `logs/qa-t3diag.log`). Facetfeatures krijgen een waarschuwing (`rebuild.ts:3314`). Voorwaarde: vertrouw de massa van ellips- en splinebodies en van facetfeatures niet als exact (RIKI-04), en maak back-ups. |

## 3. Top 3

1. **Er is geen verifieerbaar groen bewijs op de release-commit: F176, F31, F147 (nog niet bewezen), RIKI-01 en RIKI-02.** Het CI-ontwerp is nu goed, maar het heeft op HEAD nooit gedraaid. Het box-bewijs hangt aan een archief zonder hash. Bovendien bestaat het uit 7 regels zonder runnerkop of DONE-regel, plus DONE-regels die QA zelf heeft samengevoegd.
2. **"Exact" betekent niet overal exact: F175, F172 en RIKI-04.** Een ellips of spline wordt opgebouwd uit 96 rechte segmenten (`occt/brep.ts:4`, `:68-76`). Daardoor heeft de body toch een B-rep-vorm. Hij krijgt dan het label "Exact surfaces (B-rep)" (`FeatureTreeBody.tsx:354`) en geen Faceted-waarschuwing, want die komt alleen bij `!exactOf(b)` (`rebuild.ts:3314`). De volumecontrole tolereert 0,5 % (`volumeCheck.ts:8`). Dat is bij T3 ≈ 152 mm³, meer dan een hele fillet van 60 mm³. Een stille afwijking komt dus nergens aan het licht.
3. **De pariteit en NAAR-100 zijn minder hard dan ze lijken: RIKI-03, RIKI-06 en RIKI-07.** 28 van de 62 pariteitsrijen verwijzen naar logs die niet in `report-0.5.11/logs` staan. De 95 % hangt volledig af van R0, waar geen eigenaar of licentie voor is. Zonder R0 ligt het plafond op 83,1 %. De optelling van de werkdagen in het plan komt hoger uit dan het genoemde totaal.

## 4. Correcties op de ernst, met bewijs

### 4.1 Klopt "0 Kritiek"?

**Ja, voor zover de bekende defecten reiken. Ik ga akkoord.** Een open bevinding die stil verkeerde geometrie geeft met een fout van procentorde bestaat in 0.5.11 niet meer:
- F139 is opgelost (§4.3).
- F140 en F167 waren meetfouten (§4.2).

De zwaarste resterende stille afwijking is F175. Voor een ellips van 40×20 met 96 segmenten bij gelijkmatige parameterbemonstering reken ik −0,071 % volume uit. Dit is een analytische schatting: de verdeling van de monsters in `sampleEntity` heb ik **niet geverifieerd** en voor splines heb ik niets gemeten. Daarmee is F175 Major, geen Kritiek.

Twee kanttekeningen:
- **De QA-zin "eerste versie zonder bekende stille geometriefout" (§1) is te sterk.** F175 is bekend, stil en geometrisch: een body heet exact terwijl hij polygonaal is. Beter is: "zonder bekende stille geometriefout boven 0,1 %".
- **"0 Kritiek" rust op één run per pass** (zie F145, RIKI-02). Dat er geen Kritieke fouten in de testpaden zitten, is aannemelijk maar niet herhaald aangetoond.

### 4.2 Is F140 terecht ingetrokken? **Ja. Ik trek mijn eigen 0.5.10-steun voor Kritiek in.**

**Wat de 0.5.10-test deed** (`report-0.5.10/tools/qa-src/qaBrep.test.ts:57-69`):
- Een rechthoek van 80×40 op het bovenvlak, 10 geëxtrudeerd. De body loopt over x 0..80, y 0..10, z 0..−40.
- De rand werd gekozen met `filter(straight && |centroid.y−10|<1e-6).reduce(b.length > a.length ? b : a)`. Er zijn twee randen van 80 mm, bij z=0 en bij z=−40. Bij gelijke lengte houdt `reduce` de **eerste**. Welke rand dat wordt, hangt af van de volgorde waarin de kernel de randen opsomt.
- Daarna wordt een sleuf vóór de fillet ingevoegd: x 35..45, z −25..−45, door het hele materiaal. Die sleuf knipt alleen de rand bij z=−40 in 2×35 mm. De rand bij z=0 blijft heel.
- De verwachte waarde was `30500 − CORNER·70`. De test ging er dus van uit dat de rand bij **z=−40** werd gekozen.

**Analytisch**, met CORNER(R=2) = R²(1−π/4) = 4(1−π/4) = 4−π = 0,8584073 mm³/mm (zelf uitgerekend):

| Interpretatie | Verwacht volume (mm³) |
|---|---|
| Fillet op rand z=0 (80 mm, heel) | 30500 − 80·(4−π) = **30431,327412** |
| Fillet op rand z=−40 (2×35 mm) | 30500 − 70·(4−π) = **30439,911486** |
| Op z=−40, maar één helft | 30469,955743 |

**Wat er werkelijk gemeten werd:**
- In 0.5.10 gaf B-rep v = 30431,327412287184 (`report-0.5.10/logs/qa-brep-tests.log:3`). Dat wijkt 0,0 af van de z=0-waarde (berekend met dubbele precisie). Het "tekort" van 8,584 = 10·CORNER is precies het verschil in randlengte, 80 − 70. Dat was geen half overgeslagen rand. **Die signatuur heb ik in 0.5.10 verkeerd gelezen.**
- In 0.5.11 kiest de diagnose de rand expliciet op positie (`logs/qa-t3diag.log`, 8/8):
  - Bij B-rep is `firstPickZ = 0`. Dat bevestigt de tie-break.
  - Met de rand bij z=0 is v = 30431,327 (afwijking 0).
  - Met de rand bij z=−40 is v = 30439,911 (afwijking 0), zowel bij een gewone als bij een tweezijdige sleuf. `errors {}`.
  - De mesh-kernel kiest z=−40 als eerste (dus een andere opsommingsvolgorde) en zit ≈ 0,8 mm³ onder de analytische waarde. Dat ligt binnen de facettolerantie.
- **De B-rep-kernel is dus exact correct voor de rand die werkelijk gekozen werd.**

**Overdraagbaarheid naar 0.5.10.** Ik vergeleek 0.5.10 met 0.5.11 met `diff --strip-trailing-cr`:
- `src/core/features/edgesets.ts` en `solid.ts` zijn identiek.
- `occt/brep.ts` en `brepKernel.ts` verschillen alleen door een toegevoegde `sphere()` (`brep.ts:357-362`).
- De randopsomming is dus niet veranderd.

De diagnose zelf kon niet op 0.5.10 draaien, omdat vite ontbrak (`logs/qa-t3diag-on-0.5.10.log`). Dat er op 0.5.10 tijdens runtime niets aan de hand was, is daarom **niet geverifieerd**. De numerieke overeenkomst tot op 1e-9 met de z=0-interpretatie laat echter geen redelijke twijfel. F167 is dezelfde meetfout en ook terecht ingetrokken.

**Les.** De repo-test kiest nu op positie (`src/qa/qaModels.ts:59`: kleinste z) en eist een B-rep-tolerantie van 0,01 (`src/qa/qaBrep.test.ts:68`). Goed zo. Elke QA-test moet voortaan in een assert vastleggen welke rand gekozen is (RIKI-09).

### 4.3 Mijn eerdere verhogingen uit 0.5.10

| ID | Mijn 0.5.10-oordeel | Status in 0.5.11 | Bewijs |
|---|---|---|---|
| **F139** (Kritiek) | Mesh-fillet op de gatrand gaf een volume met het verkeerde teken | **Opgelost, akkoord** | `logs/qa-ext-tests.log:6-7,11-12`: verlies bij Ø35 = 97,61 (analytisch 96,80, +0,8 %) en bij Ø50 = 138,46 (137,25, +0,9 %), `filletApplied:true`, `errors {}`. B-rep exact (`:59`). De oplossing zit in `rebuild.ts` ("cut owns edge"). |
| **F145** (Major) | Niet-deterministische regressie (features/Sweep) | **Deels, niet "Opgelost"** | De oorzaak is aangepakt: wachten op toestand in plaats van vaste tijden (`docs/28-qa-0.5.10.md:171-176`, `TASKS.md:826`). Het bewijs is één groene run per pass: mesh features 163 s (`regression-mesh.log:3`), B-rep 352 s (`regression-brep-part1.log:1`, zonder kop, zie RIKI-02), plus de release-shard. Dat is 3 van 3 over verschillende kernels, maar er zijn geen herhalingen. In 0.5.10 faalde dezelfde suite af en toe. Sluiten pas na N≥10 herhaalde runs zonder fouten. |

### 4.4 F147–F152 (mijn nummering uit 0.5.10)

| Mijn ID | Onderwerp | Status in 0.5.11 | Bewijs |
|---|---|---|---|
| F147 | Een bash `-e`-keten verborg passes | **Deels, akkoord.** Het ontwerp is opgelost, maar nooit gedraaid op HEAD. | `ci.yml` heeft nu aparte jobs: checks (`:14-45`), desktop (`:48-86`) en regressie als matrix met `fail-fast: false` (`:97-98`). Elke job draait één `run-regression.mjs` (`:158`), met `continue-on-error` en een gate per job (`:178-182`). |
| F148 (= QA F149) | Claims zonder platform | **Deels, akkoord** | Logkoppen vermelden nu commit en platform (`run-regression.mjs:48-52`, volgens QA). Resterende uitzondering volgens QA: "checks, desktop groen" in `win/linux/README.md` zonder ruw log. Dat bestand heb ik niet zelf heropend: **niet geverifieerd**. |
| F150 | rename-trademarks was blind voor Weldments | **Opgelost** | `tools/rename-trademarks.cjs:26-31` vervangt Weldment(s) → Frame(s). Zichtbare labels zijn "Frame" (`Ribbon.tsx:476`) en "Frames ▸ Frame" (`MenuBar.tsx:381`). `logs/ci-checks.log`: "total 0". De resterende 39 treffers zijn identifiers en commentaar (zoals `evaluateDialogs2.tsx:65`) en staan bewust in de uitzondering `PROSE_ONLY` (`:31`). |
| F151 | Self-test draait ongepackaged | **Deels, akkoord** | Gedekt door NAAR-100 P2-13. Geen nieuw bewijs. |
| F152 | Geen convergentiesignaal uit solveMates | **Opgelost, met een rest** | `mateStatus.ts:125-128`: een geschonden mate die na een nieuwe solve met 128 iteraties wel klopt, gaat naar `unconverged`. `StatusBar.tsx:111` toont dan "Not Converged (x mm)". De rest staat in RIKI-10. |

### 4.5 Overige correcties

| ID | QA | Riki | Reden |
|---|---|---|---|
| F175 | Major | Major, plus pariteitsrijen 30 en 49 naar "deels" | De body heet exact (`FeatureTreeBody.tsx:354`) terwijl het profiel uit segmenten bestaat (`occt/brep.ts:68-76`). De STEP-export bevat dan polylijnen in plaats van ELLIPSE of B-spline. Dat leid ik statisch af uit de code. Een STEP-bestand heb ik **niet geverifieerd**. |
| F172 | Major | Major, akkoord | `volumeCheck.ts:8`: `VOLUME_MISMATCH = 0.005`. Bij T3 is 0,5 % ≈ 152 mm³, terwijl de totale fillet 60 mm³ is. Het vangnet had F140, als die echt was geweest, niet gevangen. |
| F176 | Major | Major, maar blokkerend voor publiceren | §2 |
| F49 | Major | Major, akkoord | `win/signature-0.5.11.txt`: NotSigned (volgens QA §3) |

## 5. NAAR-100 en de pariteit

### 5.1 Pariteit zelf herberekend

**Methode.** Bron is `parity.json`, met 62 rijen. Weging: aanwezig = 1, deels = 0,5, ontbreekt of kapot = 0. Uitkomst = som / 62.

- **QA-lezing:** 35 aanwezig, 23 deels, 4 ontbreekt, 0 kapot. Dat geeft (35 + 11,5) / 62 = 46,5 / 62 = **75,0 %**. Het QA-cijfer is daarmee rekenkundig bevestigd.
- **Strikte Riki-lezing:**

| Rij | QA | Riki | Waarom |
|---|---|---|---|
| 11 | aanwezig | deels | Alleen de constante fillet is kwantitatief bewezen (T1–T3). Voor variabel, face fillet en full round is er alleen het functionele e2e-script `filletopts`, zonder volume. |
| 30 | aanwezig | deels | F175 (ellips/spline als segmenten) en F51 (plastics mesh) |
| 49 | aanwezig | deels | Een STEP-bestand met een ellips of spline is niet exact (F175) |
| 62 | deels | ontbreekt | Er is geen groene Actions-run op HEAD. De eerdere runs hadden rode shards (F31-ev). |

  Uitkomst: 32 aanwezig, 25 deels, 5 ontbreekt → (32 + 12,5) / 62 = 44,5 / 62 = **71,8 %**.
- **Voorbehoud bij "aanwezig":** 28 rijen steunen op logs die niet in deze map staan (RIKI-03).

### 5.2 Oordeel over het plan

**Goed aan het plan:**
- Elk punt heeft een meetbare acceptatietest en bestand:regel.
- De blokkades door licenties en de wet zijn eerlijk benoemd: DWG/Parasolid, signing, iconen, Toolbox.
- R0 staat terecht als eerste actie.
- P0-2 eist expliciet dat een rand van 10 mm × R2 (8,58 mm³) gevangen wordt. Dat is precies de les van F140 en F172.

**Wat ontbreekt:**
1. **Onafhankelijke verificatie tegen echte SOLIDWORKS-referenties (R0).** Er is geen eigenaar, geen licentie, geen datum en geen budget voor (NAAR-100.md:36-38: "vergt een SW-licentie of SW-gebruiker"). Toch telt de 95 % op 15 van de 17 referentierijen als "aanwezig". **Zonder R0 is het plafond 83,1 %.** Zo heb ik dat berekend:
   - De 45 rijen zonder referentie zijn allemaal aanwezig, behalve rijen 51 en 59 (deels) en 60 (0).
   - De 17 referentierijen blijven maximaal "deels".
   - (42 + 1 + 8,5) / 62 = 51,5 / 62 = **83,1 %**.

   Het plan moet dit tweede plafond noemen (RIKI-07).
2. **CI-bewijs.** P0-1 wil `gh run view`, maar zegt niet wie dat onafhankelijk controleert. QA leunt nu op de eigen verklaring in `provenance.txt` en draait op een archief. Nodig zijn een run-ID plus het downloaden van de artefacten, met een hashvergelijking tussen archief en commit (RIKI-01). Verder accepteert P0-1 "brep 12/12", terwijl op de box 14 scripts draaiden (RIKI-05).
3. **Herhaalbaarheid.** Er is geen eis van N herhaalde runs (F145, `rebuildworker`, rij 56 met "1× TimeoutError"). Voorstel: elk timinggevoelig script 10× per kernel, zonder fouten.
4. **Testen van de tests zelf.** Er is geen mutatie- of fouttest: bouw opzettelijk een fout in, bijvoorbeeld een overgeslagen randstuk of een verkeerd teken, en toon aan dat de gate rood wordt. Er is ook geen eis dat elke QA-test de gekozen rand of het gekozen vlak vastlegt (de F140-les).
5. **Compatibiliteit van bestanden.** `.kcad`-bestanden uit 0.3–0.5.x moeten in de nieuwe versie openen met hetzelfde volume. Dat staat niet in het plan. Het is voor eigen gebruik het grootste risico op dataverlies.
6. **Eerlijkheid van de rubric.**
   - 100 % op 62 zelfgekozen rijen is iets anders dan "SolidWorks-gelijk". Het plan moet die reikwijdte noemen.
   - Signing telt dubbel: rij 59 is alleen "deels" wegens "ongesigneerd" en rij 60 is signing zelf (RIKI-08).
   - Pariteitsbewijs moet bij elke release ververst worden (RIKI-03).
7. **Inschatting.** Zelf opgeteld uit de tabellen van het plan:

| Onderdeel | Optelling | Genoemd in het plan |
|---|---|---|
| P0 | 3,5 d | 4–6 d |
| R0 | 3 d | 3 d |
| P1 | 30–35 d | 25–35 d |
| P2 | **40,5–42,5 d** | ≈ 25–30 d |
| P3 | **5 d** | 2–3 d |
| **Totaal** | **≈ 82–89 werkdagen** | 60–80 |

   Het plan onderschat zichzelf dus met 10–30 % (RIKI-06).

**Is "≈ 95 % haalbaar, 100 % niet" terecht?**
- "100 % niet" is terecht. Rij 60 en rij 51 (DWG/Parasolid) zijn zonder geld of OSS-status onhaalbaar, rij 54 (pixelgelijk) is juridisch uitgesloten, en de Toolbox-inhoud is SW-eigendom. Dat staat los van de techniek.
- "≈ 95 %" klopt rekenkundig: (57 + 2) / 62 = 95,2 %. Die waarde geldt **alleen als R0 er komt** en de 82–89 werkdagen worden gehaald. Zonder R0 is het hooguit 83 %.
- Mijn eerlijke formulering: **"95 % is het plafond mét SW-referentieset; zonder referentieset ligt het plafond op 83 %. Echte 100 % is niet haalbaar zonder betaalde of juridisch onmogelijke stappen."**

## 6. Nieuwe bevindingen (RIKI-nummers)

| ID | Ernst | Bevinding | Bewijs | Oplossing |
|---|---|---|---|---|
| **RIKI-01** | Major | De beoordeelde code is niet verifieerbaar gekoppeld aan db0d4b2. Het is een archief met vervangcommit dcd49df. Logs zeggen "commit unknown". De koppeling bestaat alleen als verklaring in `provenance.txt`, zonder archiefhash. | `git -C app-0.5.11 rev-parse HEAD` = dcd49df; `git cat-file -t db0d4b2` = "not a valid object"; `logs/git-standin.txt` | Lever een `git bundle` of `.git` mee, of een SHA-256 van `git archive db0d4b2` die QA controleert. Laat logkoppen de echte commit noemen. |
| **RIKI-02** | Major | Het bewijs voor B-rep 14/14 is deels gereconstrueerd. `regression-brep-part1.log` bevat 7 scriptregels zonder runnerkop, DONE-regel of exitcode (box-reset). Ook de totale DONE-regels in `regression-brep.log` en `regression-release.log` zijn door QA samengesteld ("combined"). De drie release-shards zijn wel ruwe, volledige output. | `logs/regression-brep-part1.log:1-7`; `regression-brep.log:1` "# gecombineerd" en de laatste regel; `regression-release.log` laatste regel "(combined)" | De B-rep-pass in één keer opnieuw draaien met ruwe kop en DONE-regel. Samengestelde regels altijd markeren als QA-tekst en niet als runner-output. |
| **RIKI-03** | Major | 28 van de 62 pariteitsrijen citeren logs die niet in `report-0.5.11/logs` staan (`regression.log`, `regression-rerun.log`, `qa-strict-tests.log`, `qa-brep-tests.log`), dus bewijs uit 0.5.10. Rij 56 noemt nog "worker-pass 5/6 … TimeoutError" uit 0.5.10. Ook `prefs-unused.txt` en `regression-worker.log` ontbreken. | `parity.json` rijen 1, 2, 5, 8, 9, 10, 12, 13, 14, 15, 18, 19, 21, 23, 24, 25, 26, 32, 33, 34, 36, 38, 40, 43, 45, 47, 49, 50 | Bij elke release het pariteitsbewijs verversen. Een script laten controleren dat elk geciteerd log bestaat en de release-commit noemt. |
| **RIKI-04** | Major (gevolg van F175) | Bodies met een ellips- of splineprofiel krijgen het label "Exact surfaces (B-rep)" en geen Faceted-waarschuwing. De waarschuwing verschijnt alleen als er geen B-rep-vorm is, maar het segmentenprofiel levert juist wel een OCCT-solid op. Mass Properties toont dus een benadering als exact. Mijn schatting voor een ellips met 96 segmenten is −0,071 % (statisch, **runtime niet gemeten**). | `occt/brep.ts:68-76`; `rebuild.ts:1073` (exactOf), `:3314`; `FeatureTreeBody.tsx:354` | Tot P1-1 klaar is: een vlag `approx` op de body zetten, die de Faceted-statusbalk en een waarschuwing aanstuurt. |
| **RIKI-05** | Minor | De B-rep-matrix in CI draait 12 scripts, zonder `loftface` en `pmsweep`. Op de box waren het er 14. NAAR-100 P0-1 accepteert "brep 12/12". CI dekt dus minder dan het box-bewijs. | `ci.yml:137`; `logs/regression-brep-part2.log:6-7`; `NAAR-100.md:30` | `loftface` en `pmsweep` aan de B-rep-job toevoegen en de acceptatie op 14/14 zetten. |
| **RIKI-06** | Major (plan) | De werkdagen in NAAR-100 zijn onderschat. De posten van P2 tellen op tot 40,5–42,5 d (genoemd ≈ 25–30), die van P3 tot 5 d (genoemd 2–3). Het totaal is ≈ 82–89 d, niet 60–80. | `NAAR-100.md:52-79`, `:88` | De totalen corrigeren of de scope verkleinen. |
| **RIKI-07** | Major (plan) | De 95 % hangt af van R0, waar geen eigenaar, licentie of datum voor is. Zonder R0 is het plafond 83,1 %. Dat staat niet in het plan. | `NAAR-100.md:22`, `:36-38`, `:88`; berekening in §5.2 | Beide plafonds noemen. Een eigenaar en datum voor R0 vastleggen, of het doel bijstellen. |
| **RIKI-08** | Minor | De rubric telt signing dubbel (rij 59 is alleen "deels" wegens "ongesigneerd", rij 60 is signing). Bovendien betekent 100 % op 62 zelfgekozen rijen niet "SolidWorks-gelijk". | `parity.json` rijen 59 en 60 | Rij 59 beperken tot NSIS/portable/associatie. De reikwijdte van de rubric in het rapport vermelden. |
| **RIKI-09** | Major (plan/proces) | Het plan eist geen herhaalbaarheid (N herhaalde runs), geen mutatietests op de gates, geen assert die vastlegt welke rand of welk vlak de test kiest, en geen test op compatibiliteit van `.kcad`-bestanden tussen versies. F140 en F145 laten zien dat precies deze gaten tot verkeerde conclusies leiden. | `NAAR-100.md` (ontbreekt); `report-0.5.10/tools/qa-src/qaBrep.test.ts:57-69` (tie-break) | Vier punten toevoegen aan P0/P3, elk met een meetbare acceptatie. |
| **RIKI-10** | Minor | De niet-convergentie wordt heuristisch bepaald. Na nog een solve met 128 iteraties telt een mate die dan klopt als "unconverged". Een keten die meer iteraties nodig heeft, krijgt nog steeds het label "Over defined" en geldt als conflict. | `mateStatus.ts:126-128`; `AssemblyTreeBody.tsx:87` | Convergentie bepalen met een residu-trend of een stapcriterium in `solveMates` zelf, niet met een vast aantal iteraties. Testen met een keten van 10 of meer. |
| **RIKI-11** | Minor (hygiëne) | QA heeft niet-gecommitte testbestanden in de werkboom achtergelaten (`src/qaext/`: qaBrep, qaDiag, qaStrict, qaT3diag). Dat is niet schadelijk, maar het maakt "repo schoon" (`git diff --exit-code` in CI) lokaal niet reproduceerbaar en het vermengt QA-code met de bron. | `git status --porcelain` → `?? src/qaext/` | QA-hulptests buiten de app-boom houden, of in `report-*/tools/`. |

## 7. Niet geverifieerd

- Dat de code bij db0d4b2 hoort (alleen `provenance.txt`).
- Runtime-gedrag van 0.5.10 met de randkeuze op positie (de run kon niet draaien).
- Het werkelijke volume en de STEP-inhoud van een ellips- of splinebody (alleen statisch geschat).
- Elke Actions-run, Windows-run en desktop-installed-run op HEAD.
- `win/linux/README.md` (claim "checks, desktop groen").
- Herhaalbaarheid van de regressie (één run per pass).
- Kwantitatieve juistheid van variabele fillets, face fillets en full round fillets.

## Mijn eigen correctie

In 0.5.10 noemde ik F140 terecht Kritiek. Ik zag het tekort van 10·CORNER aan als "half overgeslagen", zonder na te gaan welke rand er gekozen was. Dat was een fout in mijn controle. Ook de signatuur had ik eerst moeten verklaren uit de randkeuze.
