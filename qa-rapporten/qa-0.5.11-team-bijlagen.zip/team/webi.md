# Webi — teamreview Phlippo CAD 0.5.11 (HEAD db0d4b2) · UI/frontend/Electron/build · 3-11-2026

**Score: 5,5/10** (QA 6/10, een halve punt lager: pariteit te ruim geteld en geen bewijs op HEAD buiten de box). **Strikte pariteit volgens mij 73,4 %** (45,5/62), niet 75,0 %.
**GO/NO-GO:** klaar (SW-gelijk) **NO-GO** · publiceren **NO-GO** (NotSigned, geen CI/Windows op HEAD) · eigen gebruik **GO onder voorwaarden** (concept/hobby, met back-ups; de Windows-installer op HEAD is niet geverifieerd).

**Top 3**
1. Bewijs op HEAD bestaat alleen op de box. db0d4b2 staat niet in de lokale git; dat is de stand-in dcd49df. Windows-logs komen van 0495219/1fd00e3, Actions van c1fc039/75ceeea, en `multibody` is in 2 van 2 runs rood (WEBI-01, WEBI-08).
2. Pariteitsrijen 30 ("B-rep op desktop") en 61 ("Unit+e2e+B-rep+worker") zijn opgewaardeerd naar *aanwezig*, maar dat steunt op ongepackagede self-tests en alleen de box. Dat botst met F151/F172/F173/F176 (WEBI-02).
3. Two/Four View rendert nu correct, maar de vensters zijn statische plaatjes die elke 1,5 s volledig opnieuw worden gerenderd en via de CPU teruggelezen (WEBI-03, WEBI-04).

**Ernstcorrecties**
- '0 Kritiek' houdt voor 0.5.11. Ik vond geen stille geometriefout, en recover en hardening zijn in de code in orde. Dat oordeel is wel alleen op de box geverifieerd.
- F157 (mijn F150, zwarte multi-view) is **opgelost**. Zie code en shot.
- F156 (mijn F148, recover-IPC) is **opgelost**. De renderer stuurt geen pad meer, elke handler checkt trusted(), en de map kan alleen via een dialoog worden gekozen.
- F140/F167 "ingetrokken" houdt **voor 0.5.11**: de echte gesplitste rand (z=−40) geeft in B-rep exact 30439,911 (diff 0). **Voor 0.5.10 is de intrekking niet bewezen.** 30431,327 = 30500−80·C past op twee verklaringen: "z=0-rand gekozen" én "70 mm + extra 10 mm" (de F140-hypothese). Het 0.5.10-log noteert geen gekozen rand, de diagnose op 0.5.10 faalde (geen vite), en brep.ts/edgesets.ts zijn sindsdien gewijzigd. Mijn voorstel: status "niet geverifieerd (0.5.10)", niet "QA-fout".
- Mijn oude punten opnieuw nagelopen:
  - F155 (skip telt als groen): opgelost. Het budget staat in de DONE-regel; de enige skip zit in release-shard2 (sheetexport-PDF).
  - F158 (worker-pad): opgelost op de box. De logkop vermeldt `?kernel=brep&rebuild=worker`.
  - F162 (gpu.json): opgelost.
  - F161 (shading): deels.
  - F50 (merknamen): opgelost. uiText.test bewaakt de UI-strings; alleen code-commentaar noemt nog "Weldments".
  - F49/F117 (signing): open, NotSigned.
  - F31 (CI): de CI-config is goed (continue-on-error plus een slotstap die faalt als een stap faalde), maar er is geen run op HEAD.
  - F148/F93 (logs van deze commit?): deels. De box-logs dragen `commit dcd49df`, niet "commit unknown" zoals QA schrijft. De Linux-README telt groene shards van verschillende commits bij elkaar op.

**NAAR-100 (UI/look-and-feel vs SW)**
"~95 % haalbaar, 100 % niet" is terecht, en het plafond klopt rekenkundig: (57+4·0,5)/62 = 95,2 %. De redenen:
- (a) Pixel-identieke iconen, de "SOLIDWORKS"-branding en Toolbox-content zijn auteurs- en merkrechtelijk beschermd. De look kan dus alleen "gelijkend" zijn, nooit identiek.
- (b) Parasolid-gedrag is niet na te bouwen met OCCT: wanneer fillets en shells falen, toleranties, en face-ID's/topologische naamgeving. Er is ook geen Parasolid-writer, en DWG vereist de ODA SDK.
- (c) Er is geen SW-referentieset (R0). Daardoor zijn 17 rijen niet te scoren en kan de 4-px-overlaydiff van P2-12 niet zonder SW-licentie.
- (d) Chromium/WebGL rendert anders dan SW's eigen viewport (RealView/AO). Pixel-gelijk is daarom ook technisch onhaalbaar.
- (e) "100 %" is 100 % van een zelfgekozen matrix van 62 rijen, niet van SW. De 60–80 werkdagen zijn **niet geverifieerd**.

**Nieuwe bevindingen**
- **WEBI-01 (Major, bewijs).** De herkomst van HEAD steunt alleen op provenance.txt: db0d4b2 ontbreekt in de git, die alleen de stand-in dcd49df bevat (09:11, met een echt ogende commitboodschap). Er is geen hash die archief en commit verbindt. desktop-installed-0.5.11.txt bestaat uit 2 regels, zonder commit, platform of datum.
- **WEBI-02 (Major, pariteit).** Rij 30 en rij 61 horen *deels* te zijn: de self-tests draaien met `packaged:false` en er is geen CI op HEAD. Dat geeft 73,4 %.
- **WEBI-03 (Minor, performance).** Elk paneel rendert onvoorwaardelijk elke 1500 ms opnieuw. Elke ronde doet computeBoundingBox op alle meshes, twee keer updateSilhouettes, een synchrone readRenderTargetPixels en een per-pixel-lus in JS op de main thread. Bij Four View gebeurt dat 3×. De impact is niet gemeten.
- **WEBI-04 (Major voor SW-gelijk).** De extra vensters zijn niet interactief (geen eigen roteren/zoomen, geen actief venster). Alleen dubbelklikken draait de hoofdview, en de triad en heads-up-toolbar staan alleen in Trimetric. Dat SW hier vier live viewports heeft, is **niet geverifieerd** (er is geen R0).
- **WEBI-05 (Minor, look).** In Document Properties is het geselecteerde item ("Units") nauwelijks leesbaar. De tabs van de Material-dialoog breken af over twee regels ("Application Data", "Sheet Metal").
- **WEBI-06 (Minor, branding).** De productnaam verschijnt in drie vormen: "PhlippoCAD Design" in de titelbalk, "Welcome - Phlippo CAD" in de dialoog, en "Phlippo CAD" als venstertitel.
- **WEBI-07 (Minor, IP-risico bij publiceren).** De materiaalbibliotheek volgt de naamconventies van SW: suffixen "(SS)/(SN)", "Copy to Custom Materials", "Linear Elastic Isotropic" en dezelfde categorieboom. Of de waarden en de lijst gekopieerd zijn, is **niet geverifieerd**.
- **WEBI-08 (Major, CI).** `multibody` is rood in mesh-1of3 in **beide** Actions-runs, terwijl het op de box groen is. Dat de fix in 772236a werkt, is niet op een runner bewezen. Het script `features` liep tegen de timeout van 900 s aan, tegen 829 s eerder; de marge is dus minder dan 10 %.
- **WEBI-09 (Minor, Electron).** De hardening klopt in de code, maar de fuses (asar-integriteit, onlyLoadAppFromAsar) en de debug-switchweigering zijn nooit getest op een gepackagede exe. De self-tests draaien ongepackaged.

## Bewijs (compact)
- recover: electron/recover.cjs:3-4, :24, :27, :32-38, :79-124 (trusted), :127-134 (alleen dialoog), :41-56 (fsync)
- hardening:
  - main.cjs:185-189 (contextIsolation/sandbox/devTools), :20-23 (debugswitches), :58/:61 (CSP; unsafe-eval alleen voor de OCCT-worker)
  - main.cjs:109-113 (senderFrame), :212-219 (open/navigate/redirect/frame-navigate geweigerd), :409-410 (permissions)
  - main.cjs:41-48/:351 (gpu.json bewaart alleen de keuze)
  - package.json:75-83 (fuses)
- multi-view:
  - ViewPane.tsx:41-42, :78 (hoofdrenderer); glSetup.ts:23 (makeStudioEnvironment), :58-94 (readback)
  - ViewPane.tsx:105 (setInterval 1500), :54 (bbox), :109 (alleen dubbelklik)
  - shots/viewpanes-four(.png, -dark.png): grijs en belicht; shots/viewpanes-nowebgl.png; logs/viewpanes.log "35/35"
- T3:
  - logs/qa-t3diag.log: brep zm40 30439,911 diff 0, firstPickZ 0; mesh firstPickZ −40
  - logs/qa-t3diag-on-0.5.10.log ("failed to load config")
  - report-0.5.10/logs/qa-brep-tests.log:3 (v 30431,327, geen centroid); report-0.5.10/tools/qa-src/qaBrep.test.ts:62
  - `diff` brep.ts/edgesets.ts 0.5.10↔0.5.11 (gewijzigd); src/qa/qaBrep.test.ts:60-68 (T3, tolerantie 0,01)
- herkomst:
  - provenance.txt (db0d4b2); `git log -1` = dcd49df 2026-11-03 09:11 +0100; `git status` ?? src/qaext/
  - app-0.5.11/e2e-out/regression-0.5.11.txt:2 "commit dcd49df", :4 url; e2e-out/…brep-worker-shard1of3.txt:4 `rebuild=worker`
  - QA-rapport:256 ("commit unknown")
- logs:
  - regression-mesh.log:99 "98/98, 0 skipped"; regression-release.log:109 "98/98, 1 skipped"
  - release-shard2.log:32 (de skip); regression-brep.log:19 "14/14 (combined)"
  - build-release.log:50 "854.86 kB"; trademark-check.log "total 0"
- Windows:
  - win/regression-0.5.11-mesh-win32.txt:2 "commit 0495219"; -brep-win32.txt:2 "commit 1fd00e3", :19 "12/12"
  - win/desktop-installed-0.5.11.txt (2 regels); win/signature-0.5.11.txt "NotSigned"
- CI:
  - app-0.5.11/qa-logs/0.5.11/linux/README.md (tabel en "Samen"-alinea)
  - …/41542259973-c1fc039/mesh-1of3 en …/41551048560-75ceeea/mesh-1of3 "32/33 failed: multibody"
  - .github/workflows/ci.yml:11, :45, :86, :99-112, :182
- pariteit:
  - parity.json counts 35/23/4 → 75,0 ✓; rij 30 ev "self-test 8/8"
  - logs/self-test-{nogpu,softgl}.json `packaged: false`; rij 61 ev "box-only"
- look:
  - shots/home-brep.png en after-nav.png (titel en welkom identiek), e23-options.png ("Units"), e24-material.png (tabs, "(SS)/(SN)")
  - src/core/document/materials.ts:66; src/app/materialDialog.tsx:154-155; src/app/uiText.test.ts:12; src/app/legal.ts:3
- niet geverifieerd:
  - of het archief byte-gelijk is aan db0d4b2
  - de installer op HEAD
  - het SW-gedrag zelf (geen R0)
  - de herkomst van de materiaalwaarden
  - de CPU-impact van de paneelpolling
  - de schatting van 60–80 dagen
