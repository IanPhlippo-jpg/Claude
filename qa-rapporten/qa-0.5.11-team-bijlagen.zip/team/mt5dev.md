# Phlippo CAD 0.5.11 — strenge review (MT5-developer)

*3 november 2026 (Europe/Brussels). Bron: QA-rapport-0.5.11.md, NAAR-100.md, findings.json, parity.json, code in `app-0.5.11/`. Read-only. Geen builds of tests gedraaid; alleen kleine Python-berekeningen. Regel: **de strengste ernst wint**. Wat ik niet kon bewijzen, staat er als **niet geverifieerd**.*

## 0. HEAD-verificatie

- `app-0.5.11/` is **geen echte clone**. Het is een stand-in-repo met één commit: `dcd49df` (2026-11-03 09:11 +0100, auteur "QA"). Object `db0d4b2` bestaat er niet in en er zijn geen tags. `git status` toont één ongetrackte map: `?? src/qaext/` (QA-tests).
- `phlippo-0.5.11-src.zip` heeft als zip-commentaar `db0d4b27d857c42b898bcec68c65240b3fe855e9` (het commit-id dat `git archive` daar zet). Ik heb CRC's vergeleken: 688 getrackte bestanden tegen 688 zip-entries, 0 ontbrekend, 0 extra, 0 verschillend.
- **Conclusie:** de werkboom is inhoudelijk gelijk aan het archief van `db0d4b2`. Dat archief komt "from laptop Claude" (provenance.txt). De geschiedenis is **niet geverifieerd**: de 14 commits sinds `a4b1e92` en de datum 02:46 +0100. `package.json` meldt 0.5.11.

## 1. Score: **5/10** (QA: 6/10)

| Criterium | QA | MT5D | Waarom lager |
|---|---|---|---|
| Correcte geometrie | 7 | 6 | T1–T3 kloppen (zie §4). Maar ellipsen en splines zijn polygonaal en dragen toch het label **exact**, zonder waarschuwing (MT5D-09). De kruiscontrole is per ontwerp blind onder 0,5 % (MT5D-11). |
| Functionele pariteit | 7 | 6 | Mijn strenge herberekening is 74,2 % (zie §4.6). |
| Bewijs/claims | 6 | 4 | Geen echte git-clone. De logs van de box hebben geen commitkop. Er is niets groen buiten de box (MT5D-12, F176). |
| Tests | 7 | 6 | Een unit-test legt de blinde vlek vast (volumeCheck.test.ts:9). |
| Release-klaar | 4 | 3 | Ongesigneerd, geen CI op HEAD, self-test `packaged:false`. |

Een 6 vereist dat "0 Kritiek" klopt. Dat klopt niet (§4.1), dus het wordt een **5**.

## 2. GO/NO-GO

| Doel | Oordeel | Reden |
|---|---|---|
| **klaar** | **NO-GO** | Er is ≥ 2 keer Kritiek (§4.1): een stil fout resultaat (F175/MT5D-09) en de blokkade "geen groen bewijs op HEAD buiten de box" (F176/F54). |
| **publiceren** | **NO-GO** | `NotSigned` (win/signature-0.5.11.txt, F49). Geen Actions-run op HEAD. Windows-logs van 0495219/1fd00e3, niet van HEAD. Herkomst van HEAD niet via git te bewijzen. |
| **eigen gebruik** | **GO, voorwaardelijk** | Alleen de desktop-build met B-rep, voor prismatische en ronde geometrie (extrude, revolve, gaten, constante fillets). Daar zijn T1, T2 en T3 exact gelijk aan de theorie. **Niet** vertrouwen op massa of STEP voor ellipsen, splines, wrap, plastics of sheet-metal-flenzen. Houd de `.bak` aan. |

## 3. Top 3

1. **Stil fout resultaat onder het label "exact".**
   - Ellipsen en splines worden in B-rep uit 96 lijnstukken gebouwd (occt/brep.ts:4, :68–75). Het lichaam blijft `exact` en er komt geen waarschuwing.
   - De wrap-patch is polyhedraal, maar het lichaam behoudt zijn exact-status (rebuild.ts:2187–2188).
   - De volume-kruiscontrole ziet het niet: de drempel is 0,5 % (volumeCheck.ts:8), en een unit-test zet die blinde vlek vast (volumeCheck.test.ts:9).
2. **Er is geen bewijs dat buiten de QA-box en op een echte commit stand houdt.**
   - Stand-in-repo zonder `db0d4b2`.
   - `logs/regression-*.log` hebben geen kop met commit of platform. F176 noemt de logkop van de box zelf "commit unknown".
   - De B-rep-run is in twee delen gedraaid, met een box-reset ertussen.
   - Er is geen Actions-run op HEAD.
3. **NAAR-100 rekent zich rijk.**
   - De opgetelde schattingen per item komen op **82–89 werkdagen**, niet op de geclaimde 60–80.
   - De IGES-writer "gratis via OCCT" zit niet in de meegeleverde OCCT-build.
   - Rij 42 (DWG) staat zowel bij "naar aanwezig" als bij "kan niet".
   - Rij 37 staat zowel in het weekplan bij "naar aanwezig" als in de eindstand bij "deels".
   - Topologische naamgeving en Deform/Flex/Freeform exact zijn veel te laag geschat.

## 4. Ernstcorrecties met bewijs

### 4.1 Klopt "0 Kritiek"? **Nee.**

QA's eigen regel (0.5.10, r.587) luidt: "Kritiek = stil fout resultaat of een blokkade voor 'klaar' … strengste ernst wint."

| Bevinding | QA | MT5D | Bewijs |
|---|---|---|---|
| **F175** (ellips/spline als segmenten) | Major | **Kritiek** | brep.ts:68–75 bouwt `sampleEntity(sketch, e, 96)` als lijnstukken. Het lichaam blijft exact. De enige waarschuwing (rebuild.ts:3313–3314) gaat alleen af als een lichaam *van exact naar gefacetteerd* gaat (`!exactOf(b) && exactBefore.has(b)`). Hier gebeurt dat niet, dus er komt **geen** melding. QA §7.3 ("Het programma meldt dat wel eerlijk") klopt dus **niet** voor F175. Mijn berekening voor een ellips 40×20 geëxtrudeerd over 10 mm: exact 6283,185 mm³, polygoon (96 uniforme t-stappen) 6278,700 mm³, verschil **−4,485 mm³ (−0,071 %)**. Dat valt ruim onder de 0,5 %-drempel, en ook het mesh-pad is gesegmenteerd. Dit is een stil fout resultaat. Met een tussenfix (label "Faceted" plus waarschuwing) zakt het naar Major. |
| **F176** (niets groen op HEAD buiten de box) | Major (P0) | **Kritiek** | Dit is per definitie een "blokkade voor klaar": QA geeft het zelf prioriteit P0 en noemt het in §7.1 als risico nr. 1. Major én P0-blokker tegelijk is in strijd met QA's eigen regel. |
| **F54** (CI rood / niet reproduceerbaar) | Kritiek → Major | **Kritiek** (samen met F176) | Groen op de box (mesh 98/98, logs/regression-mesh.log), maar er bestaat geen enkele groene Actions-run. De laatste runs 41542259973 en 41551048560 hadden rode shards, en die van 772236a startte niet (quotum). "Regressie groen reproduceerbaar" is dus buiten de box nog steeds niet aangetoond. |
| F172 (kruiscontrole 0,5 %) | Major | Major | Terecht Major. Zie MT5D-11 voor de test die het vastlegt. |
| F51 (plastics mesh) | Major | Major | Akkoord: hier gaat de waarschuwing (rebuild.ts:3313–3314) wél af. |

**Mijn telling: minstens 2 Kritiek** (F175 en F176+F54), plus mogelijke kandidaten in MT5D-10 en MT5D-13.

### 4.2 Intrekking F140/F167: **terecht, met hoge waarschijnlijkheid**

**Geometrie van T3.** Een plaat 80 × 10 × 40 (wereld x 0..80, y 0..10, z 0..−40). Een sleuf van x 35..45 en diepte z −25..−40 snijdt de achterste bovenrand (z = −40) door. Scherp volume: 32000 − 10·15·10 = **30500 mm³**. Per mm randlengte haalt een fillet R2 CORNER = R²(1−π/4) = **0,858407 mm²** weg.

**Welke rand de 0.5.10-test mat.** Zie `report-0.5.10/tools/qa-src/qaBrep.test.ts:62`:
```
b0.edges.filter((e) => e.straight && Math.abs(e.centroid.y - 10) < 1e-6).reduce((a, b) => (b.length > a.length ? b : a))
```
- Er zijn twee rechte bovenranden van 80 mm. Bij gelijke lengte houdt `reduce` de **eerste**, en welke dat is hangt af van de kernel.
- In B-rep is de eerste de **voorrand z = 0**: 80 mm, niet gesplitst. Mesh vindt eerst z = −40 (logs/qa-t3diag.log: `firstPickZ` brep 0, mesh −40).
- De test logde de gekozen rand niet. qa-brep-tests.log:3 geeft alleen `v 30431.327…`.

**Welke rand het had moeten zijn.** De **achterrand z = −40**, door de sleuf gesplitst in 35 + 35 = 70 mm.

| Rand | Theorie | B-rep 0.5.11 (qa-t3diag.log) | Mesh 0.5.11 |
|---|---|---|---|
| z = −40 (juist), 70 mm | 30500 − 70·0,858407 = **30439,911** | 30439,911, Δ 0, in beide sleufmodi | 30439,067, Δ −0,845 |
| z = 0 (fout gekozen), 80 mm | 30500 − 80·0,858407 = **30431,327** | 30431,327, Δ 0 | 30430,534, Δ −0,794 |

**Over de theorieformule.** 10·(1−π/4)·R² = **8,584 mm³** is precies het verschil tussen 80 en 70 mm randlengte. Het is **geen** extra afgeronde rand van 10 mm.

**Kanttekening (eerlijk).** Mijn hypothese uit 0.5.10 ("stukken van z = −40 plus een extra randje van 10 mm op de bodem van de inkeping") geeft óók 80·CORNER. **Op volume alleen zijn de twee verklaringen niet te onderscheiden**; alleen de randvolgorde onderscheidt ze. Die randvolgorde is van 0.5.10 naar 0.5.11 niet veranderd (`diff --strip-trailing-cr`):
- edgesets.ts: 0 regels;
- solid.ts: 0 regels;
- brep.ts: alleen `sphere()` erbij (+6);
- het B-rep-filletpad in rebuild.ts (~2831–2845: bodyEdges → matchEdges → K.fillet) is ongewijzigd.

QA's herhaling op 0.5.10 zelf faalde (logs/qa-t3diag-on-0.5.10.log: vite ontbreekt). **Het rechtstreekse bewijs op 0.5.10 is dus niet geverifieerd.** De verklaring "andere rand gemeten" is wel de enige die met de ongewijzigde code én de firstPickZ-meting klopt. Daarmee is de intrekking van F140 terecht. F167 is mijn F148 uit 0.5.10 (fix "op de verkeerde laag"); die vervalt mee en is ook terecht ingetrokken. Let op: QA's huidige F148 is een **andere** bevinding (kopie van het Windows-log).

**Is het volume nu correct voor de juiste rand?**
- B-rep: **ja, exact** (Δ 0).
- Mesh: −0,845 mm³. Dat is 1,4 % van het fillet-verlies van 60,09 en 0,003 % van het lichaam. Het lichaam heet "Faceted". Aanvaardbaar.

**Les voor de tests.** Een randtest moet de gekozen rand asserten (bijv. de z van het centroid) en niet alleen het volume. qaT3diag doet dat nu wel.

### 4.3 Nog een stil fout resultaat elders? **Ja.**

- **F175 / MT5D-09.** Ellips en spline (zie hierboven).
- **MT5D-13.** Een wrap-patch op een exact lichaam wordt polyhedraal en behoudt het exact-label (rebuild.ts:2187–2188). Of de UI dan "Faceted" toont, is **niet geverifieerd**. Parity-rij 15 zegt "mesh-terugval, Faceted", maar de code volgt bij een exact lichaam een ander pad.
- **MT5D-10.** Sheet-metal-flens (rebuild.ts:1600–1604). Het exacte pad gaf aantoonbaar te weinig materiaal (comment op 1600–1601). De oorzaak is niet opgelost: alleen een afwijking boven 0,5 % valt terug op mesh. Fouten onder 0,5 % blijven stil en exact. Of zo'n kleinere fout echt voorkomt, is **niet geverifieerd**.
- **Kruiscontrole.** Die vangt geen van deze gevallen: VOLUME_MISMATCH = 0,005 (volumeCheck.ts:8).

### 4.4 Mijn kritieke bevindingen uit 0.5.10 en F147/F148

| Bevinding | QA-status | Mijn oordeel | Bewijs |
|---|---|---|---|
| **F139** (mesh-fillet op gatrand voegt volume toe) | Opgelost | **Akkoord, opgelost** | Herberekend met CORNER·2π(r + kR), k = 0,22337: r = 17,5 → 96,796; r = 25 → 137,248. Mesh 97,61 (+0,84 %) en 138,46 (+0,88 %), nu een verlies in plaats van een toename. B-rep is exact gelijk aan de formule (logs/qa-ext-tests.log). |
| **F111** (gesplitste rand half afgerond) | Opgelost | **Akkoord, opgelost** | T3 op de juiste rand: B-rep 30439,911 = theorie, mesh −0,845 (logs/qa-t3diag.log). |
| **F54** | Kritiek → Major | **Kritiek** | Zie §4.1. |
| **F31** (exitcodes/CI) | Major, deels | **Major, deels: akkoord** | De exitcodes en de DONE-regel werken. Het CI-deel overlapt met F176/F54 en telt daar als Kritiek. |
| **F147** (CI in één bash-stap) | Major, deels | **Akkoord, deels** | ci.yml splitst nu in matrix-jobs met `continue-on-error` en eind-gates (ci.yml:11, :24–42, :65–83, :153–179). Op HEAD is dit niet bewezen, want er is geen run. |
| **F148** (QA-nummering: Windows-log is een kopie) | Major, deels | **Akkoord, deels, met een aanvulling** | run-regression.mjs:48–52 schrijft nu een kop met commit en platform. Maar de logs in dit rapport (`logs/regression-mesh.log`, `-brep*.log`, `-release*.log`) beginnen direct met `smoke: exit=0…`, dus **zonder kop**. QA's eigen bewijsnorm (NAAR-100: "elk groen … met een kop die commit en platform noemt") haalt het eigen rapport niet. |

### 4.5 Overige ernstpunten

- **Rij 11 (Fillet: const, variabel, face, full round) "aanwezig".** Het bewijs in parity.json gaat alleen over constante fillets (T1–T3). Variabel, face en full round bestaan in de code (rebuild.ts:838–864, round2.test.ts), maar een kwantitatieve volumecontrole ervan is **niet geverifieerd**. Ik laat de rij staan, met een voorbehoud.
- **Rij 30 (exact op desktop).** De self-test draaide met `packaged:false`. Dat de geïnstalleerde exe exact rekent, is **niet geverifieerd**.

### 4.6 Strikte pariteit

Ik heb QA's telling nagerekend uit parity.json: 35 aanwezig / 23 deels / 4 ontbreekt = **75,0 %**. Dat klopt.

**Mijn correctie:** rij 49 "STEP AP214 in/uit (exact)" gaat van aanwezig naar **deels**. STEP van een lichaam met een ellips of spline bevat lijnstukken in plaats van `ELLIPSE` of `B_SPLINE_CURVE_WITH_KNOTS` (brep.ts:68–75). NAAR-100 P1-1 erkent dat zelf in zijn acceptatietest.

Resultaat: 34 / 24 / 4, (34 + 12)/62 = **74,2 %**.

## 5. Oordeel over NAAR-100

### 5.1 De optelling klopt niet

Ik heb de schattingen per item uit NAAR-100.md opgeteld.

| Fase | Geclaimd | Som van de items |
|---|---|---|
| P0 | 4–6 d | 3,5 d (+ quotum) |
| R0 | 3 d | 3 d |
| P1 | 25–35 d | **30–35 d** |
| P2 | 25–30 d | **40,5–42,5 d** |
| P3 | 2–3 d | **5 d** |
| **Totaal** | **60–80 d** (NAAR-100.md:13, :88) | **82–89 d** |

Al vóór enige inhoudelijke correctie zit het plan dus 10–30 % te laag. Na mijn correcties per item (5.2) kom ik op ongeveer **110–150 werkdagen**. Dat is een schatting: **niet geverifieerd**.

### 5.2 Inschatting per item

| # | Plan | Oordeel | Onderbouwing |
|---|---|---|---|
| P0-1 groene Actions-run | 0,5 d + quotum | **te optimistisch** (1–3 d) | De laatste runs hadden rode shards (41542259973, 41551048560). Die moeten eerst gerepareerd worden. "Repo publiek maken" is een beslissing (licentie, publicatie), geen taak van een halve dag. Acceptatie "brep 12/12" klopt niet met de 14 scripts op de box. |
| P0-2 kruiscontrole per feature | 1 d | realistisch | Wel volumeCheck.test.ts:9 omdraaien (MT5D-11). |
| P0-3 QA-tests strakker | 0,5 d | realistisch | Let op: het pad `src/qa/qaStrict.test.ts` bestaat, maar de QA-uitbreiding staat ongetrackt in `src/qaext/`. Eerst committen. |
| P0-4 bewijs op HEAD (Windows, desktop) | 1 d | **te optimistisch** (1–2 d) | Er is een Windows-machine nodig plus een installatierun. De logs moeten koppen krijgen (zie F148). |
| P0-5 release buiten de box | 0,5 d | licht optimistisch (1 d) | Hangt af van P0-1. |
| R0 SW-referentiepakket | 3 d | **te optimistisch** (5–8 d) + **blokkerend** | Het gaat om T1–T3, M1–M5 en ongeveer 17 rijmodellen, met Mass Properties, STEP, PDF en screenshots. Er is een SW-licentie of SW-gebruiker nodig; het plan zegt niet wie of wat. Of de SW-EULA vergelijkend gebruik toestaat, is **niet geverifieerd**. Zonder R0 blijven 17 rijen "deels". |
| P1-1 exacte ellips/spline | 3 d | realistisch (3–4 d) | De bindings hebben de API's: `gp_Elips`, `GC_MakeEllipse`, `Geom_BSplineCurve`, `GeomAPI_PointsToBSpline`, `GeomAPI_Interpolate` (replicad-opencascadejs 1.1.0, dist/replicad_single.d.ts). Wel extra werk aan randmatching en fillets op gekromde randen. |
| P1-2 plastics exact | 8–10 d | **te optimistisch** (10–15 d) | Vier complexe features, elk met een eigen gesloten vorm en eigen randgevallen. |
| P1-3 Wrap/Deform/Flex/Freeform + surfaces exact | 6–8 d | **veel te optimistisch** (15–25 d of herdefiniëren) | Exacte Deform/Flex/Freeform hebben geen directe OCCT-API. Dat is vrije-vorm-vervorming van NURBS. |
| P1-4 loft > 2 profielen | 3 d | realistisch voor de profielen, optimistisch voor guides (3–5 d) | `BRepOffsetAPI_ThruSections` en `MakePipeShell` zitten in de bindings. |
| P1-5 topologische naamgeving | 4–5 d | **veel te optimistisch** (10–20 d) | Persistente naamgeving over sweep, loft, pattern en shell is een bekend moeilijk probleem. Het item omvat 4 nieuwe QA-modellen met gesloten vormen. |
| P1-6 sheet metal tegen SW | 3 d | realistisch, mits R0 | Daarnaast de oorzaak van MT5D-10 oplossen: +1–2 d (ontbreekt in het plan). |
| P1-7 mechanische mates | 3 d | realistisch als de solver het gedrag al heeft | **Niet geverifieerd**: parity.json zegt "typen aanwezig". |
| P2-1 IGES + 3D-DXF | 3 d | **te optimistisch** (5–8 d) | In de meegeleverde OCCT-build zit **alleen `IGESControl_Reader`, geen `IGESControl_Writer`** (dist/replicad_single.d.ts). Dat vergt een eigen OCCT-WASM-build, met een wasm die nu al 22,5 MB is. |
| P2-2 Options | 6–8 d | **optimistisch** (8–12 d) bij echte bedrading | De route "verwijderen" is goedkoop, maar dat is het doel verschuiven: rij 53 heet "Options-dialoog werkend", niet "kleiner". |
| P2-3 design tables | 3 d | realistisch (3–4 d) | Let op: npm-`xlsx` (SheetJS) heeft een bekende kwetsbaarheid. Dat botst met P3-3 "audit 0". Externe kennis, **niet geverifieerd** in deze repo. |
| P2-4 Instant2D/Magnified/3D-maten | 5 d | **te optimistisch** (8–10 d) | 3D-schetsmaten vragen een solver die in 3D werkt. |
| P2-5 AlongXYZ | 1 d | realistisch | — |
| P2-6 Instant3D | 3 d | licht optimistisch (3–5 d) | Nu alleen de diepte van een blinde extrude (store.ts:828–839). |
| P2-7 undo 200 | 0,5 d | realistisch, eerder pessimistisch | `limit = 200` staat in **src/core/document/history.ts:5**. Het plan noemt `src/app/history.ts:5`, en dat bestaat niet. |
| P2-8 Toolbox-achtig | 4 d | realistisch | Rij 37 blijft volgens het plan zelf "deels". |
| P2-9 HLR/analyses tegen R0 | 4 d | **optimistisch** (5–7 d) | Numerieke gelijkheid binnen 1 % met R0 voor drie analyses plus HLR. |
| P2-10 performance 45 → 5 s | 4 d | **optimistisch** (6–10 d), **niet geverifieerd** | Het script `features` duurt nu 163 s (mesh) en 483 s (release, shard 3). Het budget staat in **rebuild.ts:853** (`rebuildBudgetMs = 45_000`). store.ts:1234/1261 lezen het alleen. |
| P2-11 frames | 2 d | realistisch, mits R0 | — |
| P2-12 UI-overlay | 3 d | optimistisch | Een overlay binnen 4 px per groep is streng. |
| P2-13 packaged self-test | 1 d | realistisch | — |
| P2-14 signing | 1 d + aanvraag | realistisch in werk, weken in kalendertijd | SignPath OSS eist een publieke OSS-repo. |
| P3-1 docs | 0,5 d | realistisch | — |
| P3-2 rebuild.ts ≤ 2500 | 2 d | **optimistisch** (3–4 d) | Het bestand telt nu 3393 regels (cap 3398, tools/line-budget.cjs:13). Bijna 900 regels uit de kern verplaatsen, plus een volledige regressie. |
| P3-3 audit, P3-4 bundel, P3-5 UI | 0,5 / 1 / 1 d | realistisch | — |

### 5.3 Wat ontbreekt in het plan

1. **Tussenfix voor eerlijkheid** (0,5 d, vóór P1): ellips, spline en wrap als "Faceted" labelen plus een waarschuwing (MT5D-09, MT5D-13). Nu leeft er weken een stil fout resultaat.
2. **De oorzaak van de flens/hem-fout** op het exacte pad (MT5D-10). Het plan raakt alleen de K-factor (P1-6).
3. **volumeCheck.test.ts:9 omdraaien.** De acceptatietest van P0-2 is in strijd met een bestaande test (MT5D-11).
4. **Herkomst:** QA en CI draaien op een echte clone met `.git`, met een release-tag, en elk QA-log krijgt een commitkop (MT5D-12).
5. **Kwantitatieve tests voor variabele, face- en full-round fillets** (rij 11) en een self-test op de packaged build (rij 30).
6. **Licentie, eigenaar en budget van R0.** Het kritieke pad voor 17 rijen heeft geen eigenaar.
7. **Buffer voor nieuwe bevindingen.** Elke QA-ronde vond tot nu toe nieuwe Majors (0.5.11: F171–F176). Daar staat geen dag voor.
8. **Ontbrekende rijen en tegenstrijdigheden** in het weekplan: zie MT5D-16.

### 5.4 Is "~95 % haalbaar, 100 % niet" eerlijk?

**Deels.**

**~95 %.** De eigen eindstand van het plan is 57/4/1 = 95,2 %. Maar rij 42 ("PDF/DXF/DWG export") gaat in P2-1 naar aanwezig, terwijl het plan zelf zegt dat DWG zonder ODA niet kan. Consequent gerekend is het 56/5/1 = **94,4 %**. Dat haalt het plan alleen als R0 er komt (licentie) en als P1-3 en P1-5 slagen. Met 60–80 dagen is "~95 %" **niet eerlijk**; met ≈ 110–150 dagen wel, onder voorbehoud.

**"100 % niet".** Te stellig geformuleerd. Wat 100 % concreet blokkeert, per rij:

| Rij | Blokkade | Aard |
|---|---|---|
| **54** iconen/lettertype pixelgelijk | Een 1:1-kopie schendt auteurs- en merkrecht | **Juridisch.** Alleen op te lossen door de rij te herdefiniëren (dat is het doel verschuiven, en moet dan expliciet). |
| **51** IGES/DXF/DWG/Parasolid | Een Parasolid-writer vergt een licentie van Siemens. DWG vergt ODA (betaald). | **Licentie of geld.** IGES lukt alleen met een eigen OCCT-build (MT5D-15). |
| **42** PDF/DXF/**DWG** export | Dezelfde DWG-blokkade als 51 | **Geld.** Het plan telt deze rij ten onrechte als aanwezig. |
| **60** code-signing (en **59** installer) | Certificaat of SignPath-OSS | **Geld of keuze**, geen onmogelijkheid. Met een betaald certificaat zijn beide te halen. |
| **37** Toolbox | De Toolbox-inhoud is van SW | **Definitie.** Een eigen ISO-bibliotheek kan functioneel "aanwezig" zijn als de rij zo gedefinieerd wordt. |
| **3, 6, 7, 10, 15, 16, 17, 18, 19, 20, 33, 37, 41, 47, 52, 54, 56** | Alleen te meten tegen een SW-referentie | **Praktisch.** Zonder R0 (SW-licentie) blijven deze rijen maximaal "deels". |

Met geld (certificaat, ODA) blijven alleen 54 (juridisch) en het Parasolid-deel van 51 over: 60/2/0 → **98,4 %**. Wordt 54 ook expliciet geherdefinieerd, dan **99,2 %**. Eerlijker geformuleerd: *"100 % letterlijk niet (rij 54 juridisch, Parasolid-licentie); 98–99 % met budget voor certificaat en ODA plus een SW-referentie; ~94 % gratis."*

## 6. Nieuwe bevindingen (MT5D-09 en verder)

### MT5D-09 — Kritiek — Ellips/spline polygonaal onder het label "exact", zonder waarschuwing
- **Plek:** src/core/occt/brep.ts:4, :68–75. Vergelijk src/core/features/rebuild.ts:3313–3314.
- **Bewijs:**
  - `sampleEntity(sketch, e, 96)` wordt tot `lineEdge`s; het lichaam blijft exact.
  - De waarschuwing op 3314 eist `!exactOf(b) && exactBefore.has(b)`, dus er komt geen melding.
  - Mijn berekening voor een ellips 40×20 × 10 mm: 6278,700 tegen 6283,185 mm³ (−4,485 mm³, −0,071 %). Dat valt onder VOLUME_MISMATCH (0,5 %).
  - In STEP worden het lijnstukken.
  - QA §7.3 ("meldt dat wel eerlijk") is hier onjuist.
- **Fix:**
  - Nu (0,5 d): een lichaam met gesampelde curven markeren als `Faceted` plus een waarschuwing "ellipse/spline approximated".
  - Daarna P1-1: `GC_MakeEllipse` / `gp_Elips` en `Geom_BSplineCurve` (aanwezig in replicad_single.d.ts).
  - Acceptatie: ±0,001 mm³.

### MT5D-10 — Major — Sheet-metal-flens: exacte kernelfout gemaskeerd, mesh als waarheid
- **Plek:** src/core/features/rebuild.ts:1600–1604.
- **Bewijs:**
  - Het comment luidt: "the release pass showed an edge flange and a hem short of material on the exact path; a disagreement keeps the mesh result".
  - De code gooit pas bij `|ev − mv|/mv > 0.005` en valt dan terug op mesh.
  - De oorzaak (te weinig materiaal op het exacte pad) is niet opgelost. Een afwijking onder 0,5 % blijft exact en stil. Mesh is de referentie, terwijl mesh zelf benadert.
  - Of er in de praktijk fouten onder 0,5 % voorkomen, is **niet geverifieerd**. Als dat zo is, is dit Kritiek.
- **Fix:**
  - De exacte flens en hem tegen een gesloten vorm testen (lengte × dikte × hoogte plus bochtsector), niet tegen mesh.
  - De oorzaak in de prism-opbouw zoeken.
  - De tolerantie absoluut maken: |ΔV| < 1e-3 mm³ tegen de formule.

### MT5D-11 — Major — Een unit-test legt de blinde vlek van de kruiscontrole vast
- **Plek:** src/core/features/volumeCheck.test.ts:9 en volumeCheck.ts:8.
- **Bewijs:** `expect(volumeMismatch(30439.07, 30431.33)).toBeNull()`, met als comment "the F140 case … below the limit … so the strict QA tests guard it". Een fout van de grootte van een fillet wordt dus bewust niet gemeld. De acceptatietest van NAAR-100 P0-2 ("8,58 mm³ moet worden gevangen") faalt op deze test.
- **Fix:** een drempel per feature, |ΔV| < max(0,5 mm³; 0,1 % van het featurevolume), en deze assert omdraaien naar `toMatch(/disagree/)`.

### MT5D-12 — Major — Herkomst van HEAD en van de QA-logs niet aantoonbaar
- **Plek:** app-0.5.11/.git (één commit dcd49df; `db0d4b2` ontbreekt), logs/git-standin.txt, provenance.txt, logs/regression-*.log.
- **Bewijs:**
  - Een stand-in-repo zonder geschiedenis; inhoud gelijk aan de zip van db0d4b2 (688/688 CRC).
  - Ongetrackt: `src/qaext/`.
  - De QA-logs hebben geen kop met commit of platform. F176 noemt de kop van de box "commit unknown".
  - De B-rep-run is gesplitst met een box-reset ertussen. Of de boom tussen part1 en part2 gelijk bleef, is **niet geverifieerd**.
- **Fix:** QA draait op `git clone` plus `git checkout <tag>`. `src/qaext/` wordt gecommit. Elk log begint met de kop van run-regression.mjs:48–52. Het rapport noemt de sha256 van de bronzip.

### MT5D-13 — Major — Een wrap-patch op een exact lichaam is polyhedraal maar houdt het exact-label
- **Plek:** src/core/features/rebuild.ts:2187–2188 (`wrapShape = K && exactOf(body) ? meshToolOf(K, tool) : undefined`).
- **Bewijs:**
  - Het comment luidt: "the patch becomes a polyhedral B-rep tool". Het lichaam blijft exact, dus de waarschuwing op 3314 gaat niet af.
  - Parity-rij 15 zegt "mesh-terugval, Faceted"; dat is in strijd met dit pad.
  - Of de UI hier "Faceted" toont, is **niet geverifieerd**.
- **Fix:** een lichaam met een polyhedraal gereedschap als `Faceted` markeren en waarschuwen. Daarna P1-3.

### MT5D-14 — Major — NAAR-100: totaal klopt niet met de eigen items
- **Plek:** NAAR-100.md:13, :26, :40, :52, :71, :88.
- **Bewijs:** de items tellen op tot P0 3,5 / R0 3 / P1 30–35 / P2 40,5–42,5 / P3 5 = **82–89 d**. Geclaimd is 60–80 d. Alleen P2 al zit 11–17 d onder de eigen optelling.
- **Fix:** het totaal herberekenen, buffer voor nieuwe bevindingen toevoegen en de items uit §5.2 herschatten (≈ 110–150 d, **niet geverifieerd**).

### MT5D-15 — Major — De IGES-export "gratis via OCCT" bestaat niet in de meegeleverde build
- **Plek:** NAAR-100 P2-1; node_modules/replicad-opencascadejs (1.1.0) dist/replicad_single.d.ts.
- **Bewijs:** `IGESControl_Reader` staat erin (2×), `IGESControl_Writer` 0×. `STEPControl_Writer` staat er wel in.
- **Fix:** een eigen opencascade.js-build met de IGES-toolkit (let op de wasm-grootte, nu 22,5 MB, en het bundlebudget F174), of IGES schrappen uit Options (F171). Herschatten op 5–8 d.

### MT5D-16 — Minor — NAAR-100: tegenstrijdigheden en foute verwijzingen
- **Bewijs:**
  - (a) Rij 42 (DWG) staat bij P2-1 als "naar aanwezig", terwijl DWG volgens het plan zelf niet gratis kan. Telt de rij als deels, dan is de eindstand 94,4 %, niet 95,2 %.
  - (b) Rij 37 staat in het weekplan (week 8–13) bij "naar aanwezig" en in de eindstand bij "deels".
  - (c) De rijen 42 en 62 ontbreken in het weekplan, terwijl de telling van 57 ze nodig heeft.
  - (d) P0-1 eist "brep 12/12"; de box draaide 14 scripts.
  - (e) P2-7 noemt `src/app/history.ts:5`; dat moet src/core/document/history.ts:5 zijn.
  - (f) P2-10 noemt store.ts:1234/1261 als de plek van het budget; dat staat in rebuild.ts:853.
- **Fix:** het plan corrigeren; per rij één eigenaar en één acceptatietest.

### MT5D-17 — Minor — Bewijs voor parity-rij 56 is verouderd
- **Plek:** parity.json, rij 56.
- **Bewijs:** de rij citeert nog "worker-pass 5/6 (features TimeoutError na 226 s)" uit 0.5.10. De release-pass van 0.5.11 draait wel met `rebuild=worker` (ci.yml:89; release 98/98), maar dat staat niet bij de rij.
- **Fix:** het bewijs van 0.5.11 citeren, of de worker-pass apart opnieuw draaien.

---
*Niets gebouwd of getest. Alleen dit bestand is aangemaakt. Andere teambestanden (riki.md, webi.md) zijn niet aangeraakt.*
