# Strati — teamreview Phlippo CAD 0.5.11 (HEAD `db0d4b2`) tegen SolidWorks

Datum: 3 november 2026 (Europe/Brussels). Rol: strategie. Maatstaf: "echt SolidWorks-gelijk en klaar", met "100 %" als doel van Ian.

**Bronnen (alleen gelezen):**
- `QA-rapport-0.5.11.md`, `NAAR-100.md`, `findings.json`, `parity.json` en `logs/`
- de kloon `app-0.5.11/` en, ter vergelijking, `app-0.5.10/`
- mijn vorige reviews: `report-0.5.10/team/strati.md` en `report-0.5.1/team/strati.md`

**Werkwijze:**
- Ik heb niets gebouwd, niets gedraaid en geen bestaand bestand gewijzigd.
- Mijn eigen controles zijn alleen leesacties: `diff --strip-trailing-cr` tussen de twee klonen, `rg`/`grep`, en een hertelling van `parity.json` met Python.
- Bevindingen die op code-analyse rusten, zijn gemarkeerd als **"code-analyse, niet gedraaid"**.
- Wat ik niet uit de bestanden kan bewijzen, staat er als **"niet geverifieerd"** bij.
- Bij twijfel wint de strengste ernst.

---

## 1. Score: **5/10**

QA geeft 6/10. Ik geef één punt minder. De vooruitgang is echt:
- F139 is opgelost.
- Basis-T3 klopt exact op B-rep: `logs/qa-t3diag.log:11-14`, diff 0.
- Op de box is alles groen: mesh 98/98, B-rep 14/14, release 98/98, vitest 487/487.

Drie zaken houden de score op 5:

1. **Stille geometriefouten zijn nog mogelijk (STRATI-01).** Er bestaan codepaden waarlangs een fillet op een gesplitste rand stil maar half wordt afgerond:
   - gesplitste rand plus een verlengde basis;
   - gesplitste gebogen open rand.

   Bewijs: `edgesets.ts:338`, `:341-348`, `:355` en `:308-310`. Het vangnet kan deze klasse principieel niet zien, omdat beide kernels dezelfde rand-resolutie gebruiken (STRATI-03). De kop van QA (r.18), "eerste versie zonder bekende stille geometriefout", is daarmee te sterk.
2. **Het label "exact" klopt niet voor ellipsen en splines (STRATI-02).**
   - Die bodies zijn polygonaal: `occt/brep.ts:68-75`.
   - Ze tellen toch als exact: `StatusBar.tsx:115`.
   - De statusbalk zegt dan niets: `:225`, alleen zichtbaar bij `faceted > 0`.

   QA r.24 ("het programma meldt dat nu wel eerlijk") klopt voor deze profielen niet.
3. **Er is geen bewijs op HEAD buiten de QA-box, en de geteste boom is een stand-in.**
   - `logs/git-standin.txt:1`: "local-git dcd49df (archive stand-in for db0d4b2)".
   - De Windows-logs zijn van `0495219`/`1fd00e3` (QA r.69).
   - Op HEAD is er geen groene Actions-run (F176).
   - De build is NotSigned (F49/F117).

## 2. GO / NO-GO

| Vraag | Oordeel | Voorwaarden voor GO |
|---|---|---|
| **Klaar** (SW-gelijk) | **NO-GO** | (1) STRATI-01: de drie testgevallen uit §6 in de repo. Elk geval geeft óf het juiste volume (beide stukken afgerond), óf een gele waarschuwing; nooit stil een halve fillet. (2) STRATI-02: een ellips- of spline-body heet "Faceted", of is echt exact (NAAR-100 P1-1). (3) Een groene Actions-run op de release-commit, met een boom waarvan de identiteit met de tag aantoonbaar is (STRATI-04, P0-1). (4) Strikte pariteit ≥ 80 % volgens de definitie in §5.3. |
| **Publiceren** | **NO-GO** | Alles van "klaar", plus: (5) ondertekening Valid (F49/F117, rij 60); (6) een juridische toets door een mens van merknamen en look-alike (F50 / rij 55; QA zelf: "juridische toets door een mens blijft aanbevolen"); (7) een gepackagede self-test vanuit de geïnstalleerde exe (`"packaged": false` in `logs/self-test-nogpu.json:3`); (8) een desktop-installed-log met commit en de namen van de 19 checks (F97). |
| **Eigen gebruik door Ian** | **Voorwaardelijk GO** | Alleen de desktop-app op de B-rep-kernel. Na het **invoegen van een feature vóór een bestaande fillet**, of het **wijzigen van een basismaat** van een body met fillets: de fillet visueel controleren en het volume nameten met Mass Properties (STRATI-01). Bij ellipsen of splines in een profiel: de STEP en de massa niet als exact behandelen (STRATI-02). Face fillets en full rounds lopen via de mesh-kernel (`rebuild.ts:860-864`). Zelf back-ups maken. Geen werk waarbij een maat- of volumeafwijking geld kost zonder dat je zelf nameet. |

## 3. Top 3

1. **Topologische naamgeving is nog niet robuust, en de tests en het vangnet zien dat niet (STRATI-01 en STRATI-03).**
   - De repo-test dekt precies één geval: een sleuf midden in een ongewijzigde rand (`src/qa/qaModels.ts:53-87`, `qaBrep.test.ts:60-78`).
   - Met de kruiscontrole (`brepRefine.ts:71-79`, `volumeCheck.ts:8`) vergelijk je twee kernels die dezelfde `matchEdges` gebruiken. B-rep doet dat in `rebuild.ts:2837-2838`, mesh in `rebuild.ts:818` en `:821`.
   - Een resolutiefout zit daardoor in beide kernels en valt nooit op.
   - Dit is hét kernvak van SolidWorks-gelijkheid. Het is ook de grootste ongemodelleerde post in NAAR-100.
2. **Eerlijkheid van labels en claims (STRATI-02 en STRATI-04).**
   - "Exact" geldt voor polygonale ellips- en spline-bodies.
   - "Op HEAD db0d4b2" rust op een archief-stand-in (één commit, `dcd49df`; `git cat-file db0d4b2` geeft "Not a valid object name").
   - Dit is hetzelfde patroon als N4/F93 in eerdere rondes, al is het nu kleiner en wel benoemd.
3. **Het plan naar 100 % is rekenkundig en inhoudelijk niet sluitend (STRATI-06).**
   - De optelling van de eigen posten geeft 82–89 werkdagen, niet 60–80.
   - Rij 42 ontbreekt in de telling, rij 37 wordt dubbel geteld en rij 59/60 dubbel bestraft.
   - "Aanwezig" heeft geen meetbare definitie per rij.
   - Er is geen poort voor stabiliteit of naamgevingsrobuustheid.

## 4. Ernstcorrecties: "0 Kritiek" en de intrekking van F140

### 4.1 "0 Kritiek" houdt **geen stand**: **Strati telt 2 Kritiek** (STRATI-01 en STRATI-02)

Mijn 8 open Kritiek-punten uit 0.5.10, één voor één:

| F | QA 0.5.11 | Strati 0.5.11 | Bewijs | Toelichting |
|---|---|---|---|---|
| F140 | Ingetrokken (QA-fout) | **Ingetrokken: akkoord, met voorbehoud** | `logs/qa-t3diag.log:5-26`; code-identiteit, zie §4.2 | Correct voor 0.5.11. Voor 0.5.10 is het afgeleid, maar niet gedraaid (`logs/qa-t3diag-on-0.5.10.log:2`: vite ontbreekt) → **niet geverifieerd** op 0.5.10 zelf. Zie STRATI-07. |
| F111 | Opgelost | **Heropend als klasse, Kritiek (via STRATI-01)** | Basis-T3 OK: `qaBrep.test.ts:62-68` (tol 0,01), `qa-t3diag.log:11-14`. Open paden: `edgesets.ts:338`, `:341-348`, `:355`, `:310` | F111 is gesloten op één testgeval. De klasse (een gesplitste rand wordt stil maar deels afgerond) is via code-analyse nog bereikbaar. Volgens de regel "stil fout resultaat = Kritiek" (mijn 0.5.10-review, §4) blijft dit Kritiek tot de tests uit §6 het weerleggen. |
| F139 | Opgelost | **Opgelost: akkoord** | QA r.18 (verlies 97,61 tegen 96,80 theoretisch); `round.ts` nieuwe `tidyChain` (diff 0.5.10→0.5.11, r.131-168); `rebuild.ts:2877-2892` (cut-eigendom op punten langs de rand, niet op het zwaartepunt) | Restpunt: de test laat ±5 % van het verlies toe (`qaStrict.test.ts:31-32`). Dat valt onder F173. |
| F105 | Opgelost | **Major, Deels opgelost** | `.github/workflows/ci.yml` release-pass met `?kernel=brep&rebuild=worker` (ci.yml r.89-115 volgens QA r.484; `query:`-regels gezien); box release 98/98 | Het releasepad wordt nu getest, dus de Kritiek-reden is weg. Maar het is alleen op de box bewezen, niet in Actions en niet op Windows op HEAD (F176, NAAR-100 P0-5). "Opgelost" is te vroeg. |
| F31 | Major, Deels | **Major, Deels: akkoord** | QA r.238 en r.244 (Linux-box 98/98 op HEAD; Actions-runs `c1fc039`/`75ceeea` met rode shards; de run op `772236a` startte niet) | De reproduceerbaar rode Linux-run is weg. Groene CI op HEAD ontbreekt nog. |
| F93 | Major, Deels | **Major, Deels: akkoord** | `TASKS.md:834-835` claimt Windows 98/98 op `0495219` en "Linux-CI release 98/98 (c1fc039, run 41542259973)". QA r.23 en r.69 | De claims noemen nu hun commit, dat is beter. Run 41542259973 zelf is **niet geverifieerd** (geen artefact in de rapportmap). |
| F51 | Major, Deels | **Major, Deels. De verlaging rust op een premisse die niet overal klopt** | `rebuild.ts:3313-3314` waarschuwt alleen bij de overgang exact → facet; `occt/brep.ts:68-75` | Voor plastics/wrap is de waarschuwing eerlijk. Voor ellips en spline niet, want die blijven "exact" heten (STRATI-02, Kritiek). |
| F50 | Opgelost | **Opgelost in de code; geen publicatievrijgave** | "Weldments" komt in `src` nog 20× voor, alleen in commentaar en identifiers (bijv. `icons3d.tsx:706`, `types.ts:468`); `uiText.test.ts:12` bewaakt UI-namen; `logs/trademark-check.log` "total 0" | De juridische toets door een mens ontbreekt. Daarom staat rij 55 bij mij op "deels" (§5.2) en is dit een voorwaarde voor publiceren. |

Daarnaast verhoog ik **F175 naar Kritiek** (als STRATI-02). Een body die "exact" heet, terwijl zijn ellips- of splinevlakken polygonaal zijn, is een stil fout resultaat: de STEP schrijft facetten en de gebruiker krijgt geen signaal.

### 4.2 De intrekking van F140: juist, met voorbehoud

**Wat bewezen is (0.5.11):**
- B-rep z=0 geeft 30431,327 (diff 0) en B-rep z=−40 geeft 30439,911 (diff 0) (`qa-t3diag.log:5-14`).
- `firstPickZ` is 0 onder B-rep en −40 onder mesh (`:5` tegen `:17`). De oude `reduce()`-keuze hing dus van de kernel af.

**Waarom de intrekking aannemelijk is voor 0.5.10** (eigen controle met `diff --strip-trailing-cr app-0.5.10/src app-0.5.11/src`):
- `core/features/edgesets.ts` is **identiek**. Het verschil dat een gewone diff meldt, komt alleen door de regeleinden.
- `core/occt/brep.ts` verschilt alleen in de toegevoegde `sphere()` (r.357-362). `brepKernel.ts` verschilt alleen in de declaratie daarvan.
- In `rebuild.ts` zit geen hunk in het B-rep-filletblok (0.5.11 r.2831-2857).

Het pad dat T3 op B-rep bouwt, is dus vrijwel zeker ongewijzigd.

**Voorbehoud:**
- De diagnose is niet op 0.5.10 gedraaid (`qa-t3diag-on-0.5.10.log:2`).
- Het oude getal 30431,327 is dubbelzinnig. Het is ook precies wat een foutieve "extra 10 mm" op de z=−40-rand zou geven: 30500 − 80·CORNER(2).
- Status: **aannemelijk, maar niet geverifieerd op 0.5.10.**

**Kan de gesplitste-randfout nog op een andere rand?** **Ja, via code-analyse (niet gedraaid).** Zie STRATI-01:
- `splitPieces` werkt alleen voor rechte, open randen (`edgesets.ts:338`).
- Elk stuk moet binnen de **oude** extent liggen (`:340-344`, `:348`).
- Bij minder dan 2 stukken valt de code terug op `matchEdge`. Die geeft bij meerdere randen tussen dezelfde benoemde vlakken alleen de **dichtstbijzijnde** terug (`:309-310`).
- De waarschuwing "edge references could not be found" komt alleen als een referentie **nul** randen oplevert (`rebuild.ts:2848-2849` en `:824`/`:871`). Een gedeeltelijke match blijft stil.

## 5. Oordeel NAAR-100

### 5.1 De 75 % klopt rekenkundig

Mijn hertelling van `parity.json` (Python, `rows[*].status`) geeft 35 aanwezig, 23 deels, 0 kapot en 4 ontbreekt. Dat is (35 + 11,5)/62 = **75,0 %**, gelijk aan `counts`/`pct`.

### 5.2 Inhoudelijk is de 75 % te hoog: strikte telling **71,8 %**

| Rij | parity.json | Strati | Bewijs |
|---|---|---|---|
| 11 Fillet/Chamfer (const, variabel, face, full round) | aanwezig (was kapot) | **deels** | Het bewijs (ev) dekt alleen constante fillets T1–T3. Face fillet en full round vallen buiten `brepRoundable` (`rebuild.ts:860-864`) en worden dus facet. Voor variabel, face, full round en chamfer is er geen 0.5.11-volumebewijs. Daarnaast STRATI-01. |
| 30 Exacte B-rep (OCCT) op desktop | aanwezig | **deels** | Het ev is de self-test met `"packaged": false` (`self-test-nogpu.json:3`), dus niet de geïnstalleerde desktop-app. Ellips en spline zijn polygonaal maar heten exact (STRATI-02). |
| 55 Handelsmerk-vrij | aanwezig | **deels** | Code-bewaking OK. Er is geen juridische toets (QA §6.3, F50). |
| 61 Unit + e2e + B-rep + worker | aanwezig | **deels** | Alleen box-bewijs. De toleranties zijn te ruim (F173: `qaStrict.test.ts:26`, `:69`). F130 staat nog op Deels (findings.json). Rij 62 staat terecht op deels om dezelfde reden. |
| 58 Zonder WebGL / zonder GPU | aanwezig | aanwezig (grensgeval) | viewpanes 35/35 zonder WebGL is echt bewijs. De self-tests draaien niet gepackaged. |

Na deze vier verlagingen: 31 aanwezig, 27 deels, 4 ontbreekt. Dat is (31 + 13,5)/62 = **71,8 %**.

### 5.3 Wat ontbreekt in NAAR-100

1. **Er is geen meetbare definitie van "aanwezig" per rij** (r.5-9). Er staat alleen "alle rijen aanwezig en 0 bevindingen". Daardoor kan dezelfde overwaardering als in §5.2 zich herhalen.
2. **De rekensom klopt niet:**
   - **P2:** de posten tellen op tot 40,5–42,5 d (3 + 6-8 + 3 + 5 + 1 + 3 + 0,5 + 4 + 4 + 4 + 2 + 3 + 1 + 1). Het plan noemt "≈ 25–30 dagen" (r.52), en week 8–13 is maar 6 weken (r.85).
   - **P3:** 5 d, tegen "2–3" in het plan (r.71).
   - **P1:** 30–35 d, tegen "25–35" (r.40).
   - **Totaal:** met P0 (3,5 d) en R0 (3 d) kom ik op **82–89 werkdagen**, niet "60–80" (r.88).
3. **De eindtelling is inconsistent** (r.84-88):
   - Rij 37 staat in week 8–13 bij "naar aanwezig", maar in de eindtelling bij "deels".
   - Rij 42 (PDF/DXF/**DWG**) komt in geen enkele weeklijst voor. Volgens r.17 is DWG geblokkeerd, dus 42 blijft deels. Zonder 42 zijn er maar 56 rijen aanwezig, en dan is het eerlijke plafond (56 + 5·0,5)/62 = **94,4 %**, geen 95,2 %.
   - Rij 59 blijft "deels, want ongesigneerd". Signing is al rij 60, dus het plan bestraft hetzelfde gemis twee keer. P2-13 dekt 59 voor het overige.
4. **Rij 11 en de STRATI-01-klasse ontbreken.**
   - P1-5 (r.48) test T4–T7: sweep, loft, patroon en shell.
   - Er staat niets in over een gesplitste rand plus een maatwijziging, gesplitste gebogen randen of variabele/face/full-round fillets.
   - Er is geen property- of fuzz-test van de randreferenties.
5. **De specificatie van P0-2 (r.31) werkt niet:**
   - De drempel "max(0,5 mm³; 0,1 %)" ligt **onder** het verschil dat de tessellatie op een correct model geeft: 0,794–0,845 mm³ op T3 (`qa-t3diag.log:17-26`). Dat geeft valse alarmen.
   - "Featurevolume" is niet gedefinieerd.
   - Belangrijker: de acceptatietest ("opzettelijk overgeslagen fillet op de mesh") test alleen of de kernels uiteenlopen. Fouten in de gedeelde resolutie blijven onzichtbaar (STRATI-03).
6. **R0 heeft een kosten- en licentie-afhankelijkheid zonder eigenaar of datum** (r.36). Toch hangen 17 rijen eraan.
7. **Er zijn geen stabiliteitspoorten:** niets over "geen rij terug naar deels", meerdere groene runs op rij, of een boomidentiteit die gelijk is aan de tag (STRATI-04).

### 5.4 Is "~95 % haalbaar, 100 % niet" terecht?

**Grotendeels terecht, met twee correcties.**
- **Het plafond is 94,4 %, niet 95,2 %** (zie 5.3, punt 3). De doorlooptijd is eerder 85–100 werkdagen. Dat is mijn schatting: de optelling van 82–89 d plus ≈ 5–8 d voor STRATI-01/03 en rij 11. Uit de bestanden is het **niet geverifieerd**.
- **"100 % niet" geldt alleen bij de huidige rijdefinities en zonder budget.**
  - Rij 60 (signing) kan wel, met een certificaat of de OSS-route (r.18).
  - Rij 54 en rij 37 zijn per definitie onhaalbaar, omdat ze een kopie van SW-eigendom vragen (r.19-20). Die moet je **herdefiniëren**, niet "deels" laten staan.
  - Voor DWG en Parasolid (rij 42/51) moet Ian kiezen: betaald (ODA, r.17), of bewust buiten de scope met zijn handtekening.
  - Of er echt geen vrije Parasolid-writer bestaat, is **niet geverifieerd** (alleen de bewering op r.17).
- **Conclusie:** 100 % is haalbaar als Ian (a) rij 37, 51/42 en 54 meetbaar herdefinieert, of daar budget voor vrijmaakt, en (b) één keer een besluit neemt over signing. Dat zijn besluiten, geen techniek.

### 5.5 Meetbare definitie van "100 %" (voorstel)

Een release is **100 % SW-gelijk** als al het volgende waar is, op één release-commit:

1. **Pariteit:** 62/62 rijen staan op "aanwezig". Rij 37, 42/51 en 54 zijn dan herdefinieerd (zie 5.4) en vooraf door Ian ondertekend. Een rij is pas aanwezig als:
   - **(a) elk deelitem uit de rijnaam** een geautomatiseerde test in de repo heeft (vitest of e2e) die in CI op `?kernel=brep&rebuild=worker` draait;
   - **(b) geometrie:** volume en oppervlak zijn gelijk aan de R0-waarde, binnen |ΔV| ≤ max(0,01 mm³; 1·10⁻⁵ relatief) voor exacte bodies. Bij facet-bodies is de rij niet aanwezig;
   - **(c) 2D en tekening:** maten binnen 0,01 mm van R0; het aantal zichtbare en verborgen lijnen gelijk aan de R0-PDF;
   - **(d) STEP:** de round-trip naar SW (R0) geeft een gelijk volume binnen 1·10⁻³ mm³, en dezelfde vlaktypes. Een ellips is `ELLIPSE`, een spline is `B_SPLINE_*` en er zijn geen polylijnstroken;
   - **(e) UI-rijen:** een overlay-diff met het R0-screenshot binnen 4 px, of een gedragsscript per commando.
2. **Bevindingen:** 0 open van welke ernst ook, en 0 "niet geverifieerd" in `findings.json`.
3. **Naamgevingsrobuustheid:** een propertysuite van ≥ 500 willekeurige bewerkreeksen. Elke reeks voegt een feature in vóór een fillet of chamfer, verwijdert er een, of wijzigt een maat of aantal. Het orakel is het opnieuw opbouwen met handmatig gekozen randen, plus R0 voor 30 vaste gevallen. Uitkomst: **0 stille afwijkingen**. Elke afwijking moet een waarschuwing geven.
4. **Eerlijkheid:** elke body met `exact: true` heeft alleen analytische of NURBS-vlakken (STEP-check). "Faceted" is waar voor elke andere body.
5. **Bewijs:** een groene GitHub Actions-run, met artefacten waarin `commit` gelijk is aan de tag, en een git-boom die echt de tag is (geen stand-in). Daarnaast:
   - Windows-regressie mesh, release en B-rep op dezelfde commit;
   - een self-test met `packaged: true` vanuit de geïnstalleerde exe;
   - `Get-AuthenticodeSignature` = Valid;
   - een desktop-installed-log met de 19 checknamen.
6. **Stabiliteit:** 3 opeenvolgende CI-runs, verspreid over 2 releases, groen zonder rerun, en geen enkele rij teruggezakt.

### 5.6 Concreet gefaseerd pad met poorten

| Fase | Inhoud | Poort (alles moet waar zijn) | Schatting (Strati, niet geverifieerd) |
|---|---|---|---|
| **F0 · Waarheid** | NAAR-100 P0-1…P0-5. STRATI-01: de drie tests uit §6 in `src/qa/`. STRATI-03: een kruiscontrole die onafhankelijk is van `matchEdges`, zie hieronder. STRATI-02: ellips- en spline-bodies `exact:false` tot P1-1. STRATI-04: commit-hash in elk log en een echte git-kloon. | G0: Actions groen op de release-commit; de STRATI-01-tests groen, met juist volume of een expliciete waarschuwing; strikte pariteit opnieuw geteld volgens 5.5-1; 0 Kritiek (Strati-telling). | 7–10 d |
| **R0 · Referentie** (parallel) | Het SW-referentiepakket zoals in NAAR-100 r.38, plus de STRATI-01-modellen en de varianten van rij 11. Eigenaar en licentie vooraf vastgelegd. | GR: `qa-referentie/` met een JSON per rij en model, door Ian goedgekeurd. | 3–5 d + licentie |
| **F1 · Geometrie** | P1-1…P1-7, plus rij 11 volledig in B-rep (face fillet, full round, setback, chamfer-varianten) en de propertysuite uit 5.5-3. | G1: 0 × Faceted in de featurelijst van R0; propertysuite 0 stil; STEP-vlaktypes juist; de rijen 10, 11, 15, 16, 18, 19, 29, 30, 31 en 33 aanwezig volgens 5.5-1. | 35–42 d |
| **F2 · Functies** | P2-1…P2-12, met realistische tijd. | G2: de rijen 3, 6, 7, 17, 20, 27, 41, 44, 47, 52, 53 en 56 aanwezig; geen enkele F1-rij teruggezakt. | 40–43 d |
| **F3 · Release en besluiten** | P2-13, P2-14 en P3. Ian beslist over signing, DWG/Parasolid en de herdefinitie van rij 37 en 54. Juridische toets. | G3 = de definitie uit 5.5, volledig. | 5–8 d + doorlooptijd van de besluiten |

**Waar de onafhankelijke kruiscontrole (F0) uit bestaat:**
- Per fillet- of chamferreferentie wordt de som van de lengtes van de gematchte stukken vergeleken met de lengte die het oorspronkelijke vlakkenpaar nu langs dezelfde lijn of kromme heeft.
- Zodra `matchEdge` bij meerdere kandidaten één rand kiest (`edgesets.ts:310`), verschijnt een waarschuwing.
- Zo'n controle ziet wat beide kernels gemeen hebben.

**Totaal:** ≈ 90–105 werkdagen tot 100 % volgens de definitie uit 5.5, mits Ian de besluiten in F3 neemt. Zonder die besluiten is het plafond 94,4 %.

## 6. Nieuwe bevindingen

**STRATI-01 · Kritiek (voorlopig; code-analyse, niet gedraaid) · Kernel/naamgeving: een fillet op een gesplitste rand rondt stil maar één stuk af, in twee varianten die niet getest worden.**

- **(a) Gesplitste rand plus verlengde basis.**
  - Model: T3 (`qaModels.ts:53-60`), sleuf ervóór ingevoegd (`t3Slot`), daarna de rechthoek 80 → 100 mm.
  - Het stuk 45…100 valt buiten de oude extent (`edgesets.ts:340-344`, `:348`). Dan geeft `splitPieces` alleen 1 stuk terug, dus `[]` (`:355`).
  - Daarna kiest `matchEdge`:
    - met benoemde vlakken: het dichtstbijzijnde stuk (`:309-310`);
    - zonder namen: via `matchMovedEdge` het stuk op 22,5 mm in plaats van 32,5 mm. Het verschil van 10 is groter dan de dubbelzinnigheidsgrens (`:377`).
  - Er komt geen waarschuwing, omdat de referentie niet leeg is (`rebuild.ts:2848-2849`, `:824`).
  - Verwacht volume: 38500 − 90·CORNER(2) = **38422,743 mm³**. Stil foutief: 38500 − 35·CORNER(2) = **38469,956 mm³**. Dat is Δ = 47,21 mm³, onder de 0,5 %-drempel (192,5 mm³), en hoe dan ook op beide kernels gelijk (STRATI-03).
- **(b) Gesplitste gebogen open rand.** Bijvoorbeeld de bovenrand van een R10-hoekboog, gesplitst door een sleuf die ervóór is ingevoegd.
  - `splitPieces` stopt meteen voor randen die niet recht zijn (`:338`).
  - Met benoemde vlakken krijgen beide boogstukken dezelfde namen, en dan wordt alleen het dichtstbijzijnde afgerond (`:308-310`).
  - Zonder namen is het resultaat geen match en een waarschuwing: niet stil.
  - Welke features vlaknamen zetten (`edgeFaces`), is **niet geverifieerd**.
- **(c) Gesloten rand (gatrand) gesplitst.** Niet stil: `closed` matcht niet meer (`:308`, `:313`, `:368`), dus 0 randen en een waarschuwing. Ter afbakening, geen fout.
- **Fix-richting:** `splitPieces` matchen op dezelfde vlakkenparen en dezelfde drager (lijn of kromme), zonder de eis "binnen de oude extent". Waarschuwen zodra `:310` bij meer dan 1 kandidaat kiest. Drie repo-tests (a, b, c) met de volumes hierboven.

**STRATI-02 · Kritiek (verhoging van F175) · Eerlijkheid: ellips- en spline-bodies heten "exact", maar zijn polygonaal.**
- `occt/brep.ts:68-75`: 96 korte lijnsegmenten.
- `StatusBar.tsx:115` telt alleen `!b.exact`, en `:225` toont de cel alleen bij `faceted > 0`.
- `rebuild.ts:3313-3314` waarschuwt alleen bij de overgang van exact naar facet.
- Dit weerspreekt QA r.24 ("meldt dat nu wel eerlijk").
- Gevolg:
  - De STEP bevat vlakstroken in plaats van `ELLIPSE` of `B_SPLINE`.
  - Het volume komt bij een ingeschreven 96-hoek ≈ 0,07 % te laag uit. Dat is een rekenschatting (1 − 96/(2π)·sin(2π/96)), **niet gemeten**.
  - De gebruiker krijgt geen enkel signaal.
- **Fix:** `exact:false` en de Faceted-waarschuwing tot P1-1 af is.

**STRATI-03 · Major · Vangnet: de kruiscontrole is structureel blind voor fouten in de rand-resolutie.**
- Beide kernels halen hun randen uit `bodyEdges` en `matchEdges`: B-rep in `rebuild.ts:2837-2838`, mesh in `:818` en `:821`.
- `brepRefine.ts:71-79` vergelijkt alleen de twee uitkomsten (`volumeCheck.ts:8-17`).
- Geen enkele drempel vangt daarom STRATI-01. Ook de nieuwe NAAR-100 P0-2 (r.31) niet.
- De P0-2-drempel van 0,5 mm³ ligt bovendien onder het tessellatieverschil op een correct T3 (0,794–0,845 mm³, `qa-t3diag.log:17-26`), dus die geeft vals alarm.

**STRATI-04 · Major · Bewijs: de geteste boom is een archief-stand-in. De identiteit met `db0d4b2` is niet verifieerbaar.**
- `logs/git-standin.txt:1`.
- De kloon heeft 1 commit (`dcd49df`, 2026-11-03 09:11 +01:00, "TASKS: Linux-CI-stand…"). `db0d4b2` is geen object in de kloon.
- QA r.9, r.18 en r.238 spreken van "op HEAD db0d4b2". Ik vond geen checksum of tree-hash die dat koppelt → **niet geverifieerd**.
- In de kloon staat bovendien een niet-gecommitte `src/qaext/` (`git status`). Dat is QA's eigen diagnose, maar hoort niet in een releaseboom.

**STRATI-05 · Major · Pariteit: de rijen 11, 30, 55 en 61 zijn overgewaardeerd.**
- Strikte pariteit is **71,8 %** in plaats van 75,0 %. Bewijs per rij in §5.2.
- Rij 11 sprong van "kapot" naar "aanwezig" (`parity.json` `old`) en sloeg "deels" over, op bewijs voor alleen constante fillets.

**STRATI-06 · Major · Plan: NAAR-100 is rekenkundig en inhoudelijk niet sluitend.**
- 82–89 d in plaats van 60–80 (r.40, r.52, r.71, r.88).
- Rij 37 staat dubbel (r.85 tegen r.88); rij 42 ontbreekt; rij 59/60 wordt dubbel bestraft.
- Geen definitie van "aanwezig", geen stabiliteitspoort, R0 zonder eigenaar.
- Het eerlijke plafond is **94,4 %**. Details in §5.3.

**STRATI-07 · Minor · QA-proces: de intrekking van F140 is voor 0.5.10 alleen afgeleid.**
- De diagnose op 0.5.10 draaide niet (`qa-t3diag-on-0.5.10.log:2`).
- Het oude getal is dubbelzinnig (zie §4.2).
- Code-identiteit (`edgesets.ts` gelijk zonder CR, `brep.ts` alleen `sphere()`) maakt de intrekking wel aannemelijk.
- De les is goed toegepast: de repo-test kiest nu deterministisch de z-min-rand (`qaModels.ts:59`).
- Aanbeveling: in QA-rapport 0.5.12 de status "aannemelijk, niet gedraaid op 0.5.10" vermelden. Dat is geen wijziging van dit rapport.

---

*Strati. Alleen gelezen, niets gebouwd of gedraaid, geen bestaande bestanden gewijzigd, niemand gecontacteerd.*
