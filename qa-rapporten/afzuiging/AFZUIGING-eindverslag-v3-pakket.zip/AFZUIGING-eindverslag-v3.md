# Afzuiging nageltafel — ontwerp-QA v3

**7 november 2026, Europe/Brussels (CET). Bron: nieuwe laptopmomentopname, revisie 6.1.**

> **Status: technisch oordeel beschikbaar; nieuwe blinde teamronde NIET uitgevoerd.** Deze executor heeft geen `SendToAgent` of andere delegatietool. De vier denkers konden dus niet worden benaderd. Er zijn geen vier nieuwe rapporten, geen nieuwe Alpha–Delta en geen geldige v3-vonnismatrix. CASUS en FORMAAT liggen klaar; oudere rapporten zijn niet als nieuwe stemmen hergebruikt. De score hieronder is daarom **voorlopig technisch**, niet een voltooid blind teamvonnis. Dit ontbrekende reviewproces is geen productscoreaftrek.

## 1. Eindoordeel

**6,6/10 voor ontwerpmaturiteit — tegenover 5,0/10 in v2 (+1,6 punt).** Onafgerond is de gewogen uitkomst 6,55. De vergelijking gebruikt hetzelfde engineeringkader en dezelfde gewichten als v2.

**Claude heeft aantoonbaar veel opgelost.** Het pakket is geometrisch en softwarematig wezenlijk verder: alle 13 printtypen aanwezig en geldig, coherente actuele hoofdafmetingen, nieuwe berekeningen en een afzonderlijk geteste regelaar. Dit is geen cosmetische README-update.

**Maar niet alles wat als opgelost staat, is daadwerkelijk opgelost.** De pakking staat nog als toekomstig ontwerp in de tekst. Een nieuwe softstartfout is reproduceerbaar. Het koppelvenster kan een bestaande set overschrijven. RPM-berekeningen zijn niet gekoppeld aan de duty-aansturing. De grove Rittal-mat is een expliciete ventilatorbescherming, geen uitgewerkt fijnstofbeheersingsconcept voor de salon.

**Ontbrekende fysieke validatie verlaagt de score nergens.** De nog nodige ontwerpkeuzes, CAD-maatketens, berekeningen en codewijzigingen wél. Prototypeproeven staan alleen in de laatste ongescoorde sectie.

## 2. Nieuwe snapshot en wijzigingen

Bron uitsluitend gelezen:
`C:\Users\ianph\OneDrive\Bureaublad\Phlippo CAD\Claude\voorbeelden\afzuiging`

Nieuwe kopie: `/workspace/afzuiging/src-v3/`. **114 bestanden**, bij overdracht elk op SHA256 gecontroleerd; na het onderzoek opnieuw alle 114 gelijk aan de broninventaris. Builds en generatoruitvoer staan uitsluitend in aparte boxwerkmappen. De laptopbron is niet aangepast. Alleen de toegestane laptoprapportmap is gebruikt voor archief/uitvoer.

Vergelijking met de **102 oorspronkelijke bestanden** uit het v1/v2-bronarchief, dus zonder later afgeleide PDF-tekst:

- **14 toegevoegd, 2 verwijderd, 81 bytegewijzigd, 19 identiek.**
- Nieuw: `revisie.mjs`, vier `docs/`-bestanden, `regel.h`, 16 hosttests, vier eerder ontbrekende STL’s, AFZ-13/14 en de exacte Rittal-filterpart.
- Verwijderd: `Fijnstoffilter-M5.kcad` en `Inlijmmoer-M4.kcad`.
- Filter: generieke M5 170×190×20 → **Rittal SK3171.100, nominale mat 173×173×17, G3/ISO Coarse50%**; cassette nu vierkant.
- Module 3 mm korter: romp **96 mm**, fanbovenkant −27, bodemplaatonderkant −102; **68 mm onderhang** bij 34mm-blad, tegenover 71 in v2.
- Magneetpocket ondieper, fanbout 1mm-verdiepte kopkamer, meerdere knopdetails aangepast; alle 13 STL’s vernieuwd/aanwezig.
- Firmware: regelhart apart, versheid/ijkgeldigheid/stop/herstartbeleid en unieke versleutelde unicast toegevoegd, boosttimer in de module, geen uitklopinstructie.
- Berekeningen en later vrijgave-/meetplan toegevoegd; G01 expliciet uitgesloten.

Volledige bestandslijsten: `v3-evidence/changes-v3.json`; tekstuele brondiff: `source-changes.diff`. “Bytegewijzigd” betekent niet automatisch “geometrie gewijzigd”.

## 3. Gebiedsscores

| Gebied | V2 | V3 | Gewicht | Onderbouwing |
|---|---:|---:|---:|---|
| CAD / geometrie | 8 | **8** | 15% | Hoofdmodel coherent; drie oude overlapkandidaten weg, één klein detail resteert. Tolerantie-/beweeg-/belastingsdetails nog open. |
| Exports / revisies | 2 | **8** | 15% | 13 geldige actuele STL’s en nieuwe tekeningen; resterende README-/tekstconflicten. |
| Luchttechniek / geluid | 5 | **6** | 20% | Echte fan-/systeemcalculatie, concreet vangstdoel; hypothetische mediacurve en ontbrekende RPM/duty-koppeling. |
| Filtratie / beschermingsconcept | 2 | **3** | 15% | Exact product en eerlijker functie; fijnstofretour/externe beheersing niet gesloten. |
| Elektrisch / thermisch | 7 | **7** | 10% | Betere begrotingen; exacte DC-selectie, coördinatie, lokale verliezen en USB-ontwerp blijven. |
| Firmware | 5 | **7** | 10% | Beide builds en 16 oorspronkelijke hosttests slagen; aanvullende tegenproeven vinden echte gaten. |
| Ergonomie als ontwerp | 8 | **8** | 5% | Werkplekcontext en onderhang beter beschreven; geen aftrek voor nog ontbrekende gebruikersproef. |
| Onderhoud als ontwerp | 6 | **7** | 5% | Exacte vervangmat en zakprocedure; pakking is nog niet geïntegreerd. |
| Documentatie | 6 | **7** | 5% | Veel completer en reproduceerbare berekeningen; niet volledig consistent. |
| **Gewogen totaal** | **5,0** | **6,6** | **100%** | **Σ(score × gewicht)/100 = 6,55 → 6,6.** |

## 4. Zelf uitgevoerd digitaal onderzoek

### Alle bestanden en actuele meshes

Alle **114 bestanden** geopend/geparseerd of passend technisch gedecodeerd: 28 JSON/KCAD/loops, 27 SVG’s, 13 STL’s, 6 PDF’s, 5 PNG’s, 3 DXF’s, 1 font en 31 tekst-/codebestanden. Geen ontbrekende CAD-referenties gevonden. Alle PDF’s naar aparte bewijsmap uitgelezen. Python-AST en `node --check` slagen voor de scripts. Dat is syntaxcontrole, geen volledige generatoruitvoering.

**Alle 13 STL’s:** gesloten/watertight, consistente winding, positief volume en één verbonden component. De vier oude slechte meshes en vier ontbrekende exporttypen zijn dus echt hersteld. Hoofdafmetingen en volume vergeleken met de onafhankelijke KCAD-reconstructie: maximale absolute volumeafwijking circa **0,104%**, passend bij verschillende tessellatie. Dit is een sterke controle, geen formeel bewijs van volledige oppervlakidentiteit.

**77/77 actuele componentplaatsingen** gereconstrueerd met Manifold3D en eigen sketch-/extrusielezer; alle zonder kernelstatusfout. Ook de nieuwe convexe 45°-boxflens is ondersteund. 2.926 componentparen op bounding boxes gescreend, relevante paren intersecteerd. Slechts **één kandidaat boven 0,02 mm³:** box/voedingsprint circa **0,649 mm³**. De drie oude knopkandidaten zijn niet meer aangetroffen.

De tweede adapterklem verschilt intern van het losse bestand met een **+55mm-schetsvertaling**, maar heeft dezelfde vorm/volume. Dit is geen onbedoelde partvormfout. Nul mates blijft evenmin automatisch een fout.

**Beperking:** dit is een onafhankelijke getesselleerde reconstructie, niet de officiële Phlippo CAD-kernel. Kleine contacten moeten exact worden bekeken. Geen volledige klauwbeweging-/tolerantiesweep over elk 10–50mm-blad uitgevoerd; alleen de geplaatste 34mm-stand integraal doorgerekend.

![Actuele module](img-v3/module-doorsnede.png)

### Belangrijke gecontroleerde maten

| Onderdeel/keten | Actuele uitkomst |
|---|---|
| Romp / gat / frame | 210 in212, frame222: 1mm per zijde en5mm opleg. Romphoogte96. |
| Cassette | Buiten174,2×174,2×19; wand1,6, bodem2; binnen171×171×17. De173mm-mat wordt zijdelings samengedrukt; exacte matmarges nog vastleggen. |
| Cassette/inlaat/fan | Cassetteonderkant−19, inlaattop−22:3mm; inlaatonderkant−25, fantop−27:2mm. |
| Onderhang | Fan69 tot−96; plaat6 tot−102; bladonderkant−34 → **68mm**. |
| Rooster en knop | Rooster4mm boven blad; knop circa16mm. |
| Magneetbodem | 2,5−1,6 = **0,9mm**, voorheen0,4. Ontwerpverbetering. |
| Fanbouten | Kopkamer1mm: nominale indraaiing5mm; opgegeven plaat-/bouttoleranties geven4,6–5,4. Neem volledige tolerantieketen op, geen grotere bout blind kiezen. |
| Knopdeksel | M4-puntgaten nuØ4,8, dus niet meer de oude nominaleØ4-nultolerantie. Dekselbasis2mm; met USB-steunpennen is totale bounding-boxhoogte4,9mm. |

![Actuele knopdoorsnede](img-v3/knop-doorsnede.png)

### Berekeningen en firmware daadwerkelijk gedraaid

- `docs/berekeningen.py` reproduceert `Berekeningen.md` **inhoudelijk exact**; byteverschil alleen Windows/Linux-regelafbreking. Geen rekenfout afleiden uit die hashverschillen.
- `prijslijst.py` op aparte kopie: **€502,69**. Koopregels €387,69, laser €55, filament €60. README vermeldt nog €495,48/€380,48.
- PlatformIO: **knop SUCCESS, module SUCCESS**, bronbytes gelijk aan snapshot. Derdepartij-GFX-bibliotheek geeft narrowing-waarschuwingen; niet “waarschuwingvrij” noemen.
- Alle **16 ongewijzigde Unity-hosttests slagen** met gratis Zig/Clang-hostcompiler en Unity. Dit is niet dezelfde native-GCC-installatie als Claude op Windows, maar wel de oorspronkelijke testcode tegen dezelfde headers. Geen hardware gebruikt.
- Aanvullende originele-code-tegenproeven: **80% na400ms bij5ms-stappen**, een tweede koppelvraag overschrijft de eerste, en een niet-bewaakbare filterstand toont geen fout. De16 tests bewijzen dus niet alle nieuwe claims.

Bewijs: `v3-evidence/firmware-build.log`, `native-tests.log`, `regression-v3.log` plus bijbehorende scripts/bronidentiteit.

## 5. Wat goed is — behouden

1. **De exportreparatie is echt:** alle13 printtypen bruikbaar als gesloten meshes, sterk overeenkomend met actuele brongeometrie.
2. **Parametrische, compacte module:** coherent matenstelsel, boventoegang, losse voedingsbox en losse bediening; de68mm-onderhang is nu correct afleidbaar.
3. **Concrete componentkeuzes:** juiste S01, gesloten 24V-adapterarchitectuur, exact Rittal-filter, echte drukmeter, tacho, source-/sink-CC-weerstanden aanwezig.
4. **Firmwarearchitectuur veel beter:** hardwarevrije regelaar, tests, meetversheid, bescherming tegen lege ijking, UIT-prioriteit, bevestigde moduletoestand en lokale boostdeadline.
5. **Claimdiscipline verbeterd:** fanvrijdebiet en dichtdruk zijn geen systeemwerkpunt meer; het rekenblad noemt RPM expliciet en scheidt scenario’s. Filter wordt niet langer als fijne luchtreiniger voorgesteld.
6. **Onderhoudsinstructie verbeterd:** mat vervangen in zak, niet uitkloppen/uitblazen, handschoenen en FFP2, opnieuw ijken.
7. **Praktische maakverbeteringen:** magneetbodem0,9mm, fanindraaimaat rond5mm en grotere knopboutuitgangen.

## 6. Iedere oude bevinding opnieuw beoordeeld

De E-ID’s volgen het eerdere samengevoegde eindverslag; v2 heeft de fysieke vrijgave-eisen al uit de score gehaald. Daarom staat hier uitsluitend de overgebleven **ontwerpinhoud**.

| Oude ID | Status v3 | Bevinding |
|---|---|---|
| E01 | **deels/open** | Exact G3-product en eerlijke begrenzing toegevoegd; fijnstof-/ventilatieconcept blijft ongesloten. Zie V3-01. |
| E02 | **deels** | 13 actuele STL’s en bijgewerkte tekeningen/BOM; grove CAD/STL-mix opgelost. README en restteksten blijven afwijkend. Zie V3-09. |
| E03 | **opgelost** | Alle13 STL’s gesloten, consistente winding, positief volume, één verbonden component. |
| E04 | **open** | EPDM-beschrijving is nog geen gewijzigde CAD-sluitmaat. Zie V3-02. |
| E05 | **deels** | Echt rekenblad/fanplot/bronvangstdoel toegevoegd; media-aanname, duty/RPM en vervangmodel nog onvoldoende. Zie V3-03. |
| E06 | **opgelost** | Versheid1s, NAN-status, herstelpad en originele hosttest bevestigd. |
| E07 | **deels** | Geen lege ijking meer; verse/plausibele samples en RPM. Niet-bewaakbare standen/druktopologie blijven. Zie V3-06. |
| E08 | **opgelost** | UIT-prioriteit, bewaking vanaf20%, gezamenlijke stroomherstart UIT en modulebevestigde status in code/tests. Module-only reset is een aparte beleidsgrens. |
| E09 | **deels** | MAC/encryptie en module-eigen120s-boost toegevoegd. Opstartkoppeling blijft overschrijfbaar. Zie V3-05. |
| E10 | **deels** | Klemkracht-/momentberekening toegevoegd; materiaalbron, bladanker en montagegrens nog niet gesloten. Zie V3-07. |
| E11 | **deels** | G01 geschrapt; vermogens-, kabel- en thermiekrekenblad toegevoegd; selectie/coördinatie en USB blijven. Zie V3-08. |
| E12 | **opgelost** | Actieve UI en hoofdprocedure: vervangen in zak, niet uitkloppen/uitblazen; PPE en opnieuw ijken. Pakking valt onderE04. |
| E13 | **deels** | Risicoscenario’s en later meetplan aanwezig; CAD-probe-/morsroute niet volledig. Geen fysieke-teststraf. Zie V3-11. |
| E14 | **deels** | Freesmaat212×102, TR5, voorwandschakelaar en USB-klemming grotendeels consistent; README-resttekst en gedeelde library ontbreken in snapshot. Zie V3-09. |
| E15 | **open** | Exacte filament-/epoxy-/reinigingsspecificatie niet gekozen. Zie V3-10. |
| E16 | **deels** | Concrete werkplek en oorposities/doelen beschreven; enkele datumvlak-/kabeldetails en kostenconsistentie blijven. Geen aftrek voor ontbrekende personenproef. Zie V3-09/V3-11. |

**Samenvatting:** 4 opgelost, 10 deels, 2 open (E01 “deels/open” telt bij deels). Geen rij wordt open gehouden omdat een fysieke proef ontbreekt.

Extra v2-detailcontrole: magneetbodem **opgelost**; nominale fanindraaimaat **verbeterd/opgelost**; knopboutgat **opgelost**; 3 van4 kleine overlapkandidaten **weg**, box/print **restant**. Klem-/moerkamerdaken zijn nog circa1,8/1,6mm en horen bij de materiaal-/belastingsberekening, niet bij een verplicht nu uit te voeren trekproef.

## 7. Actuele bevindingen — samengevoegd, zonder dubbeltelling

**12 punten: 1 Kritiek, 7 Major, 4 Minor.** Ernst beschrijft het ontwerpbelang, geen gemeten kans op letsel. De kritieke bevinding betreft het ongesloten fijnstofconcept voor de bedoelde beschermende salontoepassing; als het product uitsluitend een grove ventilatorbeschermer is, moet de overige werkplekbeheersing apart ontworpen zijn.

### V3-01 — Kritiek: Fijnstofbeheersingsconcept niet gesloten

**Bewijs:** `README.md:9,31,85; docs/Vrijgave-en-meetplan.md:25–47; Rittal fabrikantblad SK3171100`.

G3/ISO Coarse 50% is nu exact en eerlijk als ventilatorbescherming gekozen, maar retourlucht met fijn stof blijft in de salon; algemene ventilatie is niet gedimensioneerd. Kritiek voor de beoogde beschermende salontoepassing, niet een bewezen grensoverschrijding.

**Ontwerpactie:** Kies een passende fijne eindtrap met systeemweerstand en afdichting, buitenafvoer, of een afzonderlijk berekend werkplekbeheersingsconcept.

**Digitaal acceptatiecriterium:** Exacte systeemgrens, bronnen/stoffen, opvang-/retour-/buitenluchtbalans en componentprestaties gedocumenteerd; geen ongefundeerde beschermingsclaim.

### V3-02 — Major: EPDM-afdichting beschreven maar niet ingebouwd

**Bewijs:** `docs/Vrijgave-en-meetplan.md:41–43; maak-afzuiging.mjs:49–50,145–147,258–271`.

3×9mm EPDM en 30–50% compressie staan in een toekomstbeschrijving. CAD-rand en richel blijven op Y=0; verlaging, pakkingonderdeel, klemkracht en toleranceerbare sluiting ontbreken.

**Ontwerpactie:** Integreer de pakking en sluitmaat in de generator/CAD/BOM.

**Digitaal acceptatiecriterium:** Min/max maatketen geeft opgegeven compressie en retentie zonder botsing of bypass; CAD, BOM en tekeningen identiek.

### V3-03 — Major: Rekenblad, RPM, PWM en vervanggrens sluiten niet op elkaar aan

**Bewijs:** `docs/berekeningen.py:16–81,124–127,282–290; docs/Berekeningen.md:18,38,54–56; firmware/include/regel.h:100–125; firmware/src/module/main.cpp:59–63`.

Werkpuntberekening is echte vooruitgang, maar G4-vervangmedium is geen bewezen bovengrens voor de Rittal-mat. Toerentalfracties voeden warmte/geluid; firmware stuurt duty zonder toerentalregeling. De vuilefilterfunctie geeft circa396Pa bij250m³/h, niet een universele250Pa-eindgrens.

**Ontwerpactie:** Definieer echte/expliciet hypothetische mediacurven, RPM-naar-dutyregeling en één vervangmodel; maak onzekerheden eerlijk.

**Digitaal acceptatiecriterium:** Reproduceerbare berekeningen en code gebruiken dezelfde snelheidseenheid en grens; schoon/vervangen/maximum-beladen worden onderscheiden; filter- en nozzle-onzekerheid opgenomen.

### V3-04 — Major: Zachte start is bij de werkelijke lus viermaal te snel

**Bewijs:** `firmware/include/regel.h:120–125; firmware/src/module/main.cpp:212,233; firmware/test/test_regel/test_regel.cpp:24–30,208–218; v3-evidence/regression-v3.log`.

Afronden naar boven per regelstap: bij dt=5ms telkens +1 procentpunt. De originele regelaar bereikt80% na400ms in plaats van minstens1600ms. De meegeleverde test gebruikt250ms-stappen.

**Ontwerpactie:** Gebruik tijdgebaseerde fractionele accumulatie of een vaste hellingreferentie; trek de ongefundeerde zekeringclaim in.

**Digitaal acceptatiecriterium:** Tests bij1/5/10/20/250ms en jitter respecteren50 procentpunten/s (met expliciete afrondmarge), UIT direct; stroomcoördinatie afzonderlijk berekend.

### V3-05 — Major: Koppelvenster kan een bestaande set overschrijven

**Bewijs:** `firmware/include/regel.h:234–265; firmware/src/module/main.cpp:160–175; firmware/src/knop/main.cpp:101–108,436–452; v3-evidence/regression-v3.log`.

Versleutelde unicast en MAC-controle zijn toegevoegd, maar iedere opstart opent60s waarin een andere koppelvraag direct de bestaande peer overschrijft. De ongerichte bevestiging bevat geen unieke uitdagings-/doelbinding.

**Ontwerpactie:** Alleen expliciet herpairen toestaan; bevestig unieke module/knop-uitdaging; controleer peerfouten en sessie/replaybeleid.

**Digitaal acceptatiecriterium:** Twee gelijktijdige sets en herstarts behouden hun koppeling; geen vervanging zonder expliciete handeling; host-/protocoltests voor concurrerende vragen en verkeerd bevestigingsbericht.

### V3-06 — Major: Filterbewaking kan stilzwijgend niet-beschikbaar zijn

**Bewijs:** `firmware/include/regel.h:110–117,128–142; firmware/src/knop/main.cpp:298–333; v3-evidence/regression-v3.log`.

Bij een schone referentie250Pa op80% ligt2×ref boven450Pa: vol=NAN, maar vers/geijkt blijven waar en storing=0. De UI toont normale druk/RPM zonder alarm dat filterbewaking niet werkt. Drukratio blijft bovendien niet uitsluitend filterdruk.

**Ontwerpactie:** Maak bewakingsbeschikbaarheid een expliciete status en leg onderhoudsgrens vast voor de gemeten druktopologie.

**Digitaal acceptatiecriterium:** Iedere niet-bewaakbare stand geeft een duidelijke UI-status of is uitgesloten; verse meting is niet gelijk aan geldige filterbewaking; grensgevallen en wisseling van stand getest.

### V3-07 — Major: Klem-/bladberekening bevat nog ongefundeerde belastingsgrenzen

**Bewijs:** `docs/berekeningen.py:167–178; docs/Berekeningen.md:94–98; README.md:190,197; maak-afzuiging.mjs:44,96`.

Berekeningen48N/31N en0,05/0,03Nm zijn toegevoegd, maar10MPa-kruipgrens en25MPa interlaagschuif zijn generieke invoer zonder exacte materiaal-/temperatuur-/tijdbron. Twee vingers is geen0,05Nm-momentbegrenzing. Huidankers blijven generiek.

**Ontwerpactie:** Kies werkelijk filament/printoriëntatie, belastingsgevallen en bladanker; begrens montagebelasting reproduceerbaar.

**Digitaal acceptatiecriterium:** Rekenblad met materiaalbron, veiligheidsfactoren, contact- en netto doorsneden, lokale bladdruk, exacte ankerdata en controleerbare montagegrens.

### V3-08 — Major: Elektrische selectie en warmtebegroting nog niet volledig sluitend

**Bewijs:** `README.md:74,79,82; docs/Berekeningen.md:58–90; docs/berekeningen.py:139–151,282–290; schema/maak-schema.mjs:129,217–218`.

Juiste S01 en 24V-basis zijn behouden. Zekering en schakelaar missen exact DC-rated part/coördinatie. Lokale C3+sensor0,52W ontbreken in het boxverlies. RPM/duty-mix beperkt de thermische standclaim; USB-pad-/fout-/terugvoedingsontwerp niet uitgewerkt.

**Ontwerpactie:** Selecteer exacte DC-delen; sluit fout-/startstroom, kabel/connector/USB en lokaal warmtepad rekenkundig.

**Digitaal acceptatiecriterium:** Datasheets/bedradingsplan, tijd-stroomcoördinatie, lokale verliesbalans en temperatuur-/deratingmarges uit dezelfde bedrijfsstanden; geen fictieve230V-printafstandseis.

### V3-09 — Minor: README en afgeleide teksten zijn nog niet consistent

**Bewijs:** `README.md:65,102,137–146,174,200–201; docs/Vrijgave-en-meetplan.md:3; tekeningen/prijslijst.csv; maak-afzuiging.mjs:40,99,561`.

Romp staat nog99mm in README, actuele CAD/STL96mm. Filter/M5-verbruikstekst en USB-schroefmontage zijn oud. README495,48 versus reproduceerbare CSV502,69; koperijtotaal387,69 versus380,48.

**Ontwerpactie:** Genereer tabellen en montageproza uit dezelfde gevalideerde gegevens; verwijder oude laserklauwen of label obsolete.

**Digitaal acceptatiecriterium:** Geautomatiseerde controle van alle maat-/prijs-/revisie-/montagevelden; juiste filterprijs en USB-klemming.

### V3-10 — Minor: Materiaal- en reinigingsspecificatie blijft generiek

**Bewijs:** `README.md:118–133; maak-afzuiging.mjs:102–108; docs/berekeningen.py:170`.

Algemene PETG/aceton/75°C-claims onderbouwen exacte voorgespannen print, epoxy, magneten en reinigingsmiddel niet.

**Ontwerpactie:** Kies filament, lijm en schoonmaakproducten met brongegevens en ontwerpgrenzen.

**Digitaal acceptatiecriterium:** Materiaalstaat met product-/datasheetreferenties, temperatuur-/chemische gebruiksgrenzen en printoriëntatie; latere duurproeven apart.

### V3-11 — Minor: Bereikbaarheid, morsroute en werkplek-envelop nog niet volledig op papier

**Bewijs:** `docs/Vrijgave-en-meetplan.md:48–70; laser/rooster.loops; v3-evidence/aligned-probe-clearance.json`.

LB-openingen laten lokaal18,28mm-cirkels toe; de gemeenschappelijke rechte doorgang met cassettebodem/inlaat is maximaal circa11,943mm. Dat bewijst géén12mm-probedoorgang, maar evenmin volledige gelede probe-/tolerantieveiligheid. Morsroute naar elektrische/rotorzones niet uitgewerkt.

**Ontwerpactie:** Voer CAD-probeenvelop en tolerantie-/servicetoestanden uit; teken mors-/afvoerroute en echte kabel-/knie-envelop.

**Digitaal acceptatiecriterium:** Nominale en uiterste CAD-envelop zonder bereik van bewegende delen; materialen/elektrische plekken bij morsscenario benoemd; geen fysieke test als ontwerpacceptatie.

### V3-12 — Minor: Eén kleine print/box-overlapkandidaat resteert

**Bewijs:** `v3-evidence/interferences.json; Voedingsbox/Voedingsprint`.

Onafhankelijke reconstructie vindt0,649mm³ snijvolume. Drie eerdere knopkandidaten zijn verdwenen. Kleine waarde kan bedoeld contact of segmentatie zijn, geen bewezen grote botsing.

**Ontwerpactie:** Controleer exacte kernel ter plaatse en geef bedoelde contact-/spelingstoestand op.

**Digitaal acceptatiecriterium:** Exacte-kerneldoorsnede en maatketen tonen geen ongewenste overlap; bedoelde passing expliciet gelabeld.

## 8. Technische duiding waar de tekst te stellig is

### Filterkeuze: eerlijker, maar niet fijnstoftechnisch af

De geopende **fabrikantpagina** bevestigt173×173×17mm, G3 / ISO Coarse50% en een toepassing voor bescherming van kastcomponenten; zij noemt deeltjes vanaf10µm. Dit is geen gegarandeerde harde afkapdiameter en ook geen PM1-rendement. Een G3-keuze is op zichzelf niet fout voor ventilatorbescherming. Zij is wél onvoldoende als volledige onderbouwing voor gezondheidsbeschermende retourluchtafzuiging bij fijn nagelstof.

De bron stelt dat dit een keuze van Ian is. Dat is een mededeling **in het project**, niet door deze rechter onafhankelijk geverifieerde opdracht. Zij wordt niet als toestemming of veiligheidscertificaat behandeld. Ook bij een bewuste grovefilterkeuze blijft de aanvullende ventilatie-/blootstellingsstrategie ontwerpwerk. Geen H13 als universele wettelijke plicht opleggen; een werkelijk passend eindfilter, buitenafvoer of apart berekend beheersingsconcept zijn verschillende routes.

### Het nieuwe luchtmodel is bruikbaar als scenario, niet als zekere productcurve

Het nominale rekenmodel geeft circa**430m³/h** bij volle snelheid met de gekozen referentieaanname. Een referentiedruk34→50Pa verandert dat naar circa409; een kwadratische in plaats van lineaire mediumrelatie naar circa374. Dit zijn **gevoeligheden**, geen voorspelling of gegarandeerde bandbreedte voor Rittal. De0,7–1,5-band in de levering varieert alleen de overige verliezen, niet alle medium-/nozzle-onzekerheid. G3 versus G4 is geen natuurkundige garantie van lagere drukval.

Het vangstdoel190m³/h voor0,5m/s op10cm en de Dalla-Valle-rekensom zijn reproduceerbaar. Deze benadering veronderstelt een geïdealiseerde geflensde opening; handen, freesemissie, zijstroming en roosterverdeling zijn niet automatisch daarin opgelost. Dat zijn nu expliciete ontwerpvoorwaarden en later validatievragen.

Het script rekent een “vol” G4-referentiemedium via `eind/dp_ref`; bij250m³/h resulteert dat in **circa396Pa**, terwijl de tekst250Pa als einddruk noemt. Dat kan alleen als250Pa een einddruk **op de referentiesnelheid** is bedoeld. Leg deze definitie vast. Op80% **RPM** geeft dit vuile scenario circa166m³/h, onder het190-doel; de tabel vraagt86–89% RPM. Eerder vervangen bij2×schoon kan dit vermijden, maar dan moet juist die vervangtoestand, de werkelijke drukaftakking en de firmwarelogica worden doorgerekend.

Kleine labels kloppen niet: feitelijke roosteropenfractie in de gebruikte formule is0,311, niet0,35; bodemfractie0,709, niet0,56. De code gebruikt de juiste eigen ingevoerde getallen, dus dit is geen verzonnen grote rekenfout.

### Elektriek, warmte en constructie: geen foute primaire eisen verzinnen

S0156,4W plus circa2W besturing past nominaal ruim binnen90W. G01 is daadwerkelijk geschrapt. De fan56W hoort niet als volledige warmtebron in de voedingsbox. De primaire isolatie zit in de gesloten adapter; geen willekeurige230V-creepage op de24V-gatenprint eisen.

De huidige thermische berekening vergeet wel de lokale C3+sensor circa0,52W, maakt veronderstellingen over natuurlijke stroming en gebruikt RPM³ terwijl firmware duty stuurt. “PETG blijft onder60°C” is daarmee geen sluitende ontwerpgarantie. Een exacte materiaal-/warmte-/deratingberekening is nu passend; thermokoppels pas later.

De stijgende PWM beperken bewijst bovendien nooit op zichzelf de aanloopstroom van een elektronische fan of zekeringcoördinatie. De gevonden4×-softstartfout versterkt het bezwaar, maar ook na reparatie is componentdata nodig.

### Geen onterechte rotorbereikclaim

De grootste LB-opening bevat een cirkel van circa**18,28mm**. Maar de projectie die óók door de cassettebodem én Ø127-inlaat past, laat maximaal circa**11,943mm** toe: net géén nominale12mm-cilinder. Daarom keur ik niet af op een zogenaamd bewezen rechte probe-B-doorgang. Het verschil van circa0,057mm is klein, en een volledige gelede3D-probe-/tolerantie-/servicetoestandsanalyse is iets anders dan deze projectie. Het flexibele verbruiksfilter is niet als gecertificeerd vast rooster meegeteld. De fysieke normproef blijft later en ongescoord.

## 9. Top 5 ontwerpacties — klaar om aan Claude te geven

1. **Sluit filter, afdichting en systeemgrens.** `maak-afzuiging.mjs`, cassette/rand/richel, BOM en beschermingsconcept. Integreer de3×9mm-pakking met maatketen en retentie; kies fijne eindtrap/buitenafvoer of bereken expliciet de aanvullende werkplekbeheersing. **Acceptatie:** componentdata, minimumvangstdoel, lucht-/stofroute en min/max compressie sluiten op CAD en berekening aan.
2. **Herstel softstart en radio-associatie met regressietests.** `regel.h`, beide `main.cpp`, protocoltests. **Acceptatie:**50 procentpunten/s bij1–250ms en jitter, direct UIT; bestaande set nooit automatisch overgenomen; twee gelijktijdige sets, herstart en verkeerd ACK getest. De16 oude tests blijven groen.
3. **Verbind RPM, duty, filteralarm en berekening.** `docs/berekeningen.py`, `regel.h`, module en UI. **Acceptatie:** één snelheidsdefinitie, bereik-/bewakingsstatus zichtbaar, exacte vervangtoestand en conservatief benoemde mediacurven;190m³/h-doel, geluid en thermiek bij dezelfde stand doorgerekend.
4. **Maak elektrisch/thermisch en draagconcept af op papier.** Schema/BOM, bedradingsplan, warmte- en klauwberekening. **Acceptatie:** exact DC-rated zekering/schakelaar, tijd-stroom-/fout-/USB-coördinatie, alle lokale verliezen; exact filament/anker, montagegrens en belasting-/kruipfactoren; geen fysieke proef nodig voor deze ontwerpskeuzes.
5. **Maak het pakket aantoonbaar één revisie.** README, prijzen, bouwinstructies, CAD-detailcontrole. **Acceptatie:**96mm-romp,200,5mm-rand, actuele filterprijs/€502,69, juiste USB-klemming/datumvlakken en bronafhankelijkheden consistent; laatste0,649mm³-kandidaat exact verklaard; CAD-probe-/mors-/kabelenvelop vastgelegd; geautomatiseerde maat-/export-/documentchecks groen.

Niets is naar Claude verstuurd; Ian deelt het verslag zelf.

## 10. Blinde teamronde: expliciet onvoltooid

Geen fictieve validiteit-/bruikbaarheid-/blinde-vlekkenscores toegekend aan niet-bestaande v3-rapporten. De oudere Alpha–Delta geven geen vier onafhankelijke nieuwe beoordelingen van revisie6.1.

Gereed voor de ouderagent: `/workspace/afzuiging/team/v3/CASUS-v3.md`, `FORMAAT-v3.md`, `dispatch-v3.json` (vier ontvangers, priority=true, uitvoerN.md en antwoord “klaar N”, nooit Ian/Claude benaderen). De ouderagent moet die vier opdrachten werkelijk verzenden als diens tool beschikbaar is, op alle vier wachten, de inhoud anonimiseren en loten vóór blinde synthese. Pas daarna mag dit technische oordeel een voltooid blind v3-eindvonnis worden genoemd. Sterkste bewijs wint; bij gelijk bewijs de strengste ontwerpbeoordeling.

## 11. Grenzen en bewijsbestanden

Geen fysieke unit, stofblootstelling, thermiek of geluid gemeten. Geen volledige officiële Phlippo-kernelherbouw of volledig parametrisch bureau beschikbaar. De gedeelde `../lib/schets.mjs` staat buiten de gevraagde snapshot; daarom de grote CAD-generator niet als volledig reproduceerbaar gedraaid. Dit bewijst niet dat het gehele project kapot is. Geen CFD/FEM of formele conformiteitskeuring geclaimd.

Eigen reconstructies zijn onderzoeksgeometrie, geen productie-export. Nominale CAD/volume/intersectie is niet gelijk aan fabricagetolerantie of materiaalsterkte. De reproduceerbare softstart- en koppeltegenvoorbeelden zijn daarentegen echte codefeiten, geen ontbrekende-hardware-testargument.

Belangrijkste bijlagen:

- `findings-v3.json`: scores,12 actuele bevindingen en alle16 oude statussen.
- `v3-evidence/changes-v3.json`, `source-changes.diff`, `manifest.json`: herkomst en diff.
- `mesh-audit.json`, `cad-stl-comparison.json`, `cad-reconstruction.json`, `interferences.json`.
- `firmware-build.log`, `native-tests.log`, `regression-v3.log`, `firmware-source-identity.json`.
- `calculation-identity.json`, `independent-calculation-check.json`, `cost-check.json`, alle PDF-teksten en onderzoeksscripts.
- `CASUS-v3.md`, `FORMAAT-v3.md`, `TEAMSTATUS-v3.md`: teamvoorbereiding en transparante blokkade.

**Bronnen:** de nieuwe snapshot is de primaire ontwerpbron. [Rittal fabrikant SK3171100](https://www.rittal.com/com-en/products/PG20231215KLI101/PG20231215KLI1008/PG20240123KLI201/PRO0303?variantId=3171100) is in deze v3-ronde geopend (7 november2026, CET). Voor de bestaande fan-/referentiemediacurven is het eerder opgeslagen bewijs uit v2 gebruikt: [Sanyo Denki S01](https://products.sanyodenki.com/en/sanace/dc/centrifugal-fan/9TG24P0S01/), OEM-familiedatasheet via publieke spiegel en Nittmann2026-filterdata. De externe referentiemedia zijn niet het certificaat van de nieuwe Rittal-mat.

![Actuele voedingsboxdoorsnede](img-v3/box-doorsnede.png)

## 12. Validatieplan voor later — prototypefase, ongescoord

1. **Maken en passen:** print-/montageproef, echte normdelen en koopprinten, klauwbeweging, kabelstekkers, pakkingcompressie en filterwissels op de definitieve revisie.
2. **Lucht/stof:** Q–Δp/RPM/duty, bronvangst met handen en frees, bypass/hermontage en retouruitstoot; passende deskundige blootstellingsbeoordeling. Geen ongecontroleerde stofwolk met personen als demonstratie.
3. **Geluid/ergonomie:** oorposities, resonantie, tocht, polsen/knieën/knopbereik met twee gebruikers; minimaal bruikbare stand volgen uit het vooraf gekozen ontwerpdoel.
4. **Constructie/materialen:** gecontroleerde belasting/uittrek/kruip/retentie en reinigingsduur, volgens vooraf berekende grenzen en exacte materialen.
5. **Elektriek/warmte:** competente inspectie van het complete ingebouwde apparaat, temperatuur/fout-/trekontlastings-/USB-controles. Adapter gesloten houden; geen onveilige netspannings-, rotor- of waterproeven door Ian.
6. **Firmware op hardware:** vergelijken met reeds vastgelegde code-/hosttests, inclusief echte timing, sensorherstel, stilstand, UIT tijdens ijken, radioverlies en gelijktijdige sets.
7. **Bereikbaarheid/morsen:** passende deskundige normprobe-/morsbeoordeling van de vooraf uitgewerkte CAD-maatregelen.

**Geen van deze nog niet uitgevoerde proeven verlaagt de score6,6.** Eerst de resterende ontwerpacties sluiten; daarna prototypevalidatie. De nieuwe blinde teamronde is daarnaast nog nodig om de voorlopige technische score als gezamenlijk eindvonnis te bekrachtigen of te wijzigen.
